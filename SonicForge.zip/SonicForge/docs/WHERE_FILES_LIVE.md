# Where SonicForge keeps and reads files

## What the app is allowed to touch
* **No storage permission is requested.** It cannot browse your phone.
* **No INTERNET permission.** It cannot send or receive anything.
* It only reads files that **you pick** with Android's system file picker (Storage Access Framework), or a folder you link once with 📁 LINK FOLDER
  (read-only access to that one folder tree, revocable any time via UNLINK or Android settings).
* It writes only inside its own folders below, plus (optionally) your Pictures/SonicForge for screenshots on Android 10+.

## Private storage (only the app can read it)  /data/data/com.sonicforge/files/
| Folder | Contents |
|---|---|
| roms/ | copies of the ROMs you imported (renamed `<id>.rom`) |
| saves/ | `<id>.srm` game saves (battery RAM) and `<id>.st1`..`st4` save states |
| data/ | settings.json, library.json, layout_active.json, layout_slot1..6.json, hs/ scores are inside settings |
| art/ | backgrounds/logos you chose |
| sounds/ | launcher sounds (defaults + your custom ones) |
| music/ | imported music and the two test tunes |
| system/ | emulator system folder (empty unless a core wants BIOS files) |
Cache (temporary, auto-cleaned): extracted archive contents.

## Visible app folder (file manager > Android > data > com.sonicforge > files)
| Folder | Contents |
|---|---|
| music/ | drop audio files here, then press RESCAN in the Music tab |
| screenshots/ | PNG screenshots |
(Android 11+ hides Android/data from most file managers. Use the in-app buttons instead; they work everywhere.)

## Archives
* **.zip**: read directly. **.rar**: RAR4 only (RAR5 and password-protected are not supported). **.7z**: supported.
* Every ROM inside the archive (.bin .md .gen .smd .sms .gg .sg) is added as its own game. Nested archives are not opened.
* The archive is unpacked in the cache, the ROM is copied into roms/, the cache is wiped.
* A ROM folder you link is scanned up to 3 levels deep; already-imported files are skipped on later scans.

## Backups
EXPORT BACKUP writes one .zip (data, saves, art, custom sounds) wherever you choose. ROMs and music are not included.
IMPORT BACKUP restores it; restart the app afterwards.
