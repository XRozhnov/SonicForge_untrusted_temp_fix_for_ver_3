# SonicForge: how to build the APK (step by step)

You never need to give anyone access to your repository. The build runs in **your** GitHub account, on GitHub's computers,
and only **you** can download the result. Keep the repo **Private**.

---------------------------------------------------------------------------------------------------
## 0. The one rule that makes or breaks it
Your repository's **root** must directly contain these (not inside an extra folder, not inside the zip):

    .github/workflows/build.yml
    app/
    build.gradle.kts
    settings.gradle.kts
    fetch_core.sh

If you see a single folder called `SonicForge` at the top of your repo, the files are one level too deep:
GitHub will NOT find the workflow, and the **Actions** tab stays empty. (That is almost certainly what happened to you.)
The `.github` folder starts with a dot: many phone file managers hide it and many uploaders silently skip it.

---------------------------------------------------------------------------------------------------
## EASIEST UPLOAD: no folders at all (2 uploads, 2 minutes)
The workflow can build straight from the zip. You never unpack anything and never create folders by hand.
1. Make the (private) repo. On its page tap **Add file > Create new file**.
2. In the name box type exactly `.github/workflows/build.yml` (the slashes create the folders for you), paste the YAML from
   `.github/workflows/build.yml` of this project (open the file in the zip, or copy it from the chat), tap **Commit changes**.
3. Tap **Add file > Upload files**, choose **SonicForge.zip** (one file!), tap **Commit changes**.
4. Open **Actions**: the build starts by itself (or Run workflow). The APK appears under Artifacts when it is green.
To update later: upload a newer SonicForge.zip with the same name (it replaces the old one) and the build runs again.
Other ways: Termux `git push` (section B), or on a PC drag the whole unzipped folder into the browser (section A).

## Universal APK
`SonicForge-universal-APK` contains BOTH 64-bit ARM (arm64-v8a) and 32-bit ARM (armeabi-v7a) code. One file installs on any ARM phone.
The workflow's step "Prove both ARM versions are inside" lists `lib/arm64-v8a/...` and `lib/armeabi-v7a/...` in the log.


---------------------------------------------------------------------------------------------------
## FASTEST WAY 1: one command in Termux (no folders, no clicking)
First time only (installs the tools and gives storage access, tap Allow):

    pkg install -y git unzip && termux-setup-storage

Then this ONE line (edit only PASTE_TOKEN_HERE and, if needed, the two XRozhnov words). It replaces everything in the repo:

    cd ~ && rm -rf SonicForge && unzip -oq ~/storage/downloads/SonicForge.zip && cd SonicForge && git init -q && git add -A && git -c user.name=XRozhnov -c user.email=x@x.x commit -qm sf && git branch -M main && git push -f https://XRozhnov:PASTE_TOKEN_HERE@github.com/XRozhnov/SonicForge.git main

What each part does: go home, delete the old copy, unzip the new one, enter it, make a git repo, add all files, commit, name the branch main,
force-push to your GitHub repo (the token inside the address is the "password"). Delete the token on GitHub afterwards.

## FASTEST WAY 2: upload ONE file from the GitHub website (no folders at all)
The repo only needs two things: `SonicForge.zip` and one workflow file. The workflow unzips the project on GitHub's computer.
1. Repo > **Add file > Upload files** > pick `SonicForge.zip` > Commit. (One file: works on a phone.)
2. If a workflow already exists: open `.github/workflows/build.yml` > pencil icon > select all > paste the contents of `build-from-zip.yml`
   (it is in the docs folder inside the zip, and also provided as a separate file) > Commit.
   If it doesn't exist: **Add file > Create new file**, name `.github/workflows/build.yml`, paste, Commit.
3. Actions > Build APK > Run workflow.
For a new version later: upload the new `SonicForge.zip` with the same name (it replaces the old one). Don't mix this with way 1.

## Both CPU types
The APK already contains **arm64-v8a** (nearly all phones since ~2017) and **armeabi-v7a** (older 32-bit phones) in one file: install the same APK anywhere.

---------------------------------------------------------------------------------------------------
## A. Easiest from a PC (browser only, nothing to install)
1. Unzip `SonicForge.zip`. Open the unzipped `SonicForge` folder. You should see `app`, `.github`, `docs`, `build.gradle.kts` ...
   (Windows: Explorer > View > Show > Hidden items. macOS Finder: press Cmd+Shift+. )
2. github.com > **+** (top right) > **New repository**. Name: `SonicForge`. Choose **Private**. Click **Create repository**.
3. On the empty repo page click **uploading an existing file**.
4. Select everything **inside** the SonicForge folder (Ctrl+A) and drag it into the browser window.
   Drag the `.github` folder too. Wait until all files are listed (about 45 files; the limit is 100 per upload).
5. Click **Commit changes**.
6. Check: the repo front page must list `.github`, `app`, `docs`, `build.gradle.kts` ... at the top level.
   If `.github` is missing, do "Fix: create the workflow by hand" below.

## B. From a phone with Termux (works with the zip)
1. Install **Termux from F-Droid** (the Google Play version is outdated and broken).
2. Create the (private) empty repo on github.com first (steps A2 above, but do not upload anything).
3. Make a **limited, short-lived token** (this is your "limited access"):
   github.com > your photo > **Settings** > **Developer settings** > **Personal access tokens** > **Fine-grained tokens** > **Generate new token**
   * Token name: `sonicforge-upload`
   * Expiration: **1 day** (custom: tomorrow's date)
   * Repository access: **Only select repositories** > choose `SonicForge`
   * Repository permissions: **Contents = Read and write**, **Workflows = Read and write**  (Workflows is needed to upload `.github/workflows`)
   * Generate token and **copy it now** (you will not see it again).
4. In Termux, type these lines one by one (replace YOURNAME and the email):
       pkg update -y
       pkg install -y git unzip
       termux-setup-storage          # tap Allow
       cd ~
       unzip ~/storage/downloads/SonicForge.zip      # adjust the path if the zip is elsewhere
       cd SonicForge
       git config --global user.name "YOURNAME"
       git config --global user.email "you@example.com"
       git init
       git add -A
       git commit -m "SonicForge"
       git branch -M main
       git remote add origin https://github.com/YOURNAME/SonicForge.git
       git push -u origin main
   When it asks **Username**: your GitHub username. **Password**: paste the token (nothing shows while pasting; press Enter).
5. When you are done: github.com > Settings > Developer settings > your token > **Delete**. The access is gone.

## Fix: create the workflow by hand (if Actions is empty or `.github` didn't upload)
1. In the repo click **Add file > Create new file**.
2. In the name box type exactly:  `.github/workflows/build.yml`   (typing the slashes creates the folders)
3. Paste this and click **Commit changes**:

       name: Build APK
       on:
         push:
         workflow_dispatch:      # gives you the "Run workflow" button in the Actions tab
       permissions:
         contents: read
       jobs:
         build:
           runs-on: ubuntu-24.04
           steps:
             - uses: actions/checkout@v4
             - uses: actions/setup-java@v4
               with: { distribution: temurin, java-version: 17 }
             - name: Install Android SDK packages (the runner already ships the SDK)
               run: |
                 SDKM=$(ls -d "${ANDROID_HOME:-/usr/local/lib/android/sdk}"/cmdline-tools/*/bin/sdkmanager | sort -V | tail -1)
                 echo "Using $SDKM"
                 yes | "$SDKM" --licenses > /dev/null || true
                 "$SDKM" "platforms;android-34" "build-tools;34.0.0" "cmake;3.22.1" "ndk;26.1.10909125"
             - uses: gradle/actions/setup-gradle@v3
               with: { gradle-version: 8.7 }
             - name: Fetch emulator core (build time only)
               run: bash fetch_core.sh
             - name: Build
               run: gradle assembleDebug --no-daemon --stacktrace
             - uses: actions/upload-artifact@v4
               with:
                 name: SonicForge-APK
                 path: app/build/outputs/apk/debug/*.apk

---------------------------------------------------------------------------------------------------
## C. Run the build and download the APK (on the GitHub website)
1. Open your repo > **Actions** tab.
   * If it says "Workflows aren't being run on this repository" or a big green **I understand my workflows, go ahead and enable them** button: click it.
   * If you still see nothing: Settings > **Actions** > **General** > choose **Allow all actions and reusable workflows** > Save. Then check section 0.
2. Left list: click **Build APK**. A push already starts it; otherwise click **Run workflow** (right side) > **Run workflow**.
3. A yellow spinning dot = running (about 6 to 12 minutes). **Green check = success. Red X = failed.**
4. Success: click the run's title. Scroll to the very bottom, section **Artifacts**: tap **SonicForge-APK** (downloads a zip).
5. Unzip it (phone: Files app > tap the zip > Extract). Inside is `app-debug.apk`.
6. Tap the APK. Android asks to allow "Install unknown apps" for your browser/file manager: allow, then Install.
7. Failed (red X): click the run > click the **build** job > click the step with the red X > copy the last ~30 lines and send them to me.
   Private repos include 2000 free build minutes per month; one build uses about 10.

## Known build errors
* `Warning: Failed to find package 'tools'` in the step **android-actions/setup-android**: old workflow. Use the current `build.yml` (it has no such step).
* Yellow "Node.js 20 is deprecated" / "setup-java v4 deprecated" / "ubuntu-latest will migrate" notices are only warnings. Ignore them.
* Red X on **Build**: click it, copy the last ~30 lines, send them to me.

## Replacing an old upload with a newer zip (Termux)
    cd ~ && mv SonicForge SonicForge_old
    unzip ~/storage/downloads/SonicForge.zip && cd SonicForge
    git init && git add -A && git commit -m "SonicForge 0.2.0"
    git branch -M main
    git remote add origin https://github.com/YOURNAME/SonicForge.git
    git push -u origin main --force
(Use a fresh 1-day token with Contents + Workflows read/write; delete it afterwards.)

## D. Building on your own PC instead (optional)
1. Install **Android Studio**. SDK Manager > install: SDK Platform 34, Build-Tools 34, **NDK 26.1.10909125**, **CMake 3.22.1**.
2. Unzip the project. Linux/macOS: run `bash fetch_core.sh`. Windows: open the two URLs inside `fetch_core.sh` in a browser, unzip each,
   rename the `.so` to `libgpgx.so` and put them in `app/src/main/jniLibs/arm64-v8a/` and `.../armeabi-v7a/`.
3. Android Studio > **File > Open** the folder, wait for sync (if it asks for Gradle: install Gradle 8.7 and run `gradle wrapper` once).
4. **Build > Build APK(s)**. Result: `app/build/outputs/apk/debug/app-debug.apk`.
5. Install: copy to the phone and tap it, or `adb install -r app-debug.apk`.

## E. Uninstalling
* The app: long-press > Uninstall (or `adb uninstall com.sonicforge`). This erases its private data: **export a backup first**
  (SETTINGS > DATA & PRIVACY > EXPORT BACKUP, save the zip somewhere outside the app).
* Updating: just install a newer APK over the old one. Every build uses the same included signing key, so data is kept.
* Tools: uninstall Android Studio; delete the `Android/Sdk`, `.gradle` and `.android` folders in your user folder.

## F. How to make sure it works
1. Open the app: the guide appears on first launch. Close it; SETTINGS > ABOUT APP shows **Version 0.2.0 "Archives n' Cheats"**.
2. SETTINGS > DATA & PRIVACY: green line "does NOT declare the INTERNET permission". Press **RUN STORAGE SELF-TEST**: a floppy icon with **✓** appears.
3. GAMES > + ADD GAME > pick a ROM (or zip/rar/7z). It appears in the list. Press PLAY.
4. In the game: Back button > SAVE slot 1: floppy ✓ appears. Quit, relaunch, LOAD slot 1.
5. If the game shows "Emulator core is missing": the `fetch_core.sh` step failed or the file isn't named `libgpgx.so`. Send me the log.

---------------------------------------------------------------------------------------------------
## What the build produces now (version 0.3.3)
The workflow uploads an artifact with THREE APKs:
* `app-universal-debug.apk`: works on any ARM phone (largest).
* `app-arm64-v8a-debug.apk`: nearly all phones since about 2017 (smaller).
* `app-armeabi-v7a-debug.apk`: older 32-bit phones.
SETTINGS > ABOUT APP shows your CPU types and which one to use. Android TV uses the same APK.
Two build steps are optional and may print "MISS" without failing the build: `fetch_core.sh` for the 32X/GBA cores and `fetch_extras.sh` for Ruffle (Flash). The required Mega Drive core must download or the build stops.

---------------------------------------------------------------------------------------------------
## Updating the workflow file (important for Flash and the three APKs)
GitHub only runs the workflow stored in your repository ROOT:

    .github/workflows/build.yml

It is NOT read from inside SonicForge.zip. After this update replace that file in your repo with the one from this package (`docs/build-from-zip.yml`, also available as `build.yml`), or copy it from the app: SETTINGS ▸ ABOUT & UPDATES ▸ COPY build.yml. If you keep the old workflow, the build still works but Ruffle (Flash) is not included and Flash games show "Ruffle is not included in this build".

Steps: GitHub ▸ your repo ▸ .github/workflows ▸ build.yml ▸ pencil (edit) ▸ select all ▸ paste ▸ Commit. Then upload the new SonicForge.zip (replace the old one) and run Actions ▸ Build APK.
