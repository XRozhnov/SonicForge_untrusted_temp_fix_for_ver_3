# SonicForge: what is NOT in the app yet

Status after version **0.3.4 "Rock Solid Rings"**. This list is only about things we planned or you asked for and that are still missing. (New features and things that were added but are shaky are listed in "What's new" inside the app: SETTINGS ▸ ABOUT & UPDATES.)

## 1. Carried over from earlier versions (still missing)
| Area | What is missing | Why / note |
|---|---|---|
| Translations | The What's-new text, tutorial, HELP topics and all character dialogues are English only | Buttons, tabs and titles are translated into 12 languages (es fr de pt-BR it ru uk ja zh ko hi tr). Long texts come next. Arabic is skipped (right-to-left layout risk) |
| Music | More equalizer styles; two more player looks; one guide character that joins all dialogues; playlist covers; lyrics / timestamps; karaoke / voice recording | Equalizer: five styles exist (bars, mirror, wave, dots, circle) |
| Images | Recommended sizes shown when importing, a small crop editor (like changing a Discord avatar) that does not leave unused copies | Planned together with the drawing tab |
| Consoles | Nintendo DS, SRB2 tab, 3DS / Saturn / Dreamcast / PSP / GameCube / Wii / PS2 | DS needs a two-screen touch layout; the others need hardware rendering and are too big for this app. See HELP ▸ systems |
| Platforms | Android TV remote layout, an x86 / x86_64 build, home-screen widgets | The same APK already installs on Android TV, but is not tuned for a remote |
| Looks | Holiday themes, gradient / image backgrounds with fit and crop, PNG-mask frames, per-tab presets, animated backgrounds beyond particles | |
| Vibration | Hack-specific profiles (Sonic 2 XL, Hellfire Saga, Ordinary Sonic), wind in Sky Battery, breakable walls, score tally, casino, boss music | Ring Finder already teaches the app a counter in any game |
| Helpers | Much more dialogue: franchise history, collabs, other games to try, indie tips, birthdays, canonical-looking avatars | |

## 2. Planned next (not started)
1. **Drawing / pixel-art tab**: STARTED in 0.3.4 (layers with visibility, opacity and clipping, paste a picture onto a layer or as a new layer, canvas resize, undo, export PNG). Still missing: a gallery of several drawings, selection/move tools, blend modes, layer folders, brush shapes, lock-alpha, importing a picture as a reference layer with a transparency slider.
2. **Simple text editor** (for code and notes) and a **file explorer** (multi-select, copy/move/rename/delete/extract, format groups, hidden/system toggle), including a switch to use any file manager / text editor installed on the phone (already chosen in SETTINGS ▸ GENERAL ▸ External apps).
3. **Comics reader** (Kotatsu-style), **photo gallery**, **video player** (YouTube-style controls, subtitles).
4. **Music library like Auxio / YouTube Music**: songs / albums / artists / genres / playlists with pictures.
5. **Flash**: per-game control profiles; updating Ruffle from inside the app is NOT planned (the app has no internet permission on purpose).

## 3. Known limits (cannot be fixed, only explained)
* RAR5 archives cannot be read (the library supports RAR4). Re-pack as ZIP or 7z.
* A PlayStation pad's touchpad is not available to apps on Android, so it cannot move the Flash mouse.
* Ruffle runs many but not all Flash games; speed depends on the game's own frame rate.
* 32-bit-only apps such as some OpenBOR builds do not run on phones without 32-bit support.
