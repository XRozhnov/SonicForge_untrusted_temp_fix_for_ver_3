# Notes for the next updates (reference screenshots, studied)

Written for whoever continues this project (including me). These are the apps you showed as examples, and what to take from each.

## Kotatsu (comics reader)
* Bottom bar: History, Favourites, Explore, Feed. Explore has Search, "Local storage", Bookmarks, Random, Downloads, then a grid of sources.
* Reader menu (bottom sheet): Save page, Add bookmark, **Reading mode** (Standard / Right-to-left / Vertical / Webtoon, remembered per comic), two-page layout in landscape, pull gesture, rotate screen, auto-scroll, colour correction, Settings. Top shows chapter and page counters ("Ch. 2/232  Page 1/26"), battery and clock.
* Opening a title shows a cover, title, chapter, page slider at the bottom with previous/next chapter, a chapter list and a ⋮ menu.
* Take: reading modes + per-comic memory, long vertical images (webtoon) without crashing, image folders and CBZ import, bookmark, colour correction.

## YouTube Music / Auxio (audio player)
* YouTube Music: bottom tabs Home / Samples / Search / Library; a collage header for playlists (4 covers), big title, buttons (download, save, comment, shuffle, big round play); mini player at the bottom with cover + title + play; Now Playing has an audio/video toggle, big cover, like/comments, a seek bar with times, shuffle · previous · big play/pause · next · repeat, and a "Queue" sheet pulled up from the bottom (drag handles to reorder).
* Auxio: top tabs Songs / Albums / Artists / Genres / Playlists; a round shuffle button floating bottom right; a mini player with progress line; Now Playing with title/artist/album, seek bar, a pill-shaped previous/next, a big round play, outlined shuffle and repeat buttons, a Queue sheet; per-playlist pictures.
* Done in 0.3.4: Queue panel (played / now / next), mini player on every tab with hide + restore chip, favourites, system lists. Still to do: album / artist / genre views, playlist covers, drag-to-reorder in the queue.

## Image crop editor (the Discord-like crop in your gallery screenshot)
* Cancel / undo / redo / Save at the top, a crop frame with a 3×3 grid and handles, a **rotation ruler** (−45°…+45°, shows "6.4°"), and ✕ / ✓ at the bottom. Use for covers, logos, backgrounds, avatars: pan + pinch zoom inside a fixed aspect frame, optional rotate, then save ONE file and delete the previous one (no cache spam).

## Gallery / file filter chips (the colourful outlined chips)
* Sections "Date" (On this day, Recently added, months, weekdays), "Formats" (PNG, SVG, WEBM, WEBP, AVIF…), "Albums" (folders). Chips with an icon + label, each with its own colour outline, collapsible sections with ⌃. Take for the file explorer: filter by format group, by date, by folder; a search field at the top.

## Pixel-art / drawing app gallery (the "My Gallery (39)" screen) and layer panel
* Grid of thumbnails "Untitled47…" with folders, trash on a folder, Cloud Sync toggle (we will not add cloud), select mode, bottom bar: new, info, play, share, ⋮, Edit.
* Layer panel (Ibis-Paint-like): a list with thumbnail, name, **eye (visibility)**, opacity %, blend mode, drag handle; a **Selection layer**; folders; **clipping arrow** (the layer is drawn only where the layer below has paint); lock-alpha; merge down; delete; FX; blend-mode dropdown and an opacity slider with − / + buttons. Canvas tools at the right: checkerboard (transparent background), mirror, move, flip, merge, etc.
* Take for the drawing tab: layer list with eye, opacity, blend mode, clipping toggle, lock-alpha, merge, reorder; a "paste image to layer" action; canvas resize (anchor + new size); gallery grid of drawings.

## The official Ruffle app (Flash)
* Start screen: logo, "URL" box + Open URL, or "Select a SWF". In a game: a big see-through-free **keyboard under the game** (number row, QWERTY rows, CTRL ALT SPACE and arrows, plus ⌨ and ☰ buttons). It runs your Flash Sonic games well (Ultimate Flash Sonic, Sonic flash platformers).
* Our version: the full keyboard is drawn OVER the game and is semi-transparent (opacity slider), toggled with ⌨; every gamepad button can be bound to a key or a mouse click; the old simple on-screen buttons remain as an optional experimental mode.

## My own app screens (from your logs / screenshots)
* The log viewer showed the real problems (endless recursion in `heroCol`, ROM rejected because the import never wrote the file). Rule: **every user action that can fail must say what happened** (pop-up AND log), because Android pop-ups cut long text.
* The game screen with the pad overlay (screenshot with SV / LD / ≡ buttons, D-pad, A B C): fine, but the D-pad has no outline and the corner buttons are small; consider outlines and size sliders per control.
