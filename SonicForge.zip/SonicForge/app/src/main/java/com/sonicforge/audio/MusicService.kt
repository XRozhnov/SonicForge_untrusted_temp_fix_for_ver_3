package com.sonicforge.audio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.KeyEvent
import com.sonicforge.MainActivity
import com.sonicforge.data.Store

/**
 * Keeps music playing in the background with a media notification, handles lock-screen/headphone buttons:
 * 1 press = play/pause, 2 presses = next, 3 presses = restart the song (or previous track if you're within the first 3 s).
 */
class MusicService : Service() {
    private var session: MediaSession? = null
    private val h = Handler(Looper.getMainLooper()); private var clicks = 0
    private val flush = Runnable { when (clicks) { 1 -> Music.toggle(); 2 -> Music.next(); else -> if (clicks >= 3) Music.prev() }; clicks = 0 }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Music", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "SonicForge").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onMediaButtonEvent(i: Intent): Boolean {
                    val e = i.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT) ?: return false
                    if (e.action != KeyEvent.ACTION_DOWN || e.repeatCount > 0) return true
                    when (e.keyCode) {
                        KeyEvent.KEYCODE_HEADSETHOOK, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { clicks++; h.removeCallbacks(flush); h.postDelayed(flush, 380) }
                        KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> Music.toggle()
                        KeyEvent.KEYCODE_MEDIA_NEXT -> Music.next(); KeyEvent.KEYCODE_MEDIA_PREVIOUS -> Music.prev()
                        else -> return false
                    }
                    return true
                }
                override fun onPlay() = Music.toggle(); override fun onPause() = Music.toggle(); override fun onSkipToNext() = Music.next(); override fun onSkipToPrevious() = Music.prev()
            })
            isActive = true
        }
        Music.onChange = { push() }
    }
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) { A_TOGGLE -> Music.toggle(); A_NEXT -> Music.next(); A_PREV -> Music.prev(); A_STOP -> { Music.stop(); stopForeground(true); stopSelf(); return START_NOT_STICKY } }
        push(); return START_STICKY
    }
    private fun act(a: String, icon: Int, label: String): Notification.Action {
        val pi = PendingIntent.getService(this, a.hashCode(), Intent(this, MusicService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi).build()
    }
    private fun push() {
        val t = Music.tracks.getOrNull(Music.current)
        session?.setPlaybackState(PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS)
            .setState(if (Music.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, Music.pos().toLong(), 1f).build())
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else @Suppress("DEPRECATION") Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(t?.title ?: "SonicForge").setContentText(if (Music.playing) "Playing" else "Paused").setContentIntent(open).setOngoing(Music.playing)
            .addAction(act(A_PREV, android.R.drawable.ic_media_previous, "Previous"))
            .addAction(act(A_TOGGLE, if (Music.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause"))
            .addAction(act(A_NEXT, android.R.drawable.ic_media_next, "Next"))
            .addAction(act(A_STOP, android.R.drawable.ic_menu_close_clear_cancel, "Close"))
            .setStyle(Notification.MediaStyle().setMediaSession(session?.sessionToken).setShowActionsInCompactView(0, 1, 2))
        val n = b.build()
        try { if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(NID, n) } catch (_: Exception) {}
    }
    override fun onDestroy() { Music.onChange = null; session?.release(); super.onDestroy() }

    companion object {
        const val CH = "music"; const val NID = 7; const val A_TOGGLE = "sf.toggle"; const val A_NEXT = "sf.next"; const val A_PREV = "sf.prev"; const val A_STOP = "sf.stop"
        /** called when music starts: shows the notification service if the setting is on */
        fun ensure(ctx: Context) { if (!Store.b("musicNotif", true)) return; try { val i = Intent(ctx, MusicService::class.java); if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i) } catch (_: Exception) {} }
        fun stop(ctx: Context) { try { ctx.stopService(Intent(ctx, MusicService::class.java)) } catch (_: Exception) {} }
    }
}
