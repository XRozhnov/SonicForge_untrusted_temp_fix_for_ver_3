package com.sonicforge.input

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.sonicforge.data.SaveEvent
import com.sonicforge.data.Store
import org.json.JSONObject

data class HEv(val id: String, val label: String, val defAmp: Int)

/**
 * Vibration. Two independent channels: the app (menus) and the emulator (touch buttons + in-game events).
 * Every game event has its own on/off switch and strength; templates (Quiet/Medium/Max) and 3 saved presets set them all at once;
 * a per-game switch and the global switch never erase your settings.
 */
object Haptics {
    val events = listOf(
        HEv("touch", "Touch buttons", 35), HEv("ring", "Ring collected", 25), HEv("hurt", "Ring loss / hit", 80), HEv("death", "Death", 100),
        HEv("jump", "Jump", 40), HEv("spin", "Spin dash", 60), HEv("spring", "Spring", 70), HEv("fly", "Tails flying", 30), HEv("drown", "Drowning countdown", 75),
        HEv("bite", "Enemy bite (steals a ring)", 70), HEv("drain", "Rings draining away", 45), HEv("oneup", "Extra life", 55), HEv("shield", "Shield picked up", 50),
        HEv("invinc", "Invincibility sparkles", 25), HEv("shoes", "Speed shoes", 45), HEv("fizz", "Fire shield doused", 50), HEv("zap", "Lightning shield zaps water", 80), HEv("step", "Footsteps (experimental)", 25))
    @Volatile var currentGame = ""
    private var vib: Vibrator? = null
    private val last = HashMap<String, Long>()
    fun init(ctx: Context) {
        vib = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
              else @Suppress("DEPRECATION") ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
    fun appOn() = Store.b("hapAppOn", true)
    fun gameOn() = Store.b("hapGameOn", true) && Store.s("hapG_$currentGame", "1") != "0"
    fun evOn(id: String) = Store.b("hapE_${id}_on", id != "step")
    fun evAmp(id: String) = Store.i("hapE_${id}_amp", events.first { it.id == id }.defAmp)
    fun defAmp(id: String): Int = events.firstOrNull { it.id == id }?.let { it.defAmp } ?: 60

    private fun fire(id: String, a: Int) {
        val v = vib ?: return; if (!v.hasVibrator() || a <= 0) return
        val now = System.currentTimeMillis(); val gap = when (id) { "ring" -> 50; "fly" -> 220; "touch" -> 20; "bite" -> 35; "drain" -> 45; "step" -> 120; "invinc" -> 300; else -> 110 }
        if (now - (last[id] ?: 0) < gap) return; last[id] = now
        val amp = (a * 255 / 100).coerceIn(1, 255); val k = 0.6f + a / 100f * 0.8f
        fun ms(x: Int) = (x * k).toLong().coerceAtLeast(3)
        val (t, s) = when (id) {
            "hurt" -> longArrayOf(0, ms(35), 30, ms(55)) to intArrayOf(0, amp, 0, amp)
            "death" -> longArrayOf(0, ms(120), 60, ms(170)) to intArrayOf(0, amp, 0, amp)
            "spin" -> longArrayOf(0, ms(15), 25, ms(20), 25, ms(25), 25, ms(38)) to intArrayOf(0, amp / 3 + 1, 0, amp / 2 + 1, 0, amp * 3 / 4 + 1, 0, amp)
            "spring" -> longArrayOf(0, ms(12), 18, ms(26)) to intArrayOf(0, amp, 0, amp / 2 + 1)
            "drown" -> longArrayOf(0, ms(60), 70, ms(60)) to intArrayOf(0, amp, 0, amp)
            "bite" -> longArrayOf(0, ms(5), 12, ms(5)) to intArrayOf(0, amp, 0, amp)                  // two quick sharp ticks, like snapping teeth
            "drain" -> longArrayOf(0, ms(10), 8, ms(8)) to intArrayOf(0, amp, 0, amp / 2 + 1)       // a soft fading pulse per ring sucked away
            "oneup" -> longArrayOf(0, ms(15), 30, ms(15), 30, ms(25)) to intArrayOf(0, amp / 2 + 1, 0, amp * 3 / 4 + 1, 0, amp)   // rising jingle
            "shield" -> longArrayOf(0, ms(20), 30, ms(10)) to intArrayOf(0, amp, 0, amp / 2 + 1)
            "invinc" -> longArrayOf(0, 6, 40, 6, 40, 6, 40, 6) to intArrayOf(0, amp / 2 + 1, 0, amp / 2 + 1, 0, amp / 2 + 1, 0, amp / 2 + 1)   // soft sparkles
            "shoes" -> longArrayOf(0, ms(40)) to intArrayOf(0, amp)
            "fizz" -> longArrayOf(0, ms(40), 20, ms(30), 20, ms(20)) to intArrayOf(0, amp / 2 + 1, 0, amp / 3 + 1, 0, amp / 5 + 1)   // steam fading out
            "zap" -> longArrayOf(0, 8, 10, 8, 10, 8, 10, 20) to intArrayOf(0, amp, 0, amp, 0, amp, 0, amp)   // electric jitter
            "step" -> longArrayOf(0, ms(5)) to intArrayOf(0, amp * 2 / 3 + 1)
            "ring", "touch", "ui" -> longArrayOf(0, ms(8)) to intArrayOf(0, amp)
            else -> longArrayOf(0, ms(14)) to intArrayOf(0, amp)
        }
        try { v.vibrate(VibrationEffect.createWaveform(t, s, -1)) } catch (_: Exception) {}
    }

    fun ui() { if (appOn()) fire("ui", Store.i("hapApp", 35)) }
    fun gameTouch() = game("touch")
    fun gameEvent(kind: String) = game(kind)
    fun game(ev: String) { if (!gameOn() || !evOn(ev)) return; fire(ev, evAmp(ev)) }
    fun test(ev: String) { if (ev == "ui") fire("ui", Store.i("hapApp", 35)) else fire(ev, evAmp(ev)) }
    fun stopAll() { try { vib?.cancel() } catch (_: Exception) {} }

    fun template(name: String) {
        events.forEach { e -> Store.setI("hapE_${e.id}_amp", when (name) { "quiet" -> (e.defAmp / 2).coerceAtLeast(10); "max" -> (e.defAmp * 16 / 10).coerceAtMost(100); else -> e.defAmp }) }
        Store.setI("hapApp", when (name) { "quiet" -> 20; "max" -> 70; else -> 35 })
    }
    /** Presets 1-3 are built in (1 = rings + buttons only, 2 = classic set, 3 = everything but footsteps). 4-9 are yours (empty until you save). */
    fun builtin(n: Int) {
        val set = when (n) { 1 -> setOf("touch", "ring"); 2 -> setOf("touch", "ring", "hurt", "death", "jump", "spin", "spring", "fly", "drown"); else -> events.map { it.id }.toSet() - "step" }
        events.forEach { Store.setB("hapE_${it.id}_on", it.id in set); Store.setI("hapE_${it.id}_amp", it.defAmp) }
        Store.setI("hapApp", 35)
    }
    fun presetExists(n: Int) = n <= 3 || Store.read("haptic_preset_$n.json") != null
    fun savePreset(n: Int): Boolean {
        if (n <= 3) return false
        val o = JSONObject().put("app", Store.i("hapApp", 35)); events.forEach { o.put(it.id, JSONObject().put("on", evOn(it.id)).put("amp", evAmp(it.id))) }
        val ok = Store.writeVerified("haptic_preset_$n.json", o.toString()); Store.events.tryEmit(SaveEvent("Vibration preset $n saved", ok)); return ok
    }
    fun loadPreset(n: Int): Boolean {
        if (n <= 3) { builtin(n); Store.events.tryEmit(SaveEvent("Vibration preset $n applied", true)); return true }
        val t = Store.read("haptic_preset_$n.json")
        if (t == null) { Store.events.tryEmit(SaveEvent("Vibration preset $n is empty (yours to fill)", false)); return false }
        return try { val o = JSONObject(t); Store.setI("hapApp", o.optInt("app", 35))
            events.forEach { e -> o.optJSONObject(e.id)?.let { Store.setB("hapE_${e.id}_on", it.optBoolean("on", true)); Store.setI("hapE_${e.id}_amp", it.optInt("amp", e.defAmp)) } }
            Store.events.tryEmit(SaveEvent("Vibration preset $n loaded", true)); true } catch (_: Exception) { false }
    }
}
