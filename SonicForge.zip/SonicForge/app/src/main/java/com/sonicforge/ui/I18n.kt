package com.sonicforge.ui

import androidx.compose.material3.Text as M3Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import com.sonicforge.data.Store
import java.util.Locale

/**
 * UI translation. Every `Text(...)` in the app goes through the wrapper below, which looks the English string up in this table.
 * Order of columns: es | fr | de | pt | ru | uk | ja | zh | it. Strings with no entry stay English (long help sentences, the guide).
 * To add/fix a word: add one line  English::es|fr|de|pt|ru|uk|ja|zh|it
 */
object I18n {
    val languages = listOf("auto" to "Auto", "en" to "English", "es" to "Español", "fr" to "Français", "de" to "Deutsch", "pt" to "Português (Brasil)",
        "it" to "Italiano", "ru" to "Русский", "uk" to "Українська", "ja" to "日本語", "zh" to "中文", "ko" to "한국어", "hi" to "हिन्दी", "tr" to "Türkçe")
    private val order = listOf("es", "fr", "de", "pt", "ru", "uk", "ja", "zh", "it")
    private val extra = listOf("ko", "hi", "tr")   // second table (columns: ko | hi | tr)

    fun current(): String { val s = Store.s("lang", "auto"); val l = if (s == "auto") Locale.getDefault().language else s; return if (l in order || l in extra) l else "en" }

    private val table: Map<String, List<String>> by lazy {
        RAW.lines().filter { "::" in it }.associate { ln -> val k = ln.substringBefore("::"); k to ln.substringAfter("::").split('|') }
    }
    fun tr(s: String): String { val l = current(); if (l == "en") return s; val i = order.indexOf(l); if (i >= 0) return table[s]?.getOrNull(i) ?: s; return table2[s]?.getOrNull(extra.indexOf(l)) ?: s }

    private const val RAW = """
GAMES::JUEGOS|JEUX|SPIELE|JOGOS|ИГРЫ|ІГРИ|ゲーム|游戏|GIOCHI
MINI-GAMES::MINIJUEGOS|MINI-JEUX|MINISPIELE|MINIJOGOS|МИНИ-ИГРЫ|МІНІ-ІГРИ|ミニゲーム|小游戏|MINIGIOCHI
MUSIC::MÚSICA|MUSIQUE|MUSIK|MÚSICA|МУЗЫКА|МУЗИКА|音楽|音乐|MUSICA
CUSTOMIZE::PERSONALIZAR|PERSONNALISER|ANPASSEN|PERSONALIZAR|ВНЕШНИЙ ВИД|ВИГЛЯД|カスタマイズ|自定义|PERSONALIZZA
SETTINGS::AJUSTES|RÉGLAGES|EINSTELLUNGEN|AJUSTES|НАСТРОЙКИ|НАЛАШТУВАННЯ|設定|设置|IMPOSTAZIONI
GENERAL::GENERAL|GÉNÉRAL|ALLGEMEIN|GERAL|ОБЩИЕ|ЗАГАЛЬНІ|一般|常规|GENERALI
VIDEO::VÍDEO|VIDÉO|VIDEO|VÍDEO|ВИДЕО|ВІДЕО|映像|视频|VIDEO
AUDIO::AUDIO|AUDIO|AUDIO|ÁUDIO|ЗВУК|ЗВУК|サウンド|音频|AUDIO
HAPTICS::VIBRACIÓN|VIBRATIONS|VIBRATION|VIBRAÇÃO|ВИБРАЦИЯ|ВІБРАЦІЯ|振動|振动|VIBRAZIONE
CONTROLLERS::MANDOS|MANETTES|CONTROLLER|CONTROLES|ГЕЙМПАДЫ|ГЕЙМПАДИ|コントローラー|手柄|CONTROLLER
LAUNCHER SOUNDS::SONIDOS DEL MENÚ|SONS DU MENU|MENÜ-SOUNDS|SONS DO MENU|ЗВУКИ МЕНЮ|ЗВУКИ МЕНЮ|メニュー音|菜单音效|SUONI DEL MENU
DATA & PRIVACY::DATOS Y PRIVACIDAD|DONNÉES ET CONFIDENTIALITÉ|DATEN & DATENSCHUTZ|DADOS E PRIVACIDADE|ДАННЫЕ И ПРИВАТНОСТЬ|ДАНІ ТА ПРИВАТНІСТЬ|データとプライバシー|数据与隐私|DATI E PRIVACY
ABOUT APP::ACERCA DE|À PROPOS|INFO|SOBRE|О ПРИЛОЖЕНИИ|ПРО ЗАСТОСУНОК|このアプリについて|关于|INFO
UPDATES::NOVEDADES|NOUVEAUTÉS|UPDATES|NOVIDADES|ОБНОВЛЕНИЯ|ОНОВЛЕННЯ|アップデート|更新|NOVITÀ
SKINS::TEMAS|THÈMES|DESIGNS|TEMAS|ТЕМЫ|ТЕМИ|スキン|皮肤|TEMI
FRAME & SHADER::MARCO Y SHADER|CADRE ET SHADER|RAHMEN & SHADER|MOLDURA E SHADER|РАМКА И ШЕЙДЕР|РАМКА І ШЕЙДЕР|枠とシェーダー|边框与着色器|CORNICE E SHADER
CONTROLS::CONTROLES|COMMANDES|STEUERUNG|CONTROLES|УПРАВЛЕНИЕ|КЕРУВАННЯ|操作|操控|COMANDI
BACKGROUNDS::FONDOS|FONDS|HINTERGRÜNDE|FUNDOS|ФОНЫ|ФОНИ|背景|背景图|SFONDI
LIBRARY::BIBLIOTECA|BIBLIOTHÈQUE|BIBLIOTHEK|BIBLIOTECA|БИБЛИОТЕКА|БІБЛІОТЕКА|ライブラリ|游戏库|LIBRERIA
+ ADD GAME::+ AÑADIR JUEGO|+ AJOUTER UN JEU|+ SPIEL HINZUFÜGEN|+ ADICIONAR JOGO|+ ДОБАВИТЬ ИГРУ|+ ДОДАТИ ГРУ|+ ゲームを追加|+ 添加游戏|+ AGGIUNGI GIOCO
▶  PLAY::▶  JUGAR|▶  JOUER|▶  SPIELEN|▶  JOGAR|▶  ИГРАТЬ|▶  ГРАТИ|▶  プレイ|▶  开始|▶  GIOCA
🖼 BACKGROUND::🖼 FONDO|🖼 FOND|🖼 HINTERGRUND|🖼 FUNDO|🖼 ФОН|🖼 ФОН|🖼 背景|🖼 背景|🖼 SFONDO
🏷 LOGO::🏷 LOGO|🏷 LOGO|🏷 LOGO|🏷 LOGO|🏷 ЛОГОТИП|🏷 ЛОГОТИП|🏷 ロゴ|🏷 标志|🏷 LOGO
RESET ART::RESTABLECER ARTE|RÉINITIALISER|BILDER ZURÜCKSETZEN|REDEFINIR ARTE|СБРОСИТЬ ОФОРМЛЕНИЕ|СКИНУТИ ОФОРМЛЕННЯ|画像をリセット|重置图片|RIPRISTINA GRAFICA
✎ EDIT::✎ EDITAR|✎ MODIFIER|✎ BEARBEITEN|✎ EDITAR|✎ ИЗМЕНИТЬ|✎ ЗМІНИТИ|✎ 編集|✎ 编辑|✎ MODIFICA
🗑 REMOVE::🗑 QUITAR|🗑 SUPPRIMER|🗑 ENTFERNEN|🗑 REMOVER|🗑 УДАЛИТЬ|🗑 ВИДАЛИТИ|🗑 削除|🗑 移除|🗑 RIMUOVI
🩹 PATCH::🩹 PARCHE|🩹 PATCH|🩹 PATCH|🩹 PATCH|🩹 ПАТЧ|🩹 ПАТЧ|🩹 パッチ|🩹 补丁|🩹 PATCH
📁 SCAN FOLDER::📁 ESCANEAR CARPETA|📁 SCANNER LE DOSSIER|📁 ORDNER SCANNEN|📁 ESCANEAR PASTA|📁 СКАН ПАПКИ|📁 СКАН ПАПКИ|📁 フォルダをスキャン|📁 扫描文件夹|📁 SCANSIONA CARTELLA
📁 LINK FOLDER::📁 VINCULAR CARPETA|📁 LIER UN DOSSIER|📁 ORDNER VERKNÜPFEN|📁 VINCULAR PASTA|📁 ПРИВЯЗАТЬ ПАПКУ|📁 ПРИВ'ЯЗАТИ ПАПКУ|📁 フォルダを登録|📁 关联文件夹|📁 COLLEGA CARTELLA
ABOUT THE GAME::SOBRE EL JUEGO|À PROPOS DU JEU|ÜBER DAS SPIEL|SOBRE O JOGO|ОБ ИГРЕ|ПРО ГРУ|ゲームについて|游戏简介|SUL GIOCO
Edit game::Editar juego|Modifier le jeu|Spiel bearbeiten|Editar jogo|Изменить игру|Змінити гру|ゲームを編集|编辑游戏|Modifica gioco
Save::Guardar|Enregistrer|Speichern|Salvar|Сохранить|Зберегти|保存|保存|Salva
Cancel::Cancelar|Annuler|Abbrechen|Cancelar|Отмена|Скасувати|キャンセル|取消|Annulla
Remove::Quitar|Supprimer|Entfernen|Remover|Удалить|Видалити|削除|移除|Rimuovi
Language::Idioma|Langue|Sprache|Idioma|Язык|Мова|言語|语言|Lingua
Performance::Rendimiento|Performances|Leistung|Desempenho|Производительность|Продуктивність|パフォーマンス|性能|Prestazioni
Show FPS counter::Mostrar contador FPS|Afficher le compteur FPS|FPS-Anzeige|Mostrar contador de FPS|Показывать FPS|Показувати FPS|FPS表示|显示帧率|Mostra contatore FPS
Orientation::Orientación|Orientation|Ausrichtung|Orientação|Ориентация|Орієнтація|画面の向き|屏幕方向|Orientamento
Launcher::Lanzador|Lanceur|Launcher|Lançador|Лаунчер|Лаунчер|ランチャー|启动器|Launcher
Game::Juego|Jeu|Spiel|Jogo|Игра|Гра|ゲーム|游戏|Gioco
Fun::Diversión|Fun|Spaß|Diversão|Развлечения|Розваги|お楽しみ|趣味|Divertimento
Volumes (independent)::Volúmenes (independientes)|Volumes (indépendants)|Lautstärken (unabhängig)|Volumes (independentes)|Громкость (отдельно)|Гучність (окремо)|音量（個別）|音量（独立）|Volumi (indipendenti)
Music player::Reproductor|Lecteur de musique|Musikplayer|Player de música|Музыкальный плеер|Музичний плеєр|ミュージックプレイヤー|音乐播放器|Lettore musicale
Game audio::Audio del juego|Son du jeu|Spielton|Áudio do jogo|Звук игры|Звук гри|ゲーム音|游戏音频|Audio di gioco
Launcher / UI sounds::Sonidos de menú|Sons du menu|Menü-Sounds|Sons do menu|Звуки меню|Звуки меню|メニュー音|菜单音效|Suoni del menu
Enabled::Activado|Activé|Aktiv|Ativado|Включено|Увімкнено|有効|启用|Attivo
Strength::Intensidad|Intensité|Stärke|Intensidade|Сила|Сила|強さ|强度|Intensità
TEST::PROBAR|TESTER|TESTEN|TESTAR|ТЕСТ|ТЕСТ|テスト|测试|PROVA
Off::No|Désactivé|Aus|Desligado|Выкл|Вимк|オフ|关|Off
Light::Suave|Léger|Leicht|Leve|Слабая|Слабка|弱|轻|Leggera
Medium::Media|Moyen|Mittel|Média|Средняя|Середня|中|中|Media
Strong::Fuerte|Fort|Stark|Forte|Сильная|Сильна|強|强|Forte
Native::Nativa|Natif|Nativ|Nativo|Родная|Рідна|標準|原生|Nativa
Detected controllers::Mandos detectados|Manettes détectées|Erkannte Controller|Controles detectados|Найденные геймпады|Знайдені геймпади|検出されたコントローラー|检测到的手柄|Controller rilevati
Button mapping::Asignación de botones|Attribution des boutons|Tastenbelegung|Mapeamento de botões|Назначение кнопок|Призначення кнопок|ボタン割り当て|按键映射|Mappatura tasti
REBIND::ASIGNAR|ASSIGNER|ZUWEISEN|REDEFINIR|НАЗНАЧИТЬ|ПРИЗНАЧИТИ|割り当て|重设|ASSEGNA
RESET ALL TO DEFAULT::RESTABLECER TODO|TOUT RÉINITIALISER|ALLES ZURÜCKSETZEN|REDEFINIR TUDO|СБРОСИТЬ ВСЁ|СКИНУТИ ВСЕ|すべて初期化|全部重置|RIPRISTINA TUTTO
Privacy::Privacidad|Confidentialité|Datenschutz|Privacidade|Конфиденциальность|Приватність|プライバシー|隐私|Privacy
Storage::Almacenamiento|Stockage|Speicher|Armazenamento|Хранилище|Сховище|ストレージ|存储|Archiviazione
Game frame::Marco del juego|Cadre du jeu|Spielrahmen|Moldura do jogo|Рамка игры|Рамка гри|ゲーム枠|游戏边框|Cornice di gioco
Shader::Shader|Shader|Shader|Shader|Шейдер|Шейдер|シェーダー|着色器|Shader
Border style::Estilo de borde|Style de bordure|Rahmenstil|Estilo da borda|Стиль рамки|Стиль рамки|枠のスタイル|边框样式|Stile bordo
Border colour::Color del borde|Couleur de bordure|Rahmenfarbe|Cor da borda|Цвет рамки|Колір рамки|枠の色|边框颜色|Colore bordo
Thickness::Grosor|Épaisseur|Dicke|Espessura|Толщина|Товщина|太さ|粗细|Spessore
Corner radius::Radio de esquina|Rayon des coins|Eckenradius|Raio dos cantos|Скругление|Заокруглення|角の丸み|圆角|Raggio angoli
Touch controls editor::Editor de controles táctiles|Éditeur des commandes tactiles|Touch-Steuerung bearbeiten|Editor de controles de toque|Редактор сенсорных кнопок|Редактор сенсорних кнопок|タッチ操作エディター|触控编辑器|Editor comandi touch
LANDSCAPE::HORIZONTAL|PAYSAGE|QUERFORMAT|PAISAGEM|АЛЬБОМНАЯ|АЛЬБОМНА|横向き|横屏|ORIZZONTALE
PORTRAIT::VERTICAL|PORTRAIT|HOCHFORMAT|RETRATO|КНИЖНАЯ|КНИЖКОВА|縦向き|竖屏|VERTICALE
D-PAD::CRUCETA|CROIX|STEUERKREUZ|D-PAD|КРЕСТОВИНА|ХРЕСТОВИНА|十字キー|十字键|CROCE
ANALOG STICK::JOYSTICK|JOYSTICK|ANALOGSTICK|ANALÓGICO|СТИК|СТИК|アナログスティック|摇杆|STICK ANALOGICO
Opacity::Opacidad|Opacité|Deckkraft|Opacidade|Прозрачность|Прозорість|不透明度|不透明度|Opacità
Presets (6 slots)::Preajustes (6 ranuras)|Préréglages (6 emplacements)|Vorlagen (6 Plätze)|Predefinições (6 slots)|Пресеты (6 слотов)|Пресети (6 слотів)|プリセット（6枠）|预设（6个）|Preset (6 slot)
SAVE CURRENT TO::GUARDAR EN|ENREGISTRER DANS|SPEICHERN IN|SALVAR EM|СОХРАНИТЬ В|ЗБЕРЕГТИ В|保存先|保存到|SALVA IN
PAUSED::PAUSA|PAUSE|PAUSE|PAUSADO|ПАУЗА|ПАУЗА|一時停止|暂停|PAUSA
▶ RESUME::▶ CONTINUAR|▶ REPRENDRE|▶ WEITER|▶ CONTINUAR|▶ ПРОДОЛЖИТЬ|▶ ПРОДОВЖИТИ|▶ 再開|▶ 继续|▶ RIPRENDI
RESET::REINICIAR|RÉINITIALISER|ZURÜCKSETZEN|REINICIAR|СБРОС|СКИДАННЯ|リセット|重置|RESET
QUIT::SALIR|QUITTER|BEENDEN|SAIR|ВЫЙТИ|ВИЙТИ|終了|退出|ESCI
Display::Pantalla|Affichage|Anzeige|Tela|Экран|Екран|表示|显示|Schermo
+ ADD MUSIC::+ AÑADIR MÚSICA|+ AJOUTER DE LA MUSIQUE|+ MUSIK HINZUFÜGEN|+ ADICIONAR MÚSICA|+ ДОБАВИТЬ МУЗЫКУ|+ ДОДАТИ МУЗИКУ|+ 音楽を追加|+ 添加音乐|+ AGGIUNGI MUSICA
RESCAN::ESCANEAR|RE-SCANNER|NEU SCANNEN|REESCANEAR|ОБНОВИТЬ|ОНОВИТИ|再スキャン|重新扫描|RISCANSIONA
◀ BACK::◀ ATRÁS|◀ RETOUR|◀ ZURÜCK|◀ VOLTAR|◀ НАЗАД|◀ НАЗАД|◀ 戻る|◀ 返回|◀ INDIETRO
GAME OVER::FIN DEL JUEGO|PARTIE TERMINÉE|SPIEL VORBEI|FIM DE JOGO|ИГРА ОКОНЧЕНА|ГРУ ЗАКІНЧЕНО|ゲームオーバー|游戏结束|GAME OVER
RETRY::REINTENTAR|RÉESSAYER|NOCHMAL|TENTAR DE NOVO|ЕЩЁ РАЗ|ЩЕ РАЗ|リトライ|重试|RIPROVA
CHOOSE::ELEGIR|CHOISIR|WÄHLEN|ESCOLHER|ВЫБРАТЬ|ОБРАТИ|選択|选择|SCEGLI
CHOOSE IMAGE::ELEGIR IMAGEN|CHOISIR UNE IMAGE|BILD WÄHLEN|ESCOLHER IMAGEM|ВЫБРАТЬ ФОТО|ОБРАТИ ЗОБРАЖЕННЯ|画像を選択|选择图片|SCEGLI IMMAGINE
CLEAR::BORRAR|EFFACER|LÖSCHEN|LIMPAR|УБРАТЬ|ПРИБРАТИ|クリア|清除|CANCELLA
SAVE::GUARDAR|GUARDER|SPEICHERN|SALVAR|СОХРАНИТЬ|ЗБЕРЕГТИ|保存|保存|SALVA
LOAD::CARGAR|CHARGER|LADEN|CARREGAR|ЗАГРУЗИТЬ|ЗАВАНТАЖИТИ|ロード|读取|CARICA
SKIP::OMITIR|PASSER|ÜBERSPRINGEN|PULAR|ПРОПУСТИТЬ|ПРОПУСТИТИ|スキップ|跳过|SALTA
NEXT::SIGUIENTE|SUIVANT|WEITER|PRÓXIMO|ДАЛЕЕ|ДАЛІ|次へ|下一步|AVANTI
DONE::LISTO|TERMINÉ|FERTIG|CONCLUIR|ГОТОВО|ГОТОВО|完了|完成|FATTO
OPEN GUIDE::ABRIR GUÍA|OUVRIR LE GUIDE|ANLEITUNG ÖFFNEN|ABRIR GUIA|ОТКРЫТЬ ГИД|ВІДКРИТИ ГІД|ガイドを開く|打开指南|APRI GUIDA
EXPORT BACKUP::EXPORTAR COPIA|EXPORTER LA SAUVEGARDE|BACKUP EXPORTIEREN|EXPORTAR BACKUP|ЭКСПОРТ КОПИИ|ЕКСПОРТ КОПІЇ|バックアップを書き出す|导出备份|ESPORTA BACKUP
IMPORT BACKUP::IMPORTAR COPIA|IMPORTER LA SAUVEGARDE|BACKUP IMPORTIEREN|IMPORTAR BACKUP|ИМПОРТ КОПИИ|ІМПОРТ КОПІЇ|バックアップを読み込む|导入备份|IMPORTA BACKUP
LOCATIONS::UBICACIONES|EMPLACEMENTS|ORTE|LOCAIS|РАСПОЛОЖЕНИЕ|РОЗТАШУВАННЯ|場所|位置|POSIZIONI
HELP::AYUDA|AIDE|HILFE|AJUDA|ПОМОЩЬ|ДОПОМОГА|ヘルプ|帮助|AIUTO
VIBRATION::VIBRACIÓN|VIBRATIONS|VIBRATION|VIBRAÇÃO|ВИБРАЦИЯ|ВІБРАЦІЯ|振動|振动|VIBRAZIONE
APPEARANCE::APARIENCIA|APPARENCE|AUSSEHEN|APARÊNCIA|ВНЕШНИЙ ВИД|ВИГЛЯД|外観|外观|ASPETTO
Welcome to SonicForge::Bienvenido a SonicForge|Bienvenue dans SonicForge|Willkommen bei SonicForge|Bem-vindo ao SonicForge|Добро пожаловать в SonicForge|Ласкаво просимо до SonicForge|SonicForgeへようこそ|欢迎来到 SonicForge|Benvenuto in SonicForge
SCREEN & LOOK::PANTALLA Y ASPECTO|ÉCRAN ET APPARENCE|BILD & LOOK|TELA E VISUAL|ЭКРАН И ВИД|ЕКРАН І ВИГЛЯД|画面と外観|屏幕与外观|SCHERMO E ASPETTO
SOUND & MUSIC::SONIDO Y MÚSICA|SON ET MUSIQUE|TON & MUSIK|SOM E MÚSICA|ЗВУК И МУЗЫКА|ЗВУК І МУЗИКА|サウンドと音楽|声音与音乐|SUONO E MUSICA
ABOUT & UPDATES::ACERCA Y NOVEDADES|À PROPOS ET MISES À JOUR|INFO & UPDATES|SOBRE E NOVIDADES|О ПРИЛОЖЕНИИ И ОБНОВЛЕНИЯ|ПРО ЗАСТОСУНОК І ОНОВЛЕННЯ|アプリ情報と更新|关于与更新|INFO E NOVITÀ
DRAW::DIBUJAR|DESSIN|ZEICHNEN|DESENHAR|РИСОВАЛКА|МАЛЮВАННЯ|お絵かき|绘图|DISEGNO
Games: bring your own::Juegos: trae los tuyos|Jeux : apportez les vôtres|Spiele: bring deine eigenen mit|Jogos: traga os seus|Игры: свои собственные|Ігри: ваші власні|ゲーム：自分のROMを持ち込もう|游戏：自带游戏|Giochi: porta i tuoi
What makes this launcher different::Qué hace diferente a este lanzador|Ce qui rend ce lanceur différent|Was diesen Launcher besonders macht|O que torna este launcher diferente|Чем этот лаунчер отличается|Чим цей лаунчер відрізняється|このランチャーの特徴|这个启动器的与众不同之处|Cosa rende diverso questo launcher
Meet the helpers::Conoce a los ayudantes|Rencontrez les assistants|Lerne die Helfer kennen|Conheça os ajudantes|Знакомьтесь: помощники|Знайомтеся: помічники|ヘルパーたちを紹介|认识小帮手|Conosci gli aiutanti
Make it yours::Hazlo tuyo|Personnalisez-le|Mach es zu deinem|Deixe com a sua cara|Настройте под себя|Налаштуйте під себе|自分好みにしよう|打造你的专属风格|Rendilo tuo
Music, files & safety::Música, archivos y seguridad|Musique, fichiers et sécurité|Musik, Dateien & Sicherheit|Música, arquivos e segurança|Музыка, файлы и безопасность|Музика, файли та безпека|音楽・ファイル・安全|音乐、文件与安全|Musica, file e sicurezza
Questions? Ask a helper::¿Preguntas? Pregunta a un ayudante|Des questions ? Demandez à un assistant|Fragen? Frag einen Helfer|Dúvidas? Pergunte a um ajudante|Есть вопросы? Спросите помощника|Є питання? Запитайте помічника|質問は？ヘルパーに聞こう|有问题？问问小帮手|Domande? Chiedi a un aiutante
"""

    private val table2: Map<String, List<String>> by lazy { RAW2.lines().filter { "::" in it }.associate { ln -> ln.substringBefore("::") to ln.substringAfter("::").split('|') } }
    private const val RAW2 = """
DRAW::그리기|चित्रकारी|ÇİZİM
Games: bring your own::게임: 직접 가져오세요|गेम्स: अपने खुद के लाएँ|Oyunlar: kendi oyunlarınızı getirin
What makes this launcher different::이 런처가 특별한 점|यह लॉन्चर अलग क्यों है|Bu başlatıcıyı farklı kılan şey
Meet the helpers::도우미를 만나보세요|सहायकों से मिलें|Yardımcılarla tanışın
Make it yours::나만의 스타일로|इसे अपना बनाएँ|Kendinize göre ayarlayın
Music, files & safety::음악, 파일 및 안전|संगीत, फ़ाइलें और सुरक्षा|Müzik, dosyalar ve güvenlik
Questions? Ask a helper::질문이 있나요? 도우미에게 물어보세요|सवाल हैं? किसी सहायक से पूछें|Sorunuz mu var? Bir yardımcıya sorun
Welcome to SonicForge::SonicForge에 오신 것을 환영합니다|SonicForge में आपका स्वागत है|SonicForge'a hoş geldiniz
SCREEN & LOOK::화면 및 외관|स्क्रीन और रूप|EKRAN VE GÖRÜNÜM
SOUND & MUSIC::사운드 및 음악|ध्वनि और संगीत|SES VE MÜZİK
ABOUT & UPDATES::앱 정보 및 업데이트|ऐप जानकारी और अपडेट|HAKKINDA VE GÜNCELLEMELER
GAMES::게임|गेम्स|OYUNLAR
MINI-GAMES::미니게임|मिनी-गेम्स|MİNİ OYUNLAR
MUSIC::음악|संगीत|MÜZİK
CUSTOMIZE::꾸미기|अनुकूलन|ÖZELLEŞTİR
SETTINGS::설정|सेटिंग्स|AYARLAR
HELP::도움말|सहायता|YARDIM
LOCATIONS::위치|स्थान|KONUMLAR
GENERAL::일반|सामान्य|GENEL
VIDEO::영상|वीडियो|VİDEO
AUDIO::오디오|ऑडियो|SES
VIBRATION::진동|कंपन|TİTREŞİM
CONTROLS::조작|नियंत्रण|KONTROLLER
LAUNCHER SOUNDS::런처 소리|लॉन्चर ध्वनियाँ|BAŞLATICI SESLERİ
APPEARANCE::외형|रूप-रंग|GÖRÜNÜM
DATA & PRIVACY::데이터 및 개인정보|डेटा और गोपनीयता|VERİ VE GİZLİLİK
ABOUT APP::앱 정보|ऐप के बारे में|UYGULAMA HAKKINDA
UPDATES::업데이트|अपडेट|GÜNCELLEMELER
SKINS::스킨|स्किन|TEMALAR
FRAME & SHADER::프레임 및 셰이더|फ्रेम और शेडर|ÇERÇEVE VE GÖLGELENDİRİCİ
BACKGROUNDS::배경|पृष्ठभूमि|ARKA PLANLAR
LIBRARY::라이브러리|लाइब्रेरी|KÜTÜPHANE
+ ADD GAME::+ 게임 추가|+ गेम जोड़ें|+ OYUN EKLE
▶  PLAY::▶  플레이|▶  खेलें|▶  OYNA
✎ EDIT::✎ 편집|✎ संपादित करें|✎ DÜZENLE
Save::저장|सहेजें|Kaydet
Cancel::취소|रद्द करें|İptal
Language::언어|भाषा|Dil
Off::끔|बंद|Kapalı
Enabled::사용|चालू|Etkin
Strength::강도|तीव्रता|Şiddet
TEST::테스트|परीक्षण|TEST
RESET::초기화|रीसेट|SIFIRLA
QUIT::종료|बाहर निकलें|ÇIK
▶ RESUME::▶ 계속|▶ जारी रखें|▶ DEVAM
PAUSED::일시정지|रुका हुआ|DURAKLATILDI
SAVE::저장|सहेजें|KAYDET
LOAD::불러오기|लोड करें|YÜKLE
SKIP::건너뛰기|छोड़ें|ATLA
NEXT::다음|अगला|İLERİ
DONE::완료|हो गया|TAMAM
OPEN GUIDE::가이드 열기|गाइड खोलें|REHBERİ AÇ
Game::게임|गेम|Oyun
Performance::성능|प्रदर्शन|Performans
Orientation::화면 방향|अभिविन्यास|Yön
Privacy::개인정보|गोपनीयता|Gizlilik
Storage::저장소|संग्रहण|Depolama
Shader::셰이더|शेडर|Gölgelendirici
Opacity::불투명도|अपारदर्शिता|Opaklık
CHOOSE::선택|चुनें|SEÇ
CLEAR::지우기|साफ़ करें|TEMİZLE
"""
}

/** Drop-in replacement for material3 Text that translates static English strings. */
@Composable
fun Text(
    text: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified, fontSize: TextUnit = TextUnit.Unspecified,
    fontWeight: FontWeight? = null, fontFamily: FontFamily? = null, letterSpacing: TextUnit = TextUnit.Unspecified,
    textAlign: TextAlign? = null, maxLines: Int = Int.MAX_VALUE
) {
    Store.settings["lang"]   // read so the UI recomposes when the language changes
    M3Text(text = I18n.tr(text), modifier = modifier, color = color, fontSize = fontSize, fontWeight = fontWeight, fontFamily = fontFamily, letterSpacing = letterSpacing, textAlign = textAlign, maxLines = maxLines)
}
