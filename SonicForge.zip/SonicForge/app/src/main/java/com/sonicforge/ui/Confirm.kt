package com.sonicforge.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Store
import kotlinx.coroutines.delay

/**
 * "Are you sure?" dialog. It says exactly what will happen: [does] (underlined) and what will NOT happen [doesNot] (double-struck look via underline + bold).
 * The YES button unlocks after a short countdown (3 or 5 s). Both the dialog and the delay can be switched off in SETTINGS ▸ GENERAL; turning them off asks for confirmation too.
 */
@Composable
fun ConfirmDialog(title: String, does: String, doesNot: String = "", yes: String = "YES, DO IT", force: Boolean = false, onYes: () -> Unit, onNo: () -> Unit) {
    val mode = Store.s("confirmMode", "3")          // "off" | "3" | "5"
    if (mode == "off" && !force) { LaunchedEffect(Unit) { onYes() }; return }
    val delaySec = if (mode == "5") 5 else if (mode == "3") 3 else 3
    var left by remember { mutableIntStateOf(delaySec) }
    LaunchedEffect(Unit) { while (left > 0) { delay(1000); left-- } }
    AlertDialog(onDismissRequest = onNo, containerColor = Color(0xFF0D0D14), titleContentColor = Color.White, textContentColor = Color.White,
        confirmButton = { TextButton(onYes, enabled = left == 0) { Text(if (left > 0) "$yes ($left)" else yes) } },
        dismissButton = { TextButton(onNo) { Text("CANCEL") } },
        title = { Text(title) },
        text = { Column {
            androidx.compose.material3.Text(buildAnnotatedString { append("This WILL: "); withStyle(SpanStyle(textDecoration = TextDecoration.Underline, fontWeight = FontWeight.Bold)) { append(does) } }, fontSize = 14.sp)
            if (doesNot.isNotEmpty()) androidx.compose.material3.Text(buildAnnotatedString { append("This will NOT: "); withStyle(SpanStyle(textDecoration = TextDecoration.Underline, fontWeight = FontWeight.Bold, color = Color(0xFF80CBC4))) { append(doesNot) } }, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
        } })
}

/** small holder so a button can open a confirmation: `val c = rememberConfirm(); Btn("X") { c.ask(...) }; c.Host()` */
@Stable
class ConfirmState { var open by mutableStateOf(false); var title = ""; var does = ""; var doesNot = ""; var force = false; var action: () -> Unit = {}
    fun ask(title: String, does: String, doesNot: String = "", force: Boolean = false, action: () -> Unit) { this.title = title; this.does = does; this.doesNot = doesNot; this.force = force; this.action = action; open = true }
    @Composable fun Host() { if (open) ConfirmDialog(title, does, doesNot, force = force, onYes = { open = false; action() }, onNo = { open = false }) } }
@Composable fun rememberConfirm() = remember { ConfirmState() }
