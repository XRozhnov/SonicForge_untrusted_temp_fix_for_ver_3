package com.sonicforge.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import com.sonicforge.audio.Sfx
import com.sonicforge.input.Haptics
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Colour presets for the little scene under a game's description: sky, ground and hero colour (ARGB ints). */
data class ScenePreset(val name: String, val sky: Int, val ground: Int, val body: Int)
private fun p(n: String, sky: Long, ground: Long, body: Long = 0xFF1E88E5) = ScenePreset(n, sky.toInt(), ground.toInt(), body.toInt())
val SCENE_PRESETS = listOf(
    p("Green Hill", 0xFF81D4FA, 0xFF558B2F), p("Marble", 0xFF3E2723, 0xFF6D4C41), p("Spring Yard", 0xFF1A237E, 0xFF7B1FA2), p("Labyrinth", 0xFF004D40, 0xFF00695C),
    p("Star Light (Tails)", 0xFF0D0B2B, 0xFF1A237E, 0xFFFFA000), p("Scrap Brain", 0xFF37474F, 0xFF455A64), p("Emerald Hill", 0xFF4FC3F7, 0xFF2E7D32), p("Chemical Plant", 0xFF3949AB, 0xFF8E24AA),
    p("Aquatic Ruin", 0xFF006064, 0xFF00838F), p("Casino Night", 0xFF1A0033, 0xFF6A1B9A), p("Hill Top", 0xFFFFE0B2, 0xFF8D6E63), p("Mystic Cave", 0xFF263238, 0xFF1B5E20),
    p("Oil Ocean", 0xFFFFB74D, 0xFF455A64), p("Metropolis", 0xFF3E2723, 0xFF5D4037), p("Sky Chase", 0xFF81D4FA, 0xFF0288D1), p("Wing Fortress", 0xFF90A4AE, 0xFF546E7A),
    p("Death Egg", 0xFF0B0B2B, 0xFF37474F), p("Angel Island", 0xFF29B6F6, 0xFF2E7D32, 0xFFE53935), p("Hydrocity", 0xFF0277BD, 0xFF01579B), p("Marble Garden", 0xFFB2DFDB, 0xFF6D4C41),
    p("Carnival Night", 0xFF1A237E, 0xFFAD1457), p("Ice Cap", 0xFFE1F5FE, 0xFF90CAF9), p("Launch Base", 0xFF607D8B, 0xFF455A64), p("Sky Sanctuary", 0xFF4FC3F7, 0xFFB0BEC5),
    p("Hidden Palace", 0xFF311B92, 0xFF00E676), p("Shadow Space", 0xFF0B0B1E, 0xFF4A148C, 0xFF212121), p("Amy's Garden", 0xFFFFE0EC, 0xFF81C784, 0xFFF06292), p("Horror Hill", 0xFF2B0000, 0xFF3B0000),
)

/**
 * The little interactive strip under a game's description: a ball-hero rolls through a scene themed to the game.
 * Rings roll towards the hero and are really collected (score +10 each). Tap the strip for a spin-dash burst.
 */
@Composable
fun MiniScene(kind: String, modifier: Modifier = Modifier, cBody: Int = 0, cSky: Int = 0, cGround: Int = 0) {
    var t by remember { mutableFloatStateOf(0f) }
    var dash by remember { mutableFloatStateOf(0f) }
    var score by remember { mutableIntStateOf(0) }; var collected by remember { mutableIntStateOf(0) }
    var w by remember { mutableFloatStateOf(600f) }; var h by remember { mutableFloatStateOf(200f) }
    val rx = remember { floatArrayOf(300f, 420f, 540f, 660f, 780f, 900f) }
    fun ringY(i: Int) = h * .78f - 22f - 6f * sin(t * 4f + i)
    fun heroY() = h * .78f - 16f - abs(sin(t * 3f)) * 18f * (1f - dash)
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) withFrameNanos { n ->
            if (last != 0L) {
                val d = (n - last) / 1e9f; t += d * (1f + dash * 3f); dash = (dash - d * .8f).coerceAtLeast(0f)
                val speed = (150f + dash * 450f) * d; val px = w * .3f + dash * w * .25f; val py = heroY()
                for (i in rx.indices) {
                    rx[i] -= speed
                    if (rx[i] < -30f) rx[i] = w + 40f + Random.nextFloat() * 200f
                    if (abs(rx[i] - px) < 30f && abs(ringY(i) - py) < 32f) { rx[i] = w + 80f + Random.nextFloat() * 260f; score += 10; collected++ }
                }
            }
            last = n
        }
    }
    val body0 = when (kind) { "metal" -> Color(0xFF90A4AE); "shadow" -> Color(0xFF212121); "amy" -> Color(0xFFF06292); "boom" -> Color(0xFF1E88E5); "exe" -> Color(0xFF0D47A1); else -> Color(0xFF1E88E5) }
    val sky0 = when (kind) { "exe" -> Color(0xFF2B0000); "shadow" -> Color(0xFF1A0A1F); "metal" -> Color(0xFF263238); "amy" -> Color(0xFFFFE0EC); "score" -> Color(0xFF1A237E); "heroes" -> Color(0xFF80DEEA); else -> Color(0xFF81D4FA) }
    val ground0 = when (kind) { "exe" -> Color(0xFF3B0000); "shadow" -> Color(0xFF4A148C); "metal" -> Color(0xFF455A64); "amy" -> Color(0xFF81C784); "score" -> Color(0xFF283593); else -> Color(0xFF558B2F) }
    val body = if (cBody != 0) Color(cBody) else body0; val sky = if (cSky != 0) Color(cSky) else sky0; val ground = if (cGround != 0) Color(cGround) else ground0
    Canvas(modifier.fillMaxWidth().height(84.dp).onSizeChanged { w = it.width.toFloat(); h = it.height.toFloat() }.clickable { dash = 1f; Haptics.ui() }) {
        val gy = size.height * .78f
        drawRect(sky, Offset.Zero, size); drawRect(ground, Offset(0f, gy), Size(size.width, size.height - gy))
        for (i in 0 until 14) { val x = ((i * 53f - t * 90f) % (size.width + 20f) + size.width + 20f) % (size.width + 20f); drawRect(ground.copy(alpha = .6f), Offset(x, gy), Size(12f, 6f)) }
        for (i in rx.indices) drawCircle(if (kind == "exe") Color(0xFFB71C1C) else Color(0xFFFFD54F), 9f, Offset(rx[i], ringY(i)), style = Stroke(3.5f))
        val px = size.width * .3f + dash * size.width * .25f; val py = heroY()
        rotate(t * 720f, Offset(px, py)) {
            drawCircle(body, 15f, Offset(px, py))
            for (k in 0 until 5) { val a = k * 1.2566f; drawLine(body, Offset(px, py), Offset(px + 24f * cos(a), py + 24f * sin(a)), 7f) }
            drawCircle(Color(0xFFFFE0B2), 8f, Offset(px + 4f, py + 3f))
        }
        if (kind == "exe" && (t * 2f) % 3f < .25f) { drawCircle(Color.Red, 4f, Offset(px - 4f, py - 3f)); drawCircle(Color.Red, 4f, Offset(px + 6f, py - 3f)) }
        if (kind == "heroes") { drawCircle(Color(0xFFFFB300), 10f, Offset(px - 34f, py + 6f)); drawCircle(Color(0xFFE53935), 10f, Offset(px - 62f, py + 6f)) }
        drawContext.canvas.nativeCanvas.drawText("RINGS $collected   SCORE $score", 10f, 24f, android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 26f; isFakeBoldText = true; setShadowLayer(4f, 0f, 0f, android.graphics.Color.BLACK) })
    }
}
