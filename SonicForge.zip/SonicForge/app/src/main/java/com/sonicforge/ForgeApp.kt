package com.sonicforge

import android.app.Application
import com.sonicforge.audio.Music
import com.sonicforge.audio.Sfx
import com.sonicforge.data.*
import com.sonicforge.input.Haptics
import com.sonicforge.input.Pads
import kotlinx.coroutines.launch

class ForgeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Logger.init(this)
        Library.init(this)
        PadLayouts.init()
        Sfx.init(this)
        Haptics.init(this)
        Pads.init(this)
        Music.init(this)
        Logger.startWatchdog()
        Logger.reportLastExit(this)
        // every pop-up text is also kept in the log, in full
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Default + kotlinx.coroutines.SupervisorJob()).launch { Store.events.collect { Logger.notice(it.label, it.ok) } }
    }
}
