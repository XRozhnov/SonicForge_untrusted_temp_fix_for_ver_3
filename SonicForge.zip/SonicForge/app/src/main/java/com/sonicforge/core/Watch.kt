package com.sonicforge.core

import com.sonicforge.data.Store

/** Work-RAM addresses (offsets inside the 64 KB 68000 RAM, i.e. $FFxxxx) for reading what the game is doing. Best-effort: ROM hacks can differ. */
data class RamProfile(
    val rings: Int, val lives: Int, val air: Int = -1, val player: Int = -1, val tails: Int = -1,
    val statusOff: Int = 0x22, val animOff: Int = 0x1C, val spin: Int = -1, val spring: Int = 0x10,
    val hurt: Int = -1, val death: Int = -1, val drown: Int = -1, val fly: Int = -1,
    val secOff: Int = -1,                       // status_secondary byte inside the player object (bit0 shield, 1 invincible, 2 speed shoes, 3 fire, 4 lightning, 5 bubble)
    val shield: Int = -1, val invinc: Int = -1, val shoes: Int = -1,   // Sonic 1 keeps these as global bytes
    val inertiaOff: Int = -1                    // ground speed (signed word) inside the player object, used for the experimental footsteps
)

object Watch {
    val s1 = RamProfile(0xFE20, 0xFE12, air = 0xFE14, player = 0xD000, spring = 0x10, hurt = 0x1A, death = 0x18, drown = 0x17, shield = 0xFE2C, invinc = 0xFE2D, shoes = 0xFE2E, inertiaOff = 0x14)
    val s2 = RamProfile(0xFE20, 0xFE12, player = 0xB000, tails = 0xB040, spin = 9, spring = 0x10, hurt = 0x19, death = 0x18, drown = 0x17, fly = 0x20, secOff = 0x2B, inertiaOff = 0x14)
    val s3k = RamProfile(0xFE20, 0xFE12)                                                   // safe: rings + lives only
    val s3kx = RamProfile(0xFE20, 0xFE12, player = 0xB000, statusOff = 0x2A, animOff = 0x20, spin = 9, spring = 0x10, secOff = 0x2B)   // experimental: offsets from memory of the S3K disassembly
    fun byId(id: String, ringsAddr: Int, livesAddr: Int): RamProfile? = when (id) {
        "s1" -> s1; "s2" -> s2; "s3k" -> s3k; "s3kx" -> s3kx; "off" -> null
        else -> if (ringsAddr >= 0) RamProfile(ringsAddr, livesAddr) else null
    }
}

/** Polls the profile's addresses and reports: ring, hurt, death, oneup, jump, spin, spring, fly, drown, bite, drain, shield, invinc, shoes, fizz, zap, step. */
class Watcher(private val p: RamProfile) {
    private var rings = 0; private var lives = -1; private var anim = -1; private var air = -1; private var inAir = false; private var flyTick = 0
    private var flags = 0; private var lastAir = -1; private var draining = 0; private var stepTick = 0
    private fun b(a: ByteArray, base: Int, addr: Int) = a[(addr - base) xor 1].toInt() and 0xFF   // RAM is byte-swapped per word on little-endian hosts

    fun poll(read: (Int, Int) -> ByteArray?, emit: (String) -> Unit) {
        val g = read(0xFE00, 0x100) ?: return
        val nr = (b(g, 0xFE00, p.rings) shl 8) or b(g, 0xFE00, p.rings + 1)
        val nl = if (p.lives >= 0) b(g, 0xFE00, p.lives) else lives
        if (p.air >= 0) air = (b(g, 0xFE00, p.air) shl 8) or b(g, 0xFE00, p.air + 1)
        var an = -1; var st = 0; var o: ByteArray? = null
        if (p.player >= 0) { o = read(p.player, 0x60); if (o != null) { an = b(o, p.player, p.player + p.animOff); st = b(o, p.player, p.player + p.statusOff) } }
        val hurtNow = p.hurt >= 0 && an == p.hurt

        // rings: pickup, scatter on hit, or a small steady drain (robot piranhas and other ring-stealers)
        if (lives >= 0 && nl > lives) emit("oneup")
        if (lives >= 0 && nl < lives) emit("death")
        else if (nr > rings) { emit("ring"); draining = 0 }
        else if (nr < rings && !hurtNow) {
            val d = rings - nr
            if (d in 1..3 && nr > 0 || (d in 1..3 && rings <= 3)) { emit(if (draining == 0) "bite" else "drain"); draining = 8 }
            else if (p.hurt < 0 && rings > 0 && nr == 0) emit("hurt")
        }
        if (draining > 0 && nr == rings) draining--
        rings = nr; lives = nl

        if (o != null) {
            val air2 = (st and 0x02) != 0
            if (an != anim) { when (an) { p.hurt -> emit("hurt"); p.death -> emit("death"); p.spin -> emit("spin"); p.spring -> emit("spring") }; anim = an }
            if (air2 && !inAir && an == 2) emit("jump")
            inAir = air2
            if ((st and 0x40) != 0 && air in 1..12 && air != lastAir) emit("drown")
            lastAir = air
            // shields & power-ups
            var f = 0
            if (p.secOff >= 0) f = b(o, p.player, p.player + p.secOff) and 0x3F
            else if (p.shield >= 0) { if (b(g, 0xFE00, p.shield) != 0) f = f or 1; if (b(g, 0xFE00, p.invinc) != 0) f = f or 2; if (b(g, 0xFE00, p.shoes) != 0) f = f or 4 }
            val gained = f and flags.inv(); val lost = flags and f.inv()
            if (gained and 1 != 0 || gained and 0x28 != 0 || gained and 0x10 != 0) emit("shield")
            if (gained and 2 != 0) emit("invinc")
            if (gained and 4 != 0) emit("shoes")
            if ((st and 0x40) != 0) { if (lost and 8 != 0) emit("fizz"); if (lost and 16 != 0) emit("zap") }   // fire goes out / lightning discharges in water
            flags = f
            // experimental footsteps: pace follows ground speed (faster with speed shoes)
            if (p.inertiaOff >= 0 && Store.b("hapSteps", false) && !air2) {
                val v = Math.abs(((b(o, p.player, p.player + p.inertiaOff) shl 8) or b(o, p.player, p.player + p.inertiaOff + 1)).toShort().toInt())
                if (v > 0x100) { val pace = (0x1400 / v.coerceAtLeast(0x100) * Store.i("hapStepCal", 100) / 100 * 2).coerceIn(2, 14); if (stepTick++ >= pace) { stepTick = 0; emit("step") } } else stepTick = 0
            }
        }
        if (p.tails >= 0 && p.fly >= 0) read(p.tails, 0x60)?.let { t -> if (b(t, p.tails, p.tails + p.animOff) == p.fly) { if (flyTick++ % 9 == 0) emit("fly") } else flyTick = 0 }
    }
}
