package com.sonicforge.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as ACanvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.os.Build
import android.provider.MediaStore
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Logger
import com.sonicforge.data.SaveEvent
import com.sonicforge.data.Store
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Pixel-art / drawing canvas. Layers (visibility, opacity, clipping to the layer below), pencil / eraser / fill / eyedropper,
 * paste a picture onto a layer or as a new layer, canvas resize (crop or extend), undo, export to PNG. The drawing is saved on its own and reopens next time.
 */
object Draw {
    class Layer(var name: String, var bmp: Bitmap, var visible: Boolean = true, var opacity: Int = 100, var clip: Boolean = false)
    const val MAX = 512
    var w by mutableIntStateOf(64); var h by mutableIntStateOf(64)
    val layers = mutableStateListOf<Layer>()
    var active by mutableIntStateOf(0)
    var color by mutableIntStateOf(0xFF1E88E5.toInt())
    var tool by mutableStateOf("pencil")
    var brush by mutableIntStateOf(1)
    var grid by mutableStateOf(true)
    var version by mutableIntStateOf(0)
    private val undoStack = ArrayList<Pair<Int, Bitmap>>()
    private var loaded = false
    val recent = mutableStateListOf<Int>()

    fun bump() { version++ }
    fun newCanvas(nw: Int, nh: Int) {
        w = nw.coerceIn(1, MAX); h = nh.coerceIn(1, MAX); layers.clear(); layers.add(Layer("Layer 1", Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))); active = 0; undoStack.clear(); bump()
    }
    private fun cur(): Layer? = layers.getOrNull(active)
    private fun baseIndex(i: Int): Int { var b = i - 1; while (b >= 0 && layers[b].clip) b--; return b }

    // ---- undo ----
    fun begin() { val l = cur() ?: return; undoStack.add(active to l.bmp.copy(Bitmap.Config.ARGB_8888, true)); if (undoStack.size > 30) undoStack.removeAt(0) }
    fun undo() { val (i, b) = undoStack.removeLastOrNull() ?: return; if (i in layers.indices && b.width == layers[i].bmp.width && b.height == layers[i].bmp.height) { layers[i].bmp = b; bump() } }
    val canUndo get() = undoStack.isNotEmpty()

    // ---- painting ----
    private fun allowed(l: Layer, x: Int, y: Int): Boolean {
        if (x !in 0 until w || y !in 0 until h) return false
        if (!l.clip) return true
        val bi = baseIndex(layers.indexOf(l)); if (bi < 0) return true
        return (layers[bi].bmp.getPixel(x, y) ushr 24) != 0       // a clipped layer only takes paint where the layer below has paint
    }
    fun dot(x: Int, y: Int) {
        val l = cur() ?: return; val half = brush / 2
        for (bx in 0 until brush) for (by in 0 until brush) {
            val px = x - half + bx; val py = y - half + by
            if (allowed(l, px, py)) l.bmp.setPixel(px, py, if (tool == "eraser") 0 else color)
        }
    }
    fun line(x0: Int, y0: Int, x1: Int, y1: Int) {
        var x = x0; var y = y0; val dx = abs(x1 - x0); val dy = -abs(y1 - y0); val sx = if (x0 < x1) 1 else -1; val sy = if (y0 < y1) 1 else -1; var err = dx + dy
        var guard = 0
        while (guard++ < 4000) { dot(x, y); if (x == x1 && y == y1) break; val e2 = 2 * err; if (e2 >= dy) { err += dy; x += sx }; if (e2 <= dx) { err += dx; y += sy } }
        bump()
    }
    fun fill(x: Int, y: Int) {
        val l = cur() ?: return; if (x !in 0 until w || y !in 0 until h) return
        val px = IntArray(w * h); l.bmp.getPixels(px, 0, w, 0, 0, w, h)
        val target = px[y * w + x]; val newC = color; if (target == newC) return
        val q = ArrayDeque<Int>(); q.add(y * w + x)
        while (q.isNotEmpty()) {
            val p = q.removeLast(); val cx = p % w; val cy = p / w
            if (px[p] != target || !allowed(l, cx, cy)) continue
            px[p] = newC
            if (cx > 0) q.add(p - 1); if (cx < w - 1) q.add(p + 1); if (cy > 0) q.add(p - w); if (cy < h - 1) q.add(p + w)
        }
        l.bmp.setPixels(px, 0, w, 0, 0, w, h); bump()
    }
    fun pick(x: Int, y: Int) { if (x in 0 until w && y in 0 until h) { val c = composite().getPixel(x, y); if ((c ushr 24) != 0) chooseColor(c) } }
    fun chooseColor(c: Int) { color = c; recent.remove(c); recent.add(0, c); while (recent.size > 10) recent.removeAt(recent.size - 1) }

    // ---- layers ----
    fun addLayer() { layers.add(active + 1, Layer("Layer ${layers.size + 1}", Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))); active += 1; bump() }
    fun deleteLayer() { if (layers.size <= 1) return; layers.removeAt(active); active = active.coerceAtMost(layers.size - 1); bump() }
    fun move(delta: Int) { val j = active + delta; if (j !in layers.indices) return; val l = layers.removeAt(active); layers.add(j, l); active = j; bump() }
    fun mergeDown() {
        if (active <= 0) return; val top = layers[active]; val under = layers[active - 1]
        val p = Paint().apply { alpha = (top.opacity * 255 / 100).coerceIn(0, 255) }
        ACanvas(under.bmp).drawBitmap(clipped(active), 0f, 0f, p); layers.removeAt(active); active -= 1; bump()
    }
    private fun clipped(i: Int): Bitmap {
        val l = layers[i]; val bi = if (l.clip) baseIndex(i) else -1
        if (bi < 0) return l.bmp
        val t = l.bmp.copy(Bitmap.Config.ARGB_8888, true)
        ACanvas(t).drawBitmap(layers[bi].bmp, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        return t
    }
    fun composite(): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = ACanvas(out); val p = Paint()
        layers.forEachIndexed { i, l -> if (l.visible) { p.alpha = (l.opacity * 255 / 100).coerceIn(0, 255); c.drawBitmap(clipped(i), 0f, 0f, p) } }
        return out
    }

    // ---- canvas size and pictures ----
    fun resize(nw: Int, nh: Int, center: Boolean) {
        val tw = nw.coerceIn(1, MAX); val th = nh.coerceIn(1, MAX)
        val dx = if (center) (tw - w) / 2 else 0; val dy = if (center) (th - h) / 2 else 0
        layers.forEach { l -> val nb = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888); ACanvas(nb).drawBitmap(l.bmp, dx.toFloat(), dy.toFloat(), null); l.bmp = nb }
        w = tw; h = th; undoStack.clear(); bump()
    }
    fun paste(src: Bitmap, fit: Boolean, asNewLayer: Boolean) {
        if (asNewLayer) addLayer() else begin()
        val l = cur() ?: return; val c = ACanvas(l.bmp); val p = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
        if (fit) { val s = min(w / src.width.toFloat(), h / src.height.toFloat()); val dw = src.width * s; val dh = src.height * s; c.drawBitmap(src, null, android.graphics.RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), p) }
        else c.drawBitmap(src, 0f, 0f, p)
        bump()
    }
    fun decode(ctx: Context, uri: android.net.Uri): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1; while (max(o.outWidth, o.outHeight) / s > 2048) s *= 2
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }
    } catch (e: Throwable) { Logger.w("Draw", "could not read the picture: $e"); null }

    // ---- save / load / export ----
    private fun dir(ctx: Context) = File(ctx.filesDir, "draw").apply { mkdirs() }
    fun save(ctx: Context) {
        if (!loaded) return
        try {
            val d = dir(ctx); val arr = JSONArray()
            layers.forEachIndexed { i, l -> File(d, "layer$i.png").outputStream().use { l.bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                arr.put(JSONObject().put("name", l.name).put("v", l.visible).put("o", l.opacity).put("c", l.clip)) }
            File(d, "meta.json").writeText(JSONObject().put("w", w).put("h", h).put("active", active).put("layers", arr).toString())
            d.listFiles()?.filter { f -> f.name.startsWith("layer") && (f.name.removePrefix("layer").removeSuffix(".png").toIntOrNull() ?: -1) >= layers.size }?.forEach { it.delete() }
        } catch (e: Throwable) { Logger.w("Draw", "could not save the drawing: $e") }
    }
    fun ensureLoaded(ctx: Context) {
        if (loaded) return; loaded = true
        try {
            val m = File(dir(ctx), "meta.json"); if (!m.exists()) { newCanvas(64, 64); return }
            val j = JSONObject(m.readText()); val arr = j.getJSONArray("layers"); val nl = ArrayList<Layer>()
            for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); val b = BitmapFactory.decodeFile(File(dir(ctx), "layer$i.png").path)?.copy(Bitmap.Config.ARGB_8888, true) ?: continue
                nl.add(Layer(o.optString("name", "Layer ${i + 1}"), b, o.optBoolean("v", true), o.optInt("o", 100), o.optBoolean("c", false))) }
            if (nl.isEmpty()) { newCanvas(64, 64); return }
            w = j.getInt("w"); h = j.getInt("h"); layers.clear(); layers.addAll(nl); active = j.optInt("active", 0).coerceIn(0, layers.size - 1); bump()
        } catch (e: Throwable) { Logger.w("Draw", "could not open the saved drawing: $e"); newCanvas(64, 64) }
    }
    fun export(ctx: Context, scale: Int): String? {
        val bm = composite(); val big = if (scale > 1) Bitmap.createScaledBitmap(bm, w * scale, h * scale, false) else bm
        val name = "sonicforge-${System.currentTimeMillis()}.png"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/png"); put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SonicForge") }
                val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
                ctx.contentResolver.openOutputStream(uri)?.use { big.compress(Bitmap.CompressFormat.PNG, 100, it) }; "Pictures/SonicForge/$name"
            } else {
                val d = File(ctx.getExternalFilesDir(null), "drawings").apply { mkdirs() }; File(d, name).outputStream().use { big.compress(Bitmap.CompressFormat.PNG, 100, it) }; File(d, name).path
            }
        } catch (e: Throwable) { Logger.e("Draw", "export failed", e); null }
    }
}

private val PALETTE = listOf(0xFF000000, 0xFFFFFFFF, 0xFF9E9E9E, 0xFF424242, 0xFF1E88E5, 0xFF0D47A1, 0xFFE53935, 0xFFFFD54F, 0xFF558B2F, 0xFF00ACC1, 0xFFFFE0B2, 0xFFFFA000, 0xFFF06292, 0xFF7B1FA2, 0xFF6D4C41, 0xFF69F0AE).map { it.toInt() }

@Composable
fun DrawScreen() {
    val ctx = LocalContext.current; val skin = Skins.current()
    LaunchedEffect(Unit) { Draw.ensureLoaded(ctx) }
    DisposableEffect(Unit) { onDispose { Draw.save(ctx) } }
    var showColor by remember { mutableStateOf(false) }; var showLayers by remember { mutableStateOf(false) }; var showCanvas by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }; var pasted by remember { mutableStateOf<Bitmap?>(null) }
    var sc by remember { mutableFloatStateOf(8f) }; var ox by remember { mutableFloatStateOf(0f) }; var oy by remember { mutableFloatStateOf(0f) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    fun fit() { if (box.width > 0 && box.height > 0) { sc = min(box.width.toFloat() / Draw.w, box.height.toFloat() / Draw.h) * .96f; ox = (box.width - Draw.w * sc) / 2; oy = (box.height - Draw.h * sc) / 2 } }
    LaunchedEffect(box, Draw.w, Draw.h) { fit() }
    val scU by rememberUpdatedState(sc); val oxU by rememberUpdatedState(ox); val oyU by rememberUpdatedState(oy)

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("pencil" to "✏ PENCIL", "eraser" to "⌫ ERASER", "fill" to "🪣 FILL", "pick" to "💧 PICK", "move" to "✥ MOVE / ZOOM").forEach { (k, n) -> Btn(n, selected = Draw.tool == k) { Draw.tool = k } }
            Btn("SIZE ${Draw.brush}") { Draw.brush = when (Draw.brush) { 1 -> 2; 2 -> 3; 3 -> 4; 4 -> 6; 6 -> 8; else -> 1 } }
            Btn("GRID: " + if (Draw.grid) "ON" else "OFF", selected = Draw.grid) { Draw.grid = !Draw.grid }
            Btn("FIT") { fit() }
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF263238)).clip(RoundedCornerShape(0.dp)).onSizeChanged { box = it }
            .pointerInput(Draw.tool) {
                if (Draw.tool == "move") detectTransformGestures { _, pan, zoom, _ -> sc = (sc * zoom).coerceIn(1f, 90f); ox += pan.x; oy += pan.y }
                else awaitPointerEventScope {
                    while (true) {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        fun cell(o: Offset) = Pair(((o.x - oxU) / scU).toInt().let { if (o.x < oxU) -1 else it }, ((o.y - oyU) / scU).toInt().let { if (o.y < oyU) -1 else it })
                        var last = cell(down.position)
                        when (Draw.tool) {
                            "fill" -> { Draw.begin(); Draw.fill(last.first, last.second) }
                            "pick" -> Draw.pick(last.first, last.second)
                            else -> { Draw.begin(); Draw.line(last.first, last.second, last.first, last.second) }
                        }
                        down.consume()
                        var go = true
                        while (go) {
                            val ev = awaitPointerEvent(); val ch = ev.changes.firstOrNull() ?: break
                            if (!ch.pressed) { go = false } else {
                                val now = cell(ch.position)
                                if (Draw.tool == "pencil" || Draw.tool == "eraser") Draw.line(last.first, last.second, now.first, now.second) else if (Draw.tool == "pick") Draw.pick(now.first, now.second)
                                last = now
                            }
                            ch.consume()
                        }
                    }
                }
            }) {
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                @Suppress("UNUSED_VARIABLE") val v = Draw.version
                val cw = Draw.w * sc; val chh = Draw.h * sc
                drawRect(Color(0xFFCFD8DC), Offset(ox, oy), Size(cw, chh))
                val tile = max(sc * 2f, 12f); var yy = 0f; var row = 0
                while (yy < chh) { var xx = 0f; var colI = row % 2; while (xx < cw) { if (colI % 2 == 1) drawRect(Color(0xFFB0BEC5), Offset(ox + xx, oy + yy), Size(min(tile, cw - xx), min(tile, chh - yy))); xx += tile; colI++ }; yy += tile; row++ }
                val img = Draw.composite().asImageBitmap()
                drawImage(img, srcOffset = IntOffset.Zero, srcSize = IntSize(Draw.w, Draw.h), dstOffset = IntOffset(ox.toInt(), oy.toInt()), dstSize = IntSize(cw.toInt(), chh.toInt()), filterQuality = FilterQuality.None)
                if (Draw.grid && sc >= 8f) {
                    for (i in 0..Draw.w) drawLine(Color(0x33000000), Offset(ox + i * sc, oy), Offset(ox + i * sc, oy + chh), 1f)
                    for (j in 0..Draw.h) drawLine(Color(0x33000000), Offset(ox, oy + j * sc), Offset(ox + cw, oy + j * sc), 1f)
                }
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)).background(Color(Draw.color)).border(2.dp, Color.White, RoundedCornerShape(8.dp)).clickable { showColor = true })
            Btn("COLOR") { showColor = true }; Btn("LAYERS (${Draw.layers.size})") { showLayers = true }; Btn("CANVAS ${Draw.w}×${Draw.h}") { showCanvas = true }
            Btn("＋ IMAGE") { Picker.pick(arrayOf("image/*")) { u -> u.firstOrNull()?.let { uri -> val b = Draw.decode(ctx, uri); if (b != null) pasted = b else Store.events.tryEmit(SaveEvent("That picture could not be read", false)) } } }
            Btn("↶ UNDO") { Draw.undo() }; Btn("EXPORT PNG") { showExport = true }
        }
    }

    if (showColor) AlertDialog(onDismissRequest = { showColor = false }, containerColor = Color(0xFF0D0D14), confirmButton = { TextButton({ showColor = false }) { Text("Close") } }, title = { Text("Color") },
        text = { Column {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) { PALETTE.forEach { c -> Box(Modifier.size(34.dp).clip(RoundedCornerShape(6.dp)).background(Color(c)).border(if (c == Draw.color) 3.dp else 1.dp, Color.White, RoundedCornerShape(6.dp)).clickable { Draw.chooseColor(c) }) } }
            if (Draw.recent.isNotEmpty()) { Text("Recent", fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)); Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) { Draw.recent.toList().forEach { c -> Box(Modifier.size(28.dp).clip(RoundedCornerShape(5.dp)).background(Color(c)).border(1.dp, Color.White, RoundedCornerShape(5.dp)).clickable { Draw.color = c }) } } }
            val c = Draw.color; val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            fun rgb(rr: Int, gg: Int, bb: Int) { Draw.chooseColor((0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb) }
            Text("Red $r", fontSize = 11.sp); Slider(r.toFloat(), { rgb(it.toInt(), g, b) }, valueRange = 0f..255f)
            Text("Green $g", fontSize = 11.sp); Slider(g.toFloat(), { rgb(r, it.toInt(), b) }, valueRange = 0f..255f)
            Text("Blue $b", fontSize = 11.sp); Slider(b.toFloat(), { rgb(r, g, it.toInt()) }, valueRange = 0f..255f)
        } })

    if (showLayers) AlertDialog(onDismissRequest = { showLayers = false }, containerColor = Color(0xFF0D0D14), confirmButton = { TextButton({ showLayers = false }) { Text("Close") } }, title = { Text("Layers") },
        text = { @Suppress("UNUSED_VARIABLE") val vv = Draw.version; Column {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) { Btn("＋ NEW") { Draw.addLayer() }; Btn("▲") { Draw.move(1) }; Btn("▼") { Draw.move(-1) }; Btn("MERGE DOWN") { Draw.mergeDown() }; Btn("DELETE", color = Color(0xFFE53935)) { Draw.deleteLayer() } }
            Text("Tap a layer to draw on it. 👁 shows/hides it. CLIP = paint only where the layer below has paint (draw inside a circle without leaving it).", fontSize = 10.sp, color = Color(0xAAFFFFFF), modifier = Modifier.padding(vertical = 4.dp))
            Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState())) {
                for (i in Draw.layers.indices.reversed()) {
                    val l = Draw.layers[i]; val sel = i == Draw.active
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(8.dp)).background(if (sel) skin.accent.copy(.3f) else Color.White.copy(.07f)).clickable { Draw.active = i }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (l.clip) Text("↳", fontSize = 16.sp, modifier = Modifier.padding(end = 4.dp))
                        Text(if (l.visible) "👁" else "—", fontSize = 18.sp, modifier = Modifier.clickable { l.visible = !l.visible; Draw.bump() }.padding(horizontal = 6.dp))
                        Column(Modifier.weight(1f)) { Text(l.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1); Text("${l.opacity}%" + if (l.clip) " · clipped" else "", fontSize = 10.sp) }
                        Text("−", fontSize = 18.sp, modifier = Modifier.clickable { l.opacity = (l.opacity - 10).coerceAtLeast(0); Draw.bump() }.padding(horizontal = 8.dp))
                        Text("+", fontSize = 18.sp, modifier = Modifier.clickable { l.opacity = (l.opacity + 10).coerceAtMost(100); Draw.bump() }.padding(horizontal = 8.dp))
                        Text("CLIP", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (l.clip) skin.accent else Color.White, modifier = Modifier.clickable { if (i > 0) { l.clip = !l.clip; Draw.bump() } }.padding(horizontal = 6.dp))
                    }
                }
            }
        } })

    if (showCanvas) {
        var tw by remember { mutableStateOf(Draw.w.toString()) }; var th by remember { mutableStateOf(Draw.h.toString()) }
        AlertDialog(onDismissRequest = { showCanvas = false }, containerColor = Color(0xFF0D0D14), confirmButton = {}, dismissButton = { TextButton({ showCanvas = false }) { Text("Close") } }, title = { Text("Canvas") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Size in pixels (1 to ${Draw.MAX}). Making it smaller crops, making it bigger adds empty space; your layers are kept.", fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(tw, { tw = it.filter { c -> c.isDigit() }.take(4) }, singleLine = true, label = { Text("Width") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(th, { th = it.filter { c -> c.isDigit() }.take(4) }, singleLine = true, label = { Text("Height") }, modifier = Modifier.weight(1f))
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(16, 32, 64, 128, 256).forEach { n -> Btn("$n×$n") { tw = "$n"; th = "$n" } } }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("RESIZE (anchor top-left)") { Draw.resize(tw.toIntOrNull() ?: Draw.w, th.toIntOrNull() ?: Draw.h, false); showCanvas = false }
                    Btn("RESIZE (centered)") { Draw.resize(tw.toIntOrNull() ?: Draw.w, th.toIntOrNull() ?: Draw.h, true); showCanvas = false } }
                Btn("NEW EMPTY CANVAS", Modifier.padding(top = 6.dp), color = Color(0xFFE53935)) { Draw.newCanvas(tw.toIntOrNull() ?: 64, th.toIntOrNull() ?: 64); showCanvas = false }
                Text("NEW EMPTY CANVAS throws the current drawing away.", fontSize = 10.sp, color = Color(0xFFFFAB91))
            } })
    }

    pasted?.let { bm -> AlertDialog(onDismissRequest = { pasted = null }, containerColor = Color(0xFF0D0D14), confirmButton = {}, dismissButton = { TextButton({ pasted = null }) { Text("Cancel") } }, title = { Text("Add this picture") },
        text = { Column {
            Text("${bm.width}×${bm.height} px. 'Fit' scales it into the canvas, 'Original size' keeps its pixels from the top-left corner.", fontSize = 11.sp)
            Btn("ON THIS LAYER · fit", Modifier.fillMaxWidth().padding(2.dp)) { Draw.paste(bm, true, false); pasted = null }
            Btn("NEW LAYER · fit", Modifier.fillMaxWidth().padding(2.dp)) { Draw.paste(bm, true, true); pasted = null }
            Btn("NEW LAYER · original size", Modifier.fillMaxWidth().padding(2.dp)) { Draw.paste(bm, false, true); pasted = null }
            Btn("ON THIS LAYER · original size", Modifier.fillMaxWidth().padding(2.dp)) { Draw.paste(bm, false, false); pasted = null }
        } }) }

    if (showExport) AlertDialog(onDismissRequest = { showExport = false }, containerColor = Color(0xFF0D0D14), confirmButton = {}, dismissButton = { TextButton({ showExport = false }) { Text("Close") } }, title = { Text("Export PNG") },
        text = { Column {
            Text("Saves the finished picture (visible layers only) to Pictures/SonicForge. Bigger scales keep the pixels sharp.", fontSize = 11.sp)
            listOf(1, 4, 8, 16).forEach { s -> if (Draw.w * s <= 4096 && Draw.h * s <= 4096) Btn("×$s  (${Draw.w * s}×${Draw.h * s})", Modifier.fillMaxWidth().padding(2.dp)) {
                val where = Draw.export(ctx, s); showExport = false
                Store.events.tryEmit(SaveEvent(if (where != null) "Drawing saved: $where" else "Could not save the drawing (see LOGS)", where != null)) } }
        } })
}
