package com.sonicforge.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.sonicforge.data.Store

/** A skin = palette + shader + decoration + frame style. Frame fields can be overridden individually in Customize > Frame. */
data class Skin(
    val id: String, val name: String, val bgTop: Color, val bgBot: Color, val accent: Color, val c2: Color, val text: Color,
    val shader: String, val deco: String, val border: String, val bdColor: Color, val bdWidth: Int, val radius: Int, val dark: Boolean = true
)

object Skins {
    val all = listOf(
        Skin("greenhill", "Green Hill", Color(0xFF4FC3F7), Color(0xFF2E7D32), Color(0xFFFFD54F), Color(0xFF8D6E63), Color.White, "greenhill", "rings", "solid", Color(0xFF8D6E63), 4, 10),
        Skin("anime", "Anime", Color(0xFFFF9ACD), Color(0xFF6A3DFF), Color(0xFFFFE066), Color(0xFFFFFFFF), Color.White, "anime", "stars", "double", Color(0xFFFFFFFF), 3, 18),
        Skin("vibes", "Vibes", Color(0xFF1B0B3B), Color(0xFF00A99D), Color(0xFFFF6EC7), Color(0xFF7C4DFF), Color.White, "vibes", "stars", "neon", Color(0xFFFF6EC7), 3, 12),
        Skin("future", "Future", Color(0xFF020914), Color(0xFF06283D), Color(0xFF00E5FF), Color(0xFF2979FF), Color.White, "future", "grid", "neon", Color(0xFF00E5FF), 2, 6),
        Skin("cinematic", "Cinematic", Color(0xFF0B0B0D), Color(0xFF1C1611), Color(0xFFD4A24C), Color(0xFF6D4C41), Color(0xFFF2E8D5), "cinematic", "none", "solid", Color(0xFFD4A24C), 1, 2),
        Skin("sakura", "Sakura", Color(0xFFFFE4EC), Color(0xFFF48FB1), Color(0xFFE91E63), Color(0xFFFFFFFF), Color(0xFF4A1424), "sakura", "sakura", "dashed", Color(0xFFE91E63), 3, 20, dark = false),
        Skin("retro", "Retro Gaming", Color(0xFF101018), Color(0xFF1A1A2E), Color(0xFFE53935), Color(0xFF9E9E9E), Color.White, "crt", "none", "pixel", Color(0xFFE53935), 4, 0),
        Skin("blue", "Blue", Color(0xFF0D47A1), Color(0xFF1976D2), Color(0xFF4FC3F7), Color(0xFFFFFFFF), Color.White, "bloom", "rings", "solid", Color(0xFF4FC3F7), 3, 14),
        Skin("casino", "Casino Night", Color(0xFF1A0033), Color(0xFF3D0066), Color(0xFFFFC107), Color(0xFFE040FB), Color.White, "bloom", "stars", "neon", Color(0xFFFFC107), 3, 10),
        Skin("chaos", "Chaos Emerald", Color(0xFF001F1A), Color(0xFF00695C), Color(0xFF69F0AE), Color(0xFFB9F6CA), Color.White, "bloom", "stars", "double", Color(0xFF69F0AE), 3, 12),
        Skin("frost", "Frost Cap", Color(0xFF0B3C5D), Color(0xFF4FC3F7), Color(0xFFB3E5FC), Color(0xFFFFFFFF), Color.White, "snow", "snow", "double", Color(0xFFB3E5FC), 3, 16),
        Skin("lava", "Lava Reef", Color(0xFF2B0A00), Color(0xFFB71C1C), Color(0xFFFF9800), Color(0xFFFFD54F), Color.White, "ember", "embers", "neon", Color(0xFFFF9800), 3, 8),
        Skin("palace", "Hidden Palace", Color(0xFF1A0B2E), Color(0xFF4A148C), Color(0xFF69F0AE), Color(0xFFB388FF), Color.White, "emerald", "stars", "neon", Color(0xFF69F0AE), 3, 14),
        Skin("sunset", "Sunset Boost", Color(0xFFFF8F00), Color(0xFFD81B60), Color(0xFFFFFFFF), Color(0xFFFFD54F), Color.White, "synthwave", "stars", "solid", Color(0xFFFFFFFF), 3, 18),
        Skin("deathegg", "Death Egg", Color(0xFF212121), Color(0xFF37474F), Color(0xFFFF1744), Color(0xFF90A4AE), Color.White, "arcade", "none", "pixel", Color(0xFFFF1744), 4, 0),
        Skin("neonrings", "Neon Rings", Color(0xFF12002B), Color(0xFF00132E), Color(0xFFFF4081), Color(0xFF00E5FF), Color.White, "glitch", "rings", "neon", Color(0xFFFF4081), 3, 12),
        Skin("aqua", "Aqua Zone", Color(0xFF006064), Color(0xFF0277BD), Color(0xFF18FFFF), Color(0xFF80DEEA), Color.White, "aqua", "bubbles", "dashed", Color(0xFF18FFFF), 3, 20),
        Skin("pocket", "Pocket Green", Color(0xFF0F380F), Color(0xFF306230), Color(0xFF9BBC0F), Color(0xFF8BAC0F), Color(0xFFCADC9F), "gameboy", "none", "pixel", Color(0xFF9BBC0F), 4, 0),
    )
    val borders = listOf("solid", "dashed", "neon", "double", "pixel")
    val accents = listOf(0xFFFFD54F, 0xFFE53935, 0xFFFF6EC7, 0xFF00E5FF, 0xFF69F0AE, 0xFF4FC3F7, 0xFFFFFFFF, 0xFFE91E63, 0xFFFB8C00, 0xFF7C4DFF)

    /** Call from composition: reads Store state so the UI recomposes on change. */
    fun current(): Skin {
        val b = all.firstOrNull { it.id == Store.s("skin", "greenhill") } ?: all[0]
        return b.copy(
            border = Store.s("bdStyle").ifEmpty { b.border },
            bdColor = Store.s("bdColor").toIntOrNull()?.let { Color(it) } ?: b.bdColor,
            bdWidth = Store.i("bdWidth", b.bdWidth), radius = Store.i("bdRadius", b.radius),
            accent = Store.s("accentC").toIntOrNull()?.let { Color(it) } ?: b.accent,
            shader = Store.s("shader").ifEmpty { b.shader }
        )
    }
}

@Composable
fun ForgeTheme(skin: Skin, content: @Composable () -> Unit) {
    val cs = if (skin.dark) darkColorScheme(primary = skin.accent, secondary = skin.c2, background = skin.bgBot, surface = skin.bgTop, onSurface = skin.text, onBackground = skin.text, onPrimary = Color.Black)
             else lightColorScheme(primary = skin.accent, secondary = skin.c2, background = skin.bgBot, surface = skin.bgTop, onSurface = skin.text, onBackground = skin.text)
    MaterialTheme(colorScheme = cs, content = content)
}
