package com.sonicforge.audio

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/** Tiny chiptune synth: generates the UI sounds and the two test tunes, so no binary assets ship in the project. */
object Synth {
    const val SR = 22050
    fun wav(pcm: ShortArray): ByteArray {
        val n = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + n).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + n).put("WAVE".toByteArray()).put("fmt ".toByteArray()).putInt(16)
        bb.putShort(1).putShort(1).putInt(SR).putInt(SR * 2).putShort(2).putShort(16).put("data".toByteArray()).putInt(n)
        pcm.forEach { bb.putShort(it) }; return bb.array()
    }
    private fun osc(kind: Int, ph: Double): Double = when (kind) {
        0 -> if (ph % 1.0 < 0.5) 1.0 else -1.0
        1 -> 4 * abs(ph % 1.0 - 0.5) - 1
        2 -> Math.random() * 2 - 1
        else -> sin(ph * 2 * PI)
    }
    private fun hz(semis: Int) = 261.63 * 2.0.pow(semis / 12.0)

    /** note = (semitones from C4, beats); semis < -90 is a rest */
    private fun voice(out: FloatArray, notes: List<Pair<Int, Double>>, spb: Double, wave: Int, vol: Float, loops: Int) {
        var t = 0.0
        repeat(loops) {
            for ((s, beats) in notes) {
                val start = (t * SR).toInt(); val len = (beats * spb * SR).toInt()
                if (s > -90) for (i in 0 until len) {
                    val idx = start + i; if (idx >= out.size) break
                    val env = minOf(1.0, i / 120.0) * (1.0 - 0.55 * i / len)
                    out[idx] += (osc(wave, hz(s) * i / SR) * env * vol).toFloat()
                }
                t += beats * spb
            }
        }
    }
    private fun drums(out: FloatArray, spb: Double, beats: Double) {
        var b = 0.0
        while (b < beats) {
            val start = (b * spb * SR).toInt()
            val kick = (b % 1.0 == 0.0); val len = if (kick) 1800 else 700
            for (i in 0 until len) { val idx = start + i; if (idx >= out.size) break
                out[idx] += (if (kick) sin(2 * PI * (110 - 60.0 * i / len) * i / SR) * (1 - i / len.toDouble()) * 0.35
                             else (Math.random() * 2 - 1) * (1 - i / len.toDouble()) * 0.07).toFloat() }
            b += 0.5
        }
    }
    private fun finish(f: FloatArray): ShortArray { val pk = f.maxOf { abs(it) }.coerceAtLeast(1f); return ShortArray(f.size) { (f[it] / pk * 0.85f * 32767).toInt().toShort() } }

    private fun song(bpm: Int, lead: List<Pair<Int, Double>>, bass: List<Pair<Int, Double>>, loops: Int, leadWave: Int): ShortArray {
        val spb = 60.0 / bpm; val beats = lead.sumOf { it.second } * loops
        val out = FloatArray((beats * spb * SR).toInt() + SR / 2)
        voice(out, lead, spb, leadWave, 0.22f, loops); voice(out, bass, spb, 1, 0.32f, loops); drums(out, spb, beats)
        return finish(out)
    }
    private fun tone(out: FloatArray, startS: Int, lenS: Int, f: Double, wave: Int, vol: Float, decay: Double) {
        for (i in 0 until lenS) { val idx = startS + i; if (idx >= out.size) break
            out[idx] += (osc(wave, f * i / SR) * minOf(1.0, i / 60.0) * Math.exp(-decay * i / lenS) * vol).toFloat() }
    }
    private class Sec(val prog: List<Int>, val bars: Int, val lvl: Int)
    /** "Speed Rush": an original ~2 minute guitar-rock style track (square-wave guitars, power-chord chugs, bass, drum kit; intro, verses, choruses, solo, outro). */
    fun tuneRush(): ByteArray {
        val bpm = 160; val spb = 60.0 / bpm; val verse = listOf(-3, -7, 0, -5); val chorus = listOf(-7, -5, -3, -3); val bridge = listOf(-10, -7, -5, -5)
        val secs = listOf(Sec(verse, 4, 0), Sec(verse, 8, 1), Sec(chorus, 8, 2), Sec(verse, 8, 1), Sec(chorus, 8, 2), Sec(bridge, 8, 1), Sec(chorus, 8, 3), Sec(chorus, 8, 2), Sec(chorus, 12, 2), Sec(verse, 4, 0))
        val bars = secs.sumOf { it.bars }; val out = FloatArray((bars * 4 * spb * SR).toInt() + SR)
        val pent = intArrayOf(0, 3, 5, 7, 10, 12, 15, 17, 19, 22)
        fun at(beat: Double) = (beat * spb * SR).toInt()
        var bar = 0; val rnd = java.util.Random(7)
        for (sec in secs) for (b in 0 until sec.bars) {
            val root = sec.prog[b % 4]; val b0 = bar * 4.0
            for (k in 0 until 8) {
                val st = at(b0 + k * .5); val len = at(.45); val mute = if (sec.lvl == 0) 6.0 else 4.0
                tone(out, st, len, hz(root), 0, .10f, mute); tone(out, st, len, hz(root + 7), 0, .08f, mute); tone(out, st, len, hz(root + 12), 0, .05f, mute)
                tone(out, st, len, hz(root - 24), 1, .22f, 2.5)
            }
            val kicks = if (sec.lvl >= 2) doubleArrayOf(0.0, 1.5, 2.0, 2.5, 3.5) else doubleArrayOf(0.0, 2.0, 2.5)
            for (kb in kicks) { val st = at(b0 + kb); for (i in 0 until 1800) { val idx = st + i; if (idx >= out.size) break; out[idx] += (Math.sin(2 * PI * (120 - 70.0 * i / 1800) * i / SR) * (1 - i / 1800.0) * .4).toFloat() } }
            for (sb in doubleArrayOf(1.0, 3.0)) { val st = at(b0 + sb); for (i in 0 until 2600) { val idx = st + i; if (idx >= out.size) break; out[idx] += ((Math.random() * 2 - 1) * (1 - i / 2600.0) * .22).toFloat() } }
            for (h in 0 until 8) { val st = at(b0 + h * .5); for (i in 0 until 500) { val idx = st + i; if (idx >= out.size) break; out[idx] += ((Math.random() * 2 - 1) * (1 - i / 500.0) * .05).toFloat() } }
            if (b == 0 && sec.lvl >= 2) { val st = at(b0); for (i in 0 until 9000) { val idx = st + i; if (idx >= out.size) break; out[idx] += ((Math.random() * 2 - 1) * (1 - i / 9000.0) * .12).toFloat() } }
            when (sec.lvl) {
                1 -> for (k in 0 until 4) if ((b + k) % 3 != 2) tone(out, at(b0 + k), at(.9), hz(root + 12 + pent[(b * 3 + k) % 5 + 2]), 0, .13f, 1.6)
                2 -> for (k in 0 until 8) tone(out, at(b0 + k * .5), at(.48), hz(root + 12 + pent[if (b % 2 == 0) (k * 5 % 8) else (7 - k) % 8 + 1]), 0, .14f, 1.2)
                3 -> for (k in 0 until 16) tone(out, at(b0 + k * .25), at(.24), hz(root + 12 + pent[rnd.nextInt(10)]), 0, .13f, 1.0)
            }
            bar++
        }
        return wav(finish(out))
    }
    private fun n(vararg s: Int) = s.map { it to 0.5 }
    private fun n2(vararg s: Int) = s.map { it to 4.0 }

    /** "Hill Stroll": bright major-key original, ~19 s */
    fun tuneHill() = wav(song(150,
        n(0,4,7,12,11,7,4,7, 5,9,12,17,16,12,9,12, 7,11,14,19,17,14,11,14, 12,7,4,7,0,-99,-99,-99), n2(-12,-7,-5,-12), 3, 0))
    /** "Neon Night": minor, slower, triangle lead */
    fun tuneNeon() = wav(song(116,
        n(9,12,16,12,9,12,16,19, 7,11,14,11,7,11,14,17, 5,9,12,9,5,9,12,16, 4,8,11,8,4,8,11,14), n2(-15,-17,-19,-20), 3, 1))

    private fun tones(freqs: List<Double>, ms: Int, wave: Int, sweepTo: Double? = null): ShortArray {
        val per = ms * SR / 1000; val out = FloatArray(per * freqs.size)
        freqs.forEachIndexed { k, f -> for (i in 0 until per) {
            val fr = if (sweepTo != null) f + (sweepTo - f) * i / per else f
            val env = (1.0 - i / per.toDouble()).pow(1.5)
            out[k * per + i] = (osc(wave, fr * i / SR) * env * 0.5).toFloat() } }
        return ShortArray(out.size) { (out[it] * 32767).toInt().toShort() }
    }
    /** three alternative sound packs for the menu sounds */
    fun uiSound(ev: String, pack: String = "chip"): ByteArray = wav(when (pack) {
        "soft" -> when (ev) {
            "click" -> tones(listOf(900.0), 45, 3)
            "confirm" -> tones(listOf(523.0, 659.0, 784.0), 90, 3)
            "back" -> tones(listOf(659.0, 440.0), 90, 3)
            "launch" -> tones(listOf(220.0), 520, 3, 880.0)
            else -> tones(listOf(180.0, 150.0), 160, 3)
        }
        "arcade" -> when (ev) {
            "click" -> tones(listOf(2000.0), 20, 0)
            "confirm" -> tones(listOf(988.0, 1319.0), 60, 0)
            "back" -> tones(listOf(440.0, 330.0, 220.0), 50, 0)
            "launch" -> tones(listOf(200.0), 380, 1, 2400.0)
            else -> tones(listOf(100.0), 130, 2)
        }
        else -> when (ev) {
            "click" -> tones(listOf(1400.0), 35, 0)
            "confirm" -> tones(listOf(660.0, 880.0, 1320.0), 70, 0)
            "back" -> tones(listOf(880.0, 440.0), 70, 1)
            "launch" -> tones(listOf(300.0), 450, 0, 1800.0)
            else -> tones(listOf(140.0, 110.0), 110, 0)
        }
    })
}
