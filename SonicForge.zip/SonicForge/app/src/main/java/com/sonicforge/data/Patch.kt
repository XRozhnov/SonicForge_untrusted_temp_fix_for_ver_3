package com.sonicforge.data

/** ROM-hack patch formats: IPS and BPS (the two used by nearly all Mega Drive hacks). */
object Patch {
    fun apply(rom: ByteArray, p: ByteArray): ByteArray? = try {
        when {
            p.size > 8 && String(p, 0, 5, Charsets.ISO_8859_1) == "PATCH" -> ips(rom, p)
            p.size > 8 && String(p, 0, 4, Charsets.ISO_8859_1) == "BPS1" -> bps(rom, p)
            else -> null
        }
    } catch (_: Exception) { null }

    private fun ips(rom: ByteArray, p: ByteArray): ByteArray {
        var out = rom.copyOf(); var i = 5
        fun grow(n: Int) { if (n > out.size) out = out.copyOf(n) }
        while (i + 3 <= p.size) {
            if (p[i] == 'E'.code.toByte() && p[i + 1] == 'O'.code.toByte() && p[i + 2] == 'F'.code.toByte()) break
            val off = ((p[i].toInt() and 255) shl 16) or ((p[i + 1].toInt() and 255) shl 8) or (p[i + 2].toInt() and 255); i += 3
            val size = ((p[i].toInt() and 255) shl 8) or (p[i + 1].toInt() and 255); i += 2
            if (size == 0) {
                val rle = ((p[i].toInt() and 255) shl 8) or (p[i + 1].toInt() and 255); i += 2; val v = p[i++]
                grow(off + rle); for (k in 0 until rle) out[off + k] = v
            } else { grow(off + size); System.arraycopy(p, i, out, off, size); i += size }
        }
        return out
    }

    private fun bps(src: ByteArray, p: ByteArray): ByteArray {
        var pos = 4
        fun vi(): Long { var data = 0L; var shift = 1L
            while (true) { val x = p[pos++].toInt() and 255; data += (x and 0x7f) * shift; if (x and 0x80 != 0) break; shift = shift shl 7; data += shift }
            return data }
        vi(); val tsize = vi().toInt(); val meta = vi().toInt(); pos += meta
        val t = ByteArray(tsize); var o = 0; var sRel = 0; var tRel = 0
        while (pos < p.size - 12) {
            val d = vi(); val len = (d shr 2).toInt() + 1
            when ((d and 3).toInt()) {
                0 -> { for (k in 0 until len) { t[o] = if (o < src.size) src[o] else 0; o++ } }
                1 -> { for (k in 0 until len) t[o++] = p[pos++] }
                2 -> { val v = vi(); sRel += (if (v and 1L != 0L) -1 else 1) * (v shr 1).toInt(); for (k in 0 until len) t[o++] = src[sRel++] }
                else -> { val v = vi(); tRel += (if (v and 1L != 0L) -1 else 1) * (v shr 1).toInt(); for (k in 0 until len) t[o++] = t[tRel++] }
            }
        }
        return t
    }
}
