package com.sonicforge.data

/** Short tips + known cheat codes. Everything here was checked against fan wikis (Sonic Retro, Sonic Stadium, TCRF, Almar's guides). Codes are for the ORIGINAL ROMs: hacks can differ. */
object Tips {
    fun forRom(r: Rom): List<String> {
        val k = (r.title + " " + r.id).lowercase()
        return when {
            "knuckles" in k -> listOf("Level select (Sonic & Knuckles / S3&K): in Angel Island Zone grab a rope/vine and press Left x3, Right x3, Up x3. A ring sound confirms it. Then use the Sound Test.",
                "Original Sonic 3 (not locked on): on the title screen press Up, Up, Down, Down, Up, Up, Up, Up. Down, Down opens the Sound Test.")
            "hedgehog_2" in k || "sonic 2" in k || "sonic_2" in k -> listOf("Sonic 2 Sound Test (Options): Super Sonic code is 04, 01, 02, 06 (press C after each). The Level Select sound-test code is commonly given as 19, 65, 09, 17. Not verified on every revision, so test it.",
                "With Sonic 2 locked onto Sonic & Knuckles: title screen Up x3, Down x3, Left, Right, Left, Right, then hold A and press Start for Level Select.")
            "hedgehog" in k || "sonic 1" in k || "sonic_1" in k -> listOf("Level select (Sonic 1): on the title screen press Up, Down, Left, Right (ring sound), then hold A and press Start.",
                "Tip: 100 rings = an extra life. Underwater, grab air bubbles before the countdown music starts.")
            else -> emptyList()
        }
    }
}

object CheatDb {
    data class C(val name: String, val code: String, val desc: String)
    fun forRom(r: Rom): List<C> {
        val k = (r.title + " " + r.id).lowercase()
        return if ("knuckles" in k) listOf(
            C("No ring loss when hit", "AWXT-CA4C", "Game Genie. You keep your rings when hurt (S&K / S3&K)."),
            C("Infinite time", "HXRT-AA6A", "Game Genie. The timer stops counting (S&K / S3&K)."),
            C("Level select flag (PAR)", "FFFFE0:0101", "Action Replay. Switches on the level-select flag (TCRF).")) else emptyList()
    }
    /** text lines in the app's cheat format: comment line + NAME=CODE */
    fun asLines(l: List<C>) = l.joinToString("\n") { "# ${it.desc}\n${it.name}=${it.code}" }
}
