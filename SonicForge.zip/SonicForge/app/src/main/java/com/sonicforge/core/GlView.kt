package com.sonicforge.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import com.sonicforge.data.Logger
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class EmuGlView(ctx: Context) : GLSurfaceView(ctx) {
    private val r = EmuRenderer()
    init { setEGLContextClientVersion(3); setRenderer(r); renderMode = RENDERMODE_CONTINUOUSLY }
    fun setShader(id: String) { r.pendingShader = id }
    fun setSmooth(b: Boolean) { r.smooth = b }
    fun takeShot(cb: (Bitmap) -> Unit) { r.shot = cb }
    fun renderFps() = r.renderFps
}

class EmuRenderer : GLSurfaceView.Renderer {
    @Volatile var pendingShader: String? = "none"
    @Volatile var smooth = false
    @Volatile var renderFps = 0
    private var rfCount = 0; private var rfT = System.nanoTime()
    @Volatile var shot: ((Bitmap) -> Unit)? = null
    private var tex = 0; private var prog = 0; private var vbo = 0
    private val programs = HashMap<String, Int>()
    private val buf = ByteBuffer.allocateDirect(720 * 576 * 2).order(ByteOrder.nativeOrder())
    private var w = 320; private var h = 224; private var vw = 1; private var vh = 1
    private var lastSmooth = !smooth
    private val t0 = System.nanoTime()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        programs.clear()
        val t = IntArray(1); GLES30.glGenTextures(1, t, 0); tex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        val v = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val fb: FloatBuffer = ByteBuffer.allocateDirect(v.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(v).also { it.position(0) }
        val b = IntArray(1); GLES30.glGenBuffers(1, b, 0); vbo = b[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, v.size * 4, fb, GLES30.GL_STATIC_DRAW)
        prog = 0; lastSmooth = !smooth
    }
    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { vw = width; vh = height; GLES30.glViewport(0, 0, width, height) }

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type); GLES30.glShaderSource(s, src); GLES30.glCompileShader(s)
        val ok = IntArray(1); GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) Logger.e("Shader", "compile failed: " + GLES30.glGetShaderInfoLog(s))
        return s
    }
    private fun program(id: String): Int = programs.getOrPut(id) {
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, compile(GLES30.GL_VERTEX_SHADER, Shaders.VERT))
        GLES30.glAttachShader(p, compile(GLES30.GL_FRAGMENT_SHADER, Shaders.byId(id).body))
        GLES30.glLinkProgram(p)
        val ok = IntArray(1); GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0 && id != "none") return@getOrPut program("none")   // fall back to clean output if a shader fails
        p
    }

    override fun onDrawFrame(gl: GL10?) {
        rfCount++; val nowT = System.nanoTime(); if (nowT - rfT >= 1_000_000_000L) { renderFps = rfCount; rfCount = 0; rfT = nowT }
        pendingShader?.let { prog = program(it); pendingShader = null }
        if (prog == 0) prog = program("none")
        val r = Emu.fetchFrame(buf)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
        if (smooth != lastSmooth) {
            val f = if (smooth) GLES30.GL_LINEAR else GLES30.GL_NEAREST
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, f)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, f); lastSmooth = smooth
        }
        if (r != 0L) {
            w = (r shr 16).toInt(); h = (r and 0xFFFF).toInt(); buf.position(0)
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGB, w, h, 0, GLES30.GL_RGB, GLES30.GL_UNSIGNED_SHORT_5_6_5, buf)
        }
        GLES30.glClearColor(0f, 0f, 0f, 1f); GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        GLES30.glUseProgram(prog)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(prog, "uTex"), 0)
        GLES30.glUniform2f(GLES30.glGetUniformLocation(prog, "uTexSize"), w.toFloat(), h.toFloat())
        GLES30.glUniform2f(GLES30.glGetUniformLocation(prog, "uOut"), vw.toFloat(), vh.toFloat())
        GLES30.glUniform1f(GLES30.glGetUniformLocation(prog, "uTime"), (System.nanoTime() - t0) / 1e9f)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        shot?.let { cb -> shot = null
            val b = ByteBuffer.allocateDirect(vw * vh * 4).order(ByteOrder.nativeOrder())
            GLES30.glReadPixels(0, 0, vw, vh, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, b)
            val bmp = Bitmap.createBitmap(vw, vh, Bitmap.Config.ARGB_8888); bmp.copyPixelsFromBuffer(b)
            cb(Bitmap.createBitmap(bmp, 0, 0, vw, vh, Matrix().apply { postScale(1f, -1f) }, false)) }
    }
}
