package com.sonicforge.input

import android.content.Context
import android.hardware.input.InputManager
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.sonicforge.data.Store

enum class Act(val label: String, val def: Int, val kbDef: Int) {
    UP("D-pad Up", KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_UP), DOWN("D-pad Down", KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_DOWN),
    LEFT("D-pad Left", KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_LEFT), RIGHT("D-pad Right", KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_RIGHT),
    A("Button A", KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_Z), B("Button B (jump)", KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_X), C("Button C", KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_C),
    X("Button X (6-button)", KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_A), Y("Button Y (6-button)", KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_S), Z("Button Z (6-button)", KeyEvent.KEYCODE_BUTTON_R2, KeyEvent.KEYCODE_D),
    L("Shoulder L (GBA)", KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_Q), R("Shoulder R (GBA)", KeyEvent.KEYCODE_BUTTON_R2, KeyEvent.KEYCODE_W),
    START("Start", KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_ENTER), MODE("Mode / Select", KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_TAB),
    SAVE("Quick save", KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_F5), LOAD("Quick load", KeyEvent.KEYCODE_BUTTON_THUMBR, KeyEvent.KEYCODE_F7),
    MENU("Pause menu", KeyEvent.KEYCODE_BUTTON_MODE, KeyEvent.KEYCODE_ESCAPE), TURBO("Fast-forward (hold)", KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_SPACE), REWIND("Rewind (hold)", KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_R)
}

data class PadInfo(val id: Int, val name: String, val vendor: Int, val product: Int, val rumble: Boolean)

object Pads {
    val devices = mutableStateListOf<PadInfo>()
    var lastKey by mutableStateOf("")
    /** when non-null, the next key press is delivered here instead of the game (used by the rebind UI) */
    var capture: ((Int) -> Unit)? = null
    fun key(a: Act) = Store.i("pad_${a.name}", a.def)
    fun kbKey(a: Act) = Store.i("kb_${a.name}", a.kbDef)
    fun bind(a: Act, code: Int, kb: Boolean = false) = Store.setI((if (kb) "kb_" else "pad_") + a.name, code)
    fun resetAll(kb: Boolean = false) = Act.values().forEach { Store.setI((if (kb) "kb_" else "pad_") + it.name, if (kb) it.kbDef else it.def) }
    /** every action bound to this key (a key may drive several actions) plus its combo partner, if any */
    fun actsFor(code: Int, kb: Boolean): List<Act> {
        val base = Act.values().filter { (if (kb) kbKey(it) else key(it)) == code }
        return base + base.mapNotNull { a -> Store.s("combo_${a.name}").let { n -> Act.values().firstOrNull { it.name == n } } }
    }
    fun combo(a: Act) = Store.s("combo_${a.name}")
    fun keyName(code: Int) = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")

    fun refresh() {
        devices.clear()
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            val s = d.sources
            if (!d.isVirtual && ((s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD || (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK))
                devices.add(PadInfo(id, d.name, d.vendorId, d.productId, d.vibrator.hasVibrator()))
        }
    }
    fun init(ctx: Context) {
        val im = ctx.getSystemService(Context.INPUT_SERVICE) as InputManager
        im.registerInputDeviceListener(object : InputManager.InputDeviceListener {
            override fun onInputDeviceAdded(id: Int) = refresh()
            override fun onInputDeviceRemoved(id: Int) = refresh()
            override fun onInputDeviceChanged(id: Int) = refresh()
        }, Handler(Looper.getMainLooper()))
        refresh()
    }
}
