package com.sonicforge.data

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import org.json.JSONObject
import java.io.File

data class SaveEvent(val label: String, val ok: Boolean)

/** Settings + verified JSON storage. Every write is read back and compared; the result drives the little save-sprite in the UI. */
object Store {
    lateinit var root: File
    val settings = mutableStateMapOf<String, String>()
    val events = MutableSharedFlow<SaveEvent>(extraBufferCapacity = 32)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    fun init(ctx: Context) {
        root = File(ctx.filesDir, "data").apply { mkdirs() }
        read("settings.json")?.let { t ->
            try { val o = JSONObject(t); o.keys().forEach { settings[it] = o.getString(it) } } catch (_: Exception) {}
        }
    }
    fun read(name: String): String? = try { File(root, name).takeIf { it.exists() }?.readText() } catch (_: Exception) { null }
    fun writeVerified(name: String, text: String): Boolean = try {
        val f = File(root, name); val tmp = File(root, "$name.tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
        f.readText() == text
    } catch (_: Exception) { false }

    fun s(k: String, d: String = "") = settings[k]?.takeIf { it.isNotEmpty() } ?: d
    fun i(k: String, d: Int) = settings[k]?.toIntOrNull() ?: d
    fun f(k: String, d: Float) = settings[k]?.toFloatOrNull() ?: d
    fun b(k: String, d: Boolean) = settings[k]?.let { it == "1" } ?: d
    private var lastKey = ""
    fun set(k: String, v: String) { settings[k] = v; lastKey = k; schedule() }
    fun labelFor(k: String) = when {
        k.startsWith("vol") -> "Volume saved"; k.startsWith("hap") -> "Vibration settings saved"
        k.startsWith("pad_") || k.startsWith("kb_") || k.startsWith("combo_") -> "Controls saved"
        k in setOf("skin", "bdStyle", "bdColor", "bdWidth", "bdRadius", "accentC", "shader") || k.startsWith("frame") -> "Style saved"
        k == "lang" -> "Language saved"; k.startsWith("orient") -> "Orientation saved"; k.startsWith("sfx") -> "Sounds saved"
        k.startsWith("fps") || k == "aspect" || k == "smooth" || k.startsWith("scr") -> "Screen settings saved"; k.startsWith("music") || k.startsWith("eq") -> "Music settings saved"
        k.startsWith("op") -> "Opacity saved"; else -> "Settings saved" }
    /** immediate, synchronous save (used from the crash handler) */
    fun setRaw(k: String, v: String) { settings[k] = v; try { val o = JSONObject(); settings.toMap().forEach { (a, b) -> o.put(a, b) }; writeVerified("settings.json", o.toString()) } catch (_: Throwable) {} }
    fun setI(k: String, v: Int) = set(k, v.toString())
    fun setF(k: String, v: Float) = set(k, v.toString())
    fun setB(k: String, v: Boolean) = set(k, if (v) "1" else "0")

    private fun schedule() {
        job?.cancel()
        job = scope.launch {
            delay(500)
            val o = JSONObject(); settings.toMap().forEach { (k, v) -> o.put(k, v) }
            events.tryEmit(SaveEvent(labelFor(lastKey), writeVerified("settings.json", o.toString())))
        }
    }
}
