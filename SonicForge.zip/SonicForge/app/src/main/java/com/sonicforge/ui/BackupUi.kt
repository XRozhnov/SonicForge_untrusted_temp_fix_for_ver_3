package com.sonicforge.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Backup
import com.sonicforge.data.Store

private fun mb(b: Long) = if (b < 1024 * 1024) "${b / 1024} KB" else "%.1f MB".format(b / 1048576.0)

@Composable
fun BackupSection() {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("SonicForge-" + java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())) }
    var sel by remember { mutableStateOf(Backup.parts.filter { it.default }.map { it.id }.toSet()) }
    var info by remember { mutableStateOf<Backup.Info?>(null) }
    var pendingUri by remember { mutableStateOf<android.net.Uri?>(null) }
    H("Backup & restore")
    Text("Updating the app: just install the new APK over the old one. Your settings and files stay (every build uses the same signing key), so you don't need to uninstall. A backup is a safety net for a bad update, a reinstall or a new phone.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    Spacer(Modifier.height(8.dp))
    Text("LIGHT backup = only the first box: a few KB. It remembers WHICH art, sounds and music you use but does not copy them. FULL backup = tick more boxes and those files are copied into the zip too.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    OutlinedTextField(name, { name = it.filter { c -> c.isLetterOrDigit() || c in "-_ ()" } }, label = { Text("File name") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
    Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("LIGHT", selected = sel == setOf("settings")) { sel = setOf("settings") }
        Btn("FULL (no games)", selected = sel == Backup.parts.filter { it.id != "roms" }.map { it.id }.toSet()) { sel = Backup.parts.filter { it.id != "roms" }.map { it.id }.toSet() }
        Btn("EVERYTHING", selected = sel.size == Backup.parts.size) { sel = Backup.parts.map { it.id }.toSet() }
    }
    Backup.parts.forEach { p ->
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
            Checkbox(p.id in sel || p.id == "settings", { c -> if (p.id != "settings") sel = if (c) sel + p.id else sel - p.id }, enabled = p.id != "settings")
            Column(Modifier.weight(1f)) {
                Text(p.title + "  (" + mb(Backup.sizeOf(ctx, p.id)) + ")", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(p.desc, color = Color(0xAAFFFFFF), fontSize = 11.sp)
            }
        }
    }
    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Btn("EXPORT BACKUP", selected = true) { Picker.create(name.ifBlank { "SonicForge-backup" } + ".zip") { Backup.backupTo(ctx, it, sel, name) } }
        Btn("IMPORT BACKUP") { Picker.pick(arrayOf("application/zip", "application/octet-stream")) { u -> u.firstOrNull()?.let { pendingUri = it; info = Backup.inspect(ctx, it) } } }
    }
    val u = pendingUri
    if (u != null) AlertDialog(onDismissRequest = { pendingUri = null },
        confirmButton = { TextButton({ Backup.restoreFrom(ctx, u); pendingUri = null }, enabled = info != null) { Text("Restore") } },
        dismissButton = { TextButton({ pendingUri = null }) { Text("Cancel") } },
        title = { Text("Restore this backup?") },
        text = {
            val i = info
            if (i == null) Text("This file is not a SonicForge backup.") else Column {
                Text("Made with version ${i.version} on ${i.created}", fontSize = 12.sp)
                Text("Contains: " + i.partIds.joinToString { id -> Backup.parts.firstOrNull { it.id == id }?.title ?: id } + " (${i.files} files)", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                Text("Restoring overwrites the same settings and files on this phone. Restart the app afterwards.", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                if (i.missing.isNotEmpty()) Text("Heads up: this is a LIGHT backup and ${i.missing.size} file(s) it refers to are not on this phone (covers, sounds, music or games). Re-add them; first: ${i.missing.first()}", color = Color(0xFFFFB74D), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                Text("Folders you linked (ROMs/music) must be linked again after a reinstall: Android removes that permission.", fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            }
        })
}
