package com.sonicforge.data

import com.sonicforge.ui.I18n

/**
 * Offline knowledge about common errors. Texts are written by the app's author (not copied from the log). Format of each text row:
 * en ¦ ru ¦ uk ¦ es ¦ fr ¦ de   (other interface languages fall back to English).
 * Sources: libretro/RetroArch and RetroPie forum threads about Genesis Plus GX ("Unable to open CD BIOS", "Failed to load content", "wrong ELF class") and Android error docs.
 */
object CrashKB {
    class Known(val id: String, val keys: List<String>, private val rows: String) {
        fun text(lang: String): String { val p = rows.split(" ¦ "); val i = when (lang) { "ru" -> 1; "uk" -> 2; "es" -> 3; "fr" -> 4; "de" -> 5; else -> 0 }; return p.getOrNull(i)?.trim()?.ifEmpty { null } ?: p[0].trim() }
    }
    private val kb = listOf(
        Known("cd_bios", listOf("unable to open cd bios", "bios_cd_", "cd bios"),
            "The Sega CD BIOS is missing or named wrongly. Genesis Plus GX wants bios_CD_U.bin (USA), bios_CD_E.bin (Europe) or bios_CD_J.bin (Japan) and can be picky about the dump. Add it in LOCATIONS ▸ Sega CD BIOS. ¦ " +
            "Не найден или неверно назван BIOS Sega CD. Нужен bios_CD_U.bin (США), bios_CD_E.bin (Европа) или bios_CD_J.bin (Япония); ядро бывает разборчиво к дампу. Добавьте его в LOCATIONS ▸ Sega CD BIOS. ¦ " +
            "BIOS Sega CD не знайдено або назву вказано неправильно. Потрібен bios_CD_U.bin (США), bios_CD_E.bin (Європа) або bios_CD_J.bin (Японія). Додайте його в LOCATIONS ▸ Sega CD BIOS. ¦ " +
            "Falta la BIOS de Sega CD o tiene un nombre incorrecto. Se necesita bios_CD_U.bin, bios_CD_E.bin o bios_CD_J.bin. Añádela en LOCATIONS ▸ Sega CD BIOS. ¦ " +
            "Le BIOS Sega CD est absent ou mal nommé. Il faut bios_CD_U.bin, bios_CD_E.bin ou bios_CD_J.bin. Ajoutez-le dans LOCATIONS ▸ Sega CD BIOS. ¦ " +
            "Das Sega-CD-BIOS fehlt oder ist falsch benannt. Benötigt wird bios_CD_U.bin, bios_CD_E.bin oder bios_CD_J.bin. Unter LOCATIONS ▸ Sega CD BIOS hinzufügen."),
        Known("elf_class", listOf("wrong elf class", "bad elf magic", "has bad elf", "is 64-bit instead of 32-bit", "is 32-bit instead of 64-bit"),
            "The emulator core does not match your phone's CPU (32-bit vs 64-bit). Install the matching APK (arm64-v8a or armeabi-v7a) or the Universal one. ¦ " +
            "Ядро эмулятора не подходит процессору телефона (32 бит и 64 бит). Установите подходящий APK (arm64-v8a или armeabi-v7a) или Universal. ¦ " +
            "Ядро емулятора не підходить процесору (32 і 64 біти). Встановіть відповідний APK або Universal. ¦ " +
            "El núcleo no coincide con la CPU (32 frente a 64 bits). Instala el APK adecuado o el Universal. ¦ " +
            "Le cœur ne correspond pas au processeur (32 ou 64 bits). Installez le bon APK ou l'Universal. ¦ " +
            "Der Emulator-Kern passt nicht zur CPU (32 vs. 64 Bit). Passende APK oder die Universal-APK installieren."),
        Known("link_error", listOf("unsatisfiedlinkerror", "couldn't find \"lib", "dlopen failed", "library \"lib"),
            "A native library could not be loaded: the APK does not match your CPU or is damaged. Re-install the right APK (see ABOUT APP for the recommendation). ¦ " +
            "Не удалось загрузить нативную библиотеку: APK не подходит процессору или повреждён. Переустановите нужный APK (рекомендация в ABOUT APP). ¦ " +
            "Не вдалося завантажити бібліотеку: APK не підходить процесору або пошкоджений. Перевстановіть потрібний APK. ¦ " +
            "No se pudo cargar una biblioteca nativa: el APK no coincide con tu CPU o está dañado. Reinstala el APK correcto. ¦ " +
            "Impossible de charger une bibliothèque native : APK inadapté ou endommagé. Réinstallez le bon APK. ¦ " +
            "Eine native Bibliothek konnte nicht geladen werden: APK passt nicht zur CPU oder ist beschädigt. Richtige APK neu installieren."),
        Known("core_missing", listOf("is not included in this build", "core (lib", "libgpgx.so) is missing"),
            "An emulator core is not part of this build (optional cores are downloaded while building and may fail). Rebuild, or use an APK that includes it. ¦ " +
            "Ядро эмулятора не входит в эту сборку (необязательные ядра скачиваются при сборке и могут не скачаться). Пересоберите или возьмите APK с ним. ¦ " +
            "Ядро емулятора відсутнє в цій збірці. Перезберіть або візьміть APK з ним. ¦ " +
            "El núcleo no forma parte de esta compilación. Recompila o usa un APK que lo incluya. ¦ " +
            "Ce cœur n'est pas inclus dans cette version. Recompilez ou utilisez un APK qui l'inclut. ¦ " +
            "Dieser Kern ist nicht in diesem Build enthalten. Neu bauen oder eine APK mit Kern verwenden."),
        Known("rom_rejected", listOf("core rejected this rom", "failed to load game", "failed to load content", "could not start this sega cd"),
            "The core refused the file: a bad dump, the wrong system, or an archive with several files. For Sega CD import the .cue together with its .bin files and add the BIOS. ¦ " +
            "Ядро не приняло файл: плохой дамп, не та система или архив с несколькими файлами. Для Sega CD импортируйте .cue вместе с .bin и добавьте BIOS. ¦ " +
            "Ядро не прийняло файл: поганий дамп, не та система або архів з кількома файлами. Для Sega CD імпортуйте .cue разом з .bin та додайте BIOS. ¦ " +
            "El núcleo rechazó el archivo: volcado dañado, sistema equivocado o un archivo con varios ficheros. Para Sega CD importa el .cue con sus .bin y añade la BIOS. ¦ " +
            "Le cœur a refusé le fichier : dump défectueux, mauvais système ou archive multiple. Pour Sega CD, importez le .cue avec ses .bin et ajoutez le BIOS. ¦ " +
            "Der Kern hat die Datei abgelehnt: fehlerhafter Dump, falsches System oder mehrere Dateien. Für Sega CD die .cue mit den .bin importieren und das BIOS hinzufügen."),
        Known("oom", listOf("outofmemoryerror", "out of memory", "failed to allocate"),
            "The phone ran out of memory. Turn off Rewind, background effects and heavy shaders, and close other apps. ¦ " +
            "Не хватило памяти. Отключите перемотку, фоновые эффекты и тяжёлые шейдеры, закройте другие приложения. ¦ " +
            "Не вистачило пам'яті. Вимкніть перемотування, фонові ефекти та важкі шейдери. ¦ " +
            "Se agotó la memoria. Desactiva el rebobinado, los efectos de fondo y los shaders pesados. ¦ " +
            "Mémoire insuffisante. Désactivez le rembobinage, les effets de fond et les shaders lourds. ¦ " +
            "Der Speicher ist voll. Zurückspulen, Hintergrundeffekte und schwere Shader ausschalten."),
        Known("shader", listOf("shader compile failed", "glcompileshader", "shader link"),
            "A shader did not compile on this GPU, so the app fell back to Clean. Pick another shader. ¦ " +
            "Шейдер не скомпилировался на этом GPU, включён чистый режим. Выберите другой шейдер. ¦ " +
            "Шейдер не скомпілювався на цьому GPU. Оберіть інший шейдер. ¦ " +
            "Un shader no compiló en esta GPU; se usa el modo limpio. Elige otro shader. ¦ " +
            "Un shader ne compile pas sur ce GPU ; mode propre utilisé. Choisissez un autre shader. ¦ " +
            "Ein Shader ließ sich auf dieser GPU nicht kompilieren; es wird „Clean“ verwendet. Anderen Shader wählen."),
        Known("rar5", listOf("rar5", "unsupportedrarv5", "unsupported rar"),
            "RAR5 or password-protected archives are not supported. Re-pack the file as .zip or .7z. ¦ " +
            "Архивы RAR5 или с паролем не поддерживаются. Перепакуйте в .zip или .7z. ¦ " +
            "Архіви RAR5 або з паролем не підтримуються. Перепакуйте у .zip або .7z. ¦ " +
            "No se admiten RAR5 ni archivos con contraseña. Vuelve a comprimir en .zip o .7z. ¦ " +
            "Les archives RAR5 ou protégées ne sont pas gérées. Recompressez en .zip ou .7z. ¦ " +
            "RAR5 und passwortgeschützte Archive werden nicht unterstützt. Als .zip oder .7z neu packen."),
        Known("storage_full", listOf("enospc", "no space left"),
            "The phone storage is full. Free some space (Sega CD images are large). ¦ Память телефона заполнена. Освободите место (образы Sega CD большие). ¦ Пам'ять телефона заповнена. Звільніть місце. ¦ El almacenamiento está lleno. Libera espacio. ¦ Stockage plein. Libérez de l'espace. ¦ Speicher voll. Platz schaffen."),
        Known("folder_perm", listOf("securityexception", "permission denial", "no persistable"),
            "Android no longer lets the app read that folder or file. Link the folder again (LOCATIONS) or pick the file again. ¦ Android больше не даёт доступ к этой папке или файлу. Привяжите папку заново (LOCATIONS) или выберите файл снова. ¦ Android більше не дає доступ до цієї папки. Прив'яжіть папку знову. ¦ Android ya no permite leer esa carpeta. Vincula la carpeta de nuevo. ¦ Android n'autorise plus l'accès à ce dossier. Reliez-le à nouveau. ¦ Android erlaubt den Zugriff auf diesen Ordner nicht mehr. Ordner erneut verknüpfen."),
        Known("zip_bad", listOf("zipexception", "zip file is empty", "invalid zip", "malformed"),
            "The archive is damaged or in an unsupported format. Try re-downloading it or extract it on a PC. ¦ Архив повреждён или в неподдерживаемом формате. Скачайте заново или распакуйте на ПК. ¦ Архів пошкоджений або у непідтримуваному форматі. ¦ El archivo está dañado o no es compatible. ¦ L'archive est endommagée ou non prise en charge. ¦ Das Archiv ist beschädigt oder nicht unterstützt."),
        Known("music_fmt", listOf("unsupported audio", "cannot decode", "can't play this file", "no decoder"),
            "Android cannot play this audio: its format or codec isn't supported on this phone (WMA, APE, WV, DSF, VGM/NSF and tracker modules are not). Convert it to MP3, FLAC, OGG or WAV and add it again. Check more at developer.android.com, Supported media formats. ¦ " +
            "Android не может воспроизвести этот звук: формат или кодек не поддерживается на этом телефоне (WMA, APE, WV, DSF, VGM/NSF и трекерные модули не поддерживаются). Конвертируйте в MP3, FLAC, OGG или WAV и добавьте снова. Подробнее: developer.android.com, Supported media formats."),
        Known("audio", listOf("audiotrack", "audio track init", "audioflinger"),
            "The audio output could not start (maybe busy). Close other apps that use sound and try again. ¦ Не удалось запустить вывод звука (возможно, занят). Закройте другие приложения со звуком. ¦ Не вдалося запустити вивід звуку. ¦ No se pudo iniciar la salida de audio. ¦ Impossible de démarrer la sortie audio. ¦ Audioausgabe konnte nicht starten."),
    )
    private val unknown = mapOf(
        "en" to "I have no offline information about this error. Try searching the internet for the error text together with: %s.",
        "ru" to "У меня нет офлайн-информации об этой ошибке. Попробуйте найти ответ в интернете по тексту ошибки вместе с: %s.",
        "uk" to "У мене немає офлайн-інформації про цю помилку. Спробуйте знайти відповідь в інтернеті за текстом помилки разом із: %s.",
        "es" to "No tengo información sin conexión sobre este error. Busca el texto del error en internet junto con: %s.",
        "fr" to "Je n'ai pas d'information hors ligne sur cette erreur. Cherchez le texte de l'erreur sur internet avec : %s.",
        "de" to "Ich habe keine Offline-Informationen zu diesem Fehler. Suche den Fehlertext im Internet zusammen mit: %s.",
        "pt" to "Não tenho informação offline sobre este erro. Pesquise o texto do erro na internet junto com: %s.",
        "it" to "Non ho informazioni offline su questo errore. Cerca il testo dell'errore su internet insieme a: %s.",
        "ja" to "このエラーのオフライン情報はありません。エラー文と次の語をインターネットで検索してください: %s。",
        "zh" to "我没有关于此错误的离线信息。请在网上搜索错误文本和：%s。")

    fun match(text: String): Known? { val t = text.lowercase(); return kb.firstOrNull { k -> k.keys.any { it in t } } }

    /** (english note, note in the launcher's language). Only the app's own comment; the original message is never changed. */
    fun comments(text: String, context: String): Pair<String, String> {
        val k = match(text); val lang = I18n.current()
        return if (k != null) k.text("en") to k.text(lang)
        else { val ctx = context.ifEmpty { "the emulator/game and its version" }; String.format(unknown["en"]!!, ctx) to String.format(unknown[lang] ?: unknown["en"]!!, ctx) }
    }
}
