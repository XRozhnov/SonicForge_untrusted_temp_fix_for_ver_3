package com.sonicforge.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.concurrent.thread

/**
 * Backups. LIGHT = only "Settings, presets & library list" (a few KB): it also remembers WHICH art/sound/music/game files you use, without copying them.
 * FULL = tick more parts and those files are copied into the zip too. Updating the app by installing the new APK over the old one keeps everything anyway
 * (same signing key), so a backup is a safety net for bad updates, uninstalls and moving to another phone.
 */
object Backup {
    data class Part(val id: String, val title: String, val desc: String, val dir: String, val default: Boolean)
    val parts = listOf(
        Part("settings", "Settings, presets & library list", "All settings, control layouts, vibration presets, skins, volumes, and the list of your games with their notes, cheats, versions and order. Tiny, always included.", "data", true),
        Part("art", "Covers, logos & backgrounds", "The pictures you picked for games, the gamepad and the launcher.", "art", true),
        Part("sounds", "Custom launcher sounds", "Sound files you assigned to menu events.", "sounds", true),
        Part("saves", "Game saves & save states", "In-game saves (.srm) and every save-state slot, with the previous save kept for each slot.", "saves", true),
        Part("music", "Music files", "Music you imported into the app. Can be big. (Built-in test tunes are skipped.)", "music", false),
        Part("roms", "Game files (ROMs / disc images)", "Copies of the games you imported. Very big; you can also just re-import your originals.", "roms", false),
    )
    data class Info(val app: String, val version: String, val created: String, val partIds: List<String>, val files: Int, val missing: List<String>)
    private fun skip(part: String, f: File) = f.name.endsWith(".tmp") || (part == "sounds" && Regex("^(chip|soft|arcade)_.*\\.wav$").matches(f.name)) || (part == "music" && f.name.startsWith("Test Tune - "))

    fun fileList(ctx: Context, part: Part): List<File> = File(ctx.filesDir, part.dir).walkTopDown().filter { it.isFile && !skip(part.id, it) }.toList()
    fun sizeOf(ctx: Context, id: String) = parts.first { it.id == id }.let { p -> fileList(ctx, p).sumOf { it.length() } }

    fun backupTo(ctx: Context, uri: Uri, selected: Set<String>, label: String) = thread {
        val sel = selected + "settings"
        val ok = try {
            val man = JSONObject().put("app", "SonicForge").put("created", java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date()))
                .put("label", label).put("version", try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (_: Exception) { "?" }).put("parts", JSONArray(sel.toList()))
            val refs = JSONObject()   // light mode: remember which files exist (not copied)
            parts.filter { it.id !in sel }.forEach { p -> refs.put(p.id, JSONArray(fileList(ctx, p).map { it.relativeTo(ctx.filesDir).path.replace('\\', '/') })) }
            man.put("refs", refs)
            var n = 0
            ZipOutputStream(ctx.contentResolver.openOutputStream(uri)!!).use { z ->
                z.putNextEntry(ZipEntry("manifest.json")); z.write(man.toString(2).toByteArray()); z.closeEntry()
                parts.filter { it.id in sel }.forEach { p -> fileList(ctx, p).forEach { f ->
                    z.putNextEntry(ZipEntry(f.relativeTo(ctx.filesDir).path.replace('\\', '/'))); f.inputStream().use { it.copyTo(z) }; z.closeEntry(); n++ } }
            }
            Logger.i("Backup", "exported $n files, parts=$sel"); true
        } catch (e: Exception) { Logger.e("Backup", "export failed", e); false }
        Store.events.tryEmit(SaveEvent(if (ok) "Backup saved: " + (if (sel.size == 1) "settings only (light)" else "${sel.size} parts") else "Backup failed", ok))
    }

    fun inspect(ctx: Context, uri: Uri): Info? = try {
        var man: JSONObject? = null; var count = 0
        ZipInputStream(ctx.contentResolver.openInputStream(uri)!!).use { z ->
            var e = z.nextEntry
            while (e != null) { if (e.name == "manifest.json") man = JSONObject(String(z.readBytes())) else if (!e.isDirectory) count++; e = z.nextEntry }
        }
        val m = man ?: JSONObject().put("app", "SonicForge").put("version", "old").put("created", "?").put("parts", JSONArray(parts.map { it.id }))   // backups from older builds have no manifest
        val ids = (0 until m.getJSONArray("parts").length()).map { m.getJSONArray("parts").getString(it) }
        val missing = mutableListOf<String>()
        m.optJSONObject("refs")?.let { r -> r.keys().forEach { k -> val a = r.getJSONArray(k); for (i in 0 until a.length()) if (!File(ctx.filesDir, a.getString(i)).exists()) missing.add(a.getString(i)) } }
        Info(m.optString("app"), m.optString("version"), m.optString("created"), ids, count, missing)
    } catch (e: Exception) { Logger.e("Backup", "inspect failed", e); null }

    fun restoreFrom(ctx: Context, uri: Uri) = thread {
        var n = 0
        val ok = try {
            val root = ctx.filesDir.canonicalPath
            ZipInputStream(ctx.contentResolver.openInputStream(uri)!!).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val f = File(ctx.filesDir, e.name)
                    if (!e.isDirectory && parts.any { e!!.name.startsWith(it.dir + "/") } && f.canonicalPath.startsWith(root)) { f.parentFile?.mkdirs(); f.outputStream().use { z.copyTo(it) }; n++ }
                    e = z.nextEntry
                }
            }; n > 0
        } catch (e: Exception) { Logger.e("Backup", "restore failed", e); false }
        if (ok) { Store.settings.clear(); Store.init(ctx); Library.init(ctx); PadLayouts.init(); com.sonicforge.audio.Music.scan() }
        Store.events.tryEmit(SaveEvent(if (ok) "Restored $n files. Restart the app to apply everything." else "Not a valid backup", ok))
    }
}
