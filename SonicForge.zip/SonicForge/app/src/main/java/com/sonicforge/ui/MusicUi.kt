package com.sonicforge.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.audio.Music
import com.sonicforge.audio.MusicService
import com.sonicforge.audio.Playlists
import com.sonicforge.audio.Track
import com.sonicforge.data.Library
import com.sonicforge.data.Store
import com.sonicforge.input.Haptics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sin

private const val FAV = "★ Favorites"
private val SYSTEM_LISTS = listOf("all" to "ALL", FAV to "★ FAVORITES", "recent" to "RECENT", "imported" to "IMPORTED", "builtin" to "BUILT-IN", "linked" to "LINKED FOLDER")
private fun isSystem(k: String) = SYSTEM_LISTS.any { it.first == k }
private fun isUser(k: String) = !isSystem(k)
private fun listTracks(k: String): List<com.sonicforge.audio.Track> = when (k) {
    "all" -> Music.tracks.toList()
    "recent" -> Music.tracks.filter { !it.isUri }.sortedByDescending { Music.dateOf(it) }.take(25)
    "imported" -> Music.tracks.filter { !it.isUri && !it.title.startsWith("Test Tune") }
    "builtin" -> Music.tracks.filter { it.title.startsWith("Test Tune") }
    "linked" -> Music.tracks.filter { it.isUri }
    else -> Playlists.tracks(k).mapNotNull { p -> Music.byPath[p] }
}
private val LCD_BG = Color(0xFF9BBC0F); private val LCD_FG = Color(0xFF0F380F)
private fun fmt(ms: Int): String {
    val h = ms / 3600000; val m = ms / 60000 % 60; val s = ms / 1000 % 60
    return if (Store.s("timeFmt", "auto") == "minutes") "%d:%02d".format(ms / 60000, s) else if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
private fun mb(b: Long) = if (b <= 0) "" else if (b < 1048576) "${b / 1024} KB" else "%.1f MB".format(b / 1048576.0)

/** embedded album art (or your own picture for that track) */
@Composable
private fun coverOf(t: Track?): ImageBitmap? {
    val ctx = LocalContext.current
    val mode = Store.s("coverMode", "original")
    return produceState<ImageBitmap?>(null, t?.path, mode, Store.s("cov_" + (t?.path ?: ""))) {
        value = if (t == null || mode == "off") null else withContext(Dispatchers.IO) {
            val own = Store.s("cov_" + t.path)
            if (own.isNotEmpty() && File(own).exists()) BitmapFactory.decodeFile(own, BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap()
            else if (mode == "custom") null
            else try { val r = android.media.MediaMetadataRetriever(); if (t.isUri) r.setDataSource(ctx, Uri.parse(t.path)) else r.setDataSource(t.path)
                val pic = r.embeddedPicture; r.release(); pic?.let { BitmapFactory.decodeByteArray(it, 0, it.size, BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap() } } catch (_: Exception) { null }
        }
    }.value
}

@Composable
private fun Equalizer(style: String, active: Float, tt: () -> Float, color: Color, modifier: Modifier) {
    androidx.compose.foundation.Canvas(modifier) {
        val t = tt()   // read while drawing, so the animation does not recompose the whole screen
        val n = 28; val w = size.width / n; val h = size.height
        for (i in 0 until n) {
            val a = (0.08f + abs(sin(t * (1.6f + i % 5) + i * .7f)) * .92f) * active
            when (style) {
                "bars" -> drawRect(color, Offset(i * w + 2f, h * (1 - a)), Size(w - 4f, h * a))
                "mirror" -> drawRect(color, Offset(i * w + 2f, h / 2 - h * a / 2), Size(w - 4f, h * a))
                "dots" -> drawCircle(color, 3f + a * 7f, Offset(i * w + w / 2, h / 2 + sin(t * 3f + i * .5f) * h * .35f * active))
                "wave" -> drawLine(color, Offset(i * w, h / 2 - (a - .5f) * h), Offset((i + 1) * w, h / 2 - (abs(sin(t * 2f + (i + 1) * .4f)) - .5f) * h * active), 4f)
                "circle" -> { val c = Offset(size.width / 2, h / 2); val ang = i * 6.2832f / n; val r0 = h * .28f
                    drawLine(color, c + Offset(kotlin.math.cos(ang) * r0, kotlin.math.sin(ang) * r0), c + Offset(kotlin.math.cos(ang) * (r0 + h * .3f * a), kotlin.math.sin(ang) * (r0 + h * .3f * a)), 4f) }
            }
        }
    }
}

@Composable
fun MusicScreen() {
    val skin = Skins.current(); val ctx = LocalContext.current
    var t by remember { mutableFloatStateOf(0f) }; var angle by remember { mutableFloatStateOf(0f) }
    var opts by remember { mutableStateOf(false) }; var select by remember { mutableStateOf(false) }
    var chosen by remember { mutableStateOf(setOf<String>()) }; var list by remember { mutableStateOf("all") }
    var showFailed by remember { mutableStateOf(false) }; var newList by remember { mutableStateOf(false) }; var mergeFrom by remember { mutableStateOf<String?>(null) }
    var delAsk by remember { mutableStateOf(false) }; var addMenu by remember { mutableStateOf(false) }
    val confirm = rememberConfirm()
    LaunchedEffect(Unit) { Playlists.load(); Playlists.create(FAV) }
    var move by remember { mutableStateOf(false) }; var showQueue by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { var last = 0L; while (true) withFrameNanos { n -> if (last != 0L && Music.playing) angle += (n - last) / 1e9f * 120f; last = n; t = n / 1e9f } }
    val active by animateFloatAsState(if (Music.playing) 1f else 0f, label = "eq")
    val cur = Music.tracks.getOrNull(Music.current); val cover = coverOf(cur)
    val face = Store.s("musFace", "lcd"); val eq = Store.s("musEq", "bars")
    // the lists are recalculated only when something they depend on changes, never once per animation frame
    val shown by remember { derivedStateOf {
        @Suppress("UNUSED_VARIABLE") val mt = Music.metaTick
        val base = listTracks(list); val rv = Store.b("musRev", false)
        when (Store.s("musSort", "added")) { "name" -> base.sortedBy { it.title.lowercase() }; "date" -> base.sortedBy { Music.dateOf(it) }; "size" -> base.sortedBy { Music.sizeOf(it) }; "artist" -> base.sortedBy { Music.artist(it).lowercase() }; else -> base }.let { if (rv) it.reversed() else it }
    } }
    val artistCount by remember { derivedStateOf { shown.mapNotNull { Music.artist(it).takeIf { a -> a.isNotEmpty() } }.distinct().size } }
    val counts by remember { derivedStateOf { SYSTEM_LISTS.associate { it.first to listTracks(it.first).size } } }
    val noteText = cur?.title ?: "NO TRACK"

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth > 700.dp
        val player: @Composable (Modifier) -> Unit = { m ->
            Column(m.padding(10.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF2B2B33)).skinBorder(skin).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                when (face) {
                    "stream" -> {   // streaming-app look: big cover, title, thin progress bar
                        Box(Modifier.fillMaxWidth().height(if (wide) 170.dp else 190.dp).clip(RoundedCornerShape(14.dp)).background(Brush3(skin.c2, skin.bgBot)), Alignment.Center) {
                            if (cover != null) Image(cover, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else Equalizer(eq, active, { t }, skin.accent, Modifier.fillMaxSize().padding(24.dp))
                        }
                        Text(noteText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, modifier = Modifier.padding(top = 8.dp))
                        Text(cur?.let { Music.artist(it) }.orEmpty(), color = Color(0xAAFFFFFF), fontSize = 12.sp, maxLines = 1)
                    }
                    "neon" -> {
                        Text(noteText.uppercase(), color = skin.accent, fontWeight = FontWeight.Black, maxLines = 1, letterSpacing = 2.sp)
                        Equalizer(eq, active, { t }, skin.accent, Modifier.fillMaxWidth().height(80.dp))
                    }
                    else -> Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(LCD_BG).padding(10.dp)) {   // handheld LCD
                        Text(noteText.uppercase(), color = LCD_FG, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("${if (Music.shuffle) "SHUFFLE ON " else ""}${listOf("REPEAT OFF", "REPEAT ALL", "REPEAT ONE")[Music.repeat]}   VOL ${Store.i("volMusic", 100)}", color = LCD_FG, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        Equalizer(eq, active, { t }, LCD_FG, Modifier.fillMaxWidth().height(56.dp))
                    }
                }
                ProgressBar(skin.accent)
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Key("⏮") { Music.prev() }; Key("-30") { Music.seek((Music.pos() - 30000).coerceAtLeast(0)) }; Key("-10") { Music.seek((Music.pos() - 10000).coerceAtLeast(0)) }
                    Key(if (Music.playing) "⏸" else "▶", true) { Music.toggle(); if (Music.playing) MusicService.ensure(ctx) }
                    Key("+10") { Music.seek(Music.pos() + 10000) }; Key("+30") { Music.seek(Music.pos() + 30000) }; Key("⏭") { Music.next() }
                }
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("SHUFFLE: " + if (Music.shuffle) "ON" else "OFF", selected = Music.shuffle) { Music.shuffle = !Music.shuffle }
                    Btn("REPEAT: " + listOf("OFF", "ALL", "ONE")[Music.repeat], selected = Music.repeat > 0) { Music.repeat = (Music.repeat + 1) % 3 }
                    Btn("☰ QUEUE") { showQueue = true }
                    Btn("⚙", selected = opts) { opts = !opts }
                }
                if (face == "lcd") {   // spinning disc: drag around it to scrub
                    var ds by remember { mutableStateOf(IntSize.Zero) }
                    androidx.compose.foundation.Canvas(Modifier.padding(top = 6.dp).size(90.dp).onSizeChanged { ds = it }.clickable { Music.toggle(); Haptics.ui() }.pointerInput(Unit) { detectDragGestures { c, _ ->
                        val cx = ds.width / 2f; val cy = ds.height / 2f; val a1 = atan2(c.previousPosition.y - cy, c.previousPosition.x - cx); val a2 = atan2(c.position.y - cy, c.position.x - cx)
                        var d = a2 - a1; if (d > 3.1416f) d -= 6.2832f; if (d < -3.1416f) d += 6.2832f; angle += Math.toDegrees(d.toDouble()).toFloat(); Music.seek((Music.pos() + d / 6.2832f * 20000f).toInt().coerceAtLeast(0)) } }) {
                        val c = Offset(size.width / 2, size.height / 2)
                        rotate(angle, c) { drawCircle(Color(0xFF111114), size.width / 2, c); drawCircle(skin.accent, size.width * .32f, c); drawCircle(Color(0xFF111114), size.width * .08f, c); drawLine(Color.White, c, Offset(c.x, c.y - size.width * .3f), 4f) }
                        drawCircle(skin.accent, size.width / 2, c, style = Stroke(4f))
                    }
                    Text("Tap = play/pause · drag around the disc = scrub", color = Color(0x99FFFFFF), fontSize = 10.sp)
                }
                if (opts) Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    SChips("Look", "musFace", "lcd", listOf("lcd" to "Handheld", "neon" to "Neon", "stream" to "Streaming"))
                    SChips("Equalizer", "musEq", "bars", listOf("bars" to "Bars", "mirror" to "Mirror", "wave" to "Wave", "dots" to "Dots", "circle" to "Circle"))
                    SChips("Cover", "coverMode", "original", listOf("original" to "Original", "custom" to "Mine only", "off" to "Off"))
                    if (cur != null) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Btn("MY COVER…") { Picker.pick(arrayOf("image/*")) { u -> u.firstOrNull()?.let { uri -> val f = File(Library.art, "cov-${System.currentTimeMillis()}.img"); try { ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }; Store.set("cov_" + cur.path, f.path) } catch (_: Exception) {} } } }
                        Btn("RESET COVER") { Store.set("cov_" + cur.path, "") } }
                    SChips("Time", "timeFmt", "auto", listOf("auto" to "Hours when long", "minutes" to "Minutes only"))
                    Text("Details in the list:", color = Color.White, fontSize = 12.sp); SToggle("Length", "musDetLen", true); SToggle("File size", "musDetSize", true); SToggle("Date added", "musDetDate", false); SToggle("File format (MP3, FLAC...)", "musDetFmt", false)
                    SChips("Sort by", "musSort", "added", listOf("added" to "Order added", "name" to "Name", "date" to "Date", "size" to "Size", "artist" to "Artist")); SToggle("Reverse order", "musRev", false)
                }
            }
        }
        val rows: androidx.compose.foundation.lazy.LazyListScope.() -> Unit = {
            item { Spacer(Modifier.height(0.dp)) }
            itemsIndexed(shown) { i, tr ->
                val sel = tr.path in chosen
                Row(Modifier.fillMaxWidth().background(if (tr.path == cur?.path) Color.White.copy(.14f) else Color.Transparent).forgeClick { if (select) chosen = if (sel) chosen - tr.path else chosen + tr.path else Music.playPath(tr.path, shown.map { it.path }) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (select) Checkbox(sel, { chosen = if (it) chosen + tr.path else chosen - tr.path })
                    Column(Modifier.weight(1f)) {
                        Text((if (tr.path == cur?.path && Music.playing) "▶ " else "") + tr.title, color = if (tr.path == cur?.path) skin.accent else Color.White, maxLines = 1)
                        val len by produceState(0L, tr.path) { value = withContext(Dispatchers.IO) { if (Store.b("musDetLen", true)) Music.lengthMs(tr) else 0L } }
                        val bits = listOfNotNull(if (Store.b("musDetFmt", false)) tr.path.substringAfterLast('.').uppercase().take(6) else null, Music.artist(tr).takeIf { it.isNotEmpty() }, if (Store.b("musDetLen", true) && len > 0) fmt(len.toInt()) else null, if (Store.b("musDetSize", true)) mb(Music.sizeOf(tr)).ifEmpty { null } else null,
                            if (Store.b("musDetDate", false) && Music.dateOf(tr) > 0) java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(Music.dateOf(tr))) else null)
                        if (bits.isNotEmpty()) Text(bits.joinToString("  ·  "), color = Color(0x99FFFFFF), fontSize = 10.sp, maxLines = 1)
                    }
                    if (move && !select) {
                        val up = { if (list == "all") Music.moveInAll(tr.path, -1) else if (isUser(list) || list == FAV) Playlists.move(list, i, i - 1) }
                        val down = { if (list == "all") Music.moveInAll(tr.path, 1) else if (isUser(list) || list == FAV) Playlists.move(list, i, i + 1) }
                        Text("▲", color = Color.White, fontSize = 18.sp, modifier = Modifier.clickable { up() }.padding(8.dp)); Text("▼", color = Color.White, fontSize = 18.sp, modifier = Modifier.clickable { down() }.padding(8.dp))
                    }
                    if (!select) { val fav = tr.path in Playlists.tracks(FAV); Text(if (fav) "♥" else "♡", color = if (fav) Color(0xFFFF5252) else Color.White, fontSize = 18.sp, modifier = Modifier.clickable { if (fav) Playlists.remove(FAV, listOf(tr.path)) else Playlists.add(FAV, listOf(tr.path)) }.padding(8.dp)) }
                }
            }
        }
        val header: @Composable () -> Unit = {
            Column(Modifier.padding(10.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Btn("+ ADD MUSIC") { Picker.pick(arrayOf("audio/*", "application/ogg", "application/octet-stream")) { Music.addFiles(ctx, it, if (isUser(list) || list == FAV) list else null) } }
                    Btn("REFRESH LIST") { Music.scan(true) }
                    if (Music.failed.isNotEmpty()) Btn("FAILED (${Music.failed.size})", color = Color(0xFFE53935)) { showFailed = true }
                    Btn(if (select) "DONE" else "SELECT", selected = select) { select = !select; chosen = emptySet() }
                    Btn(if (move) "DONE MOVING" else "MOVE", selected = move) { move = !move }
                }
                if (Music.importStatus.isNotEmpty()) Text(Music.importStatus, color = skin.accent, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SYSTEM_LISTS.forEach { (k, n) -> Btn("$n (${counts[k] ?: 0})", selected = list == k) { list = k; chosen = emptySet() } }
                    Playlists.names.filter { it != FAV }.forEach { n -> Btn("$n (${Playlists.tracks(n).size})", selected = list == n) { list = n; chosen = emptySet() } }
                    Btn("+ PLAYLIST") { newList = true }
                }
                Text("${shown.size} track${if (shown.size == 1) "" else "s"} · $artistCount artists" + (if (list != "all") " in “${SYSTEM_LISTS.firstOrNull { it.first == list }?.second ?: list}”" else ""), color = Color(0xAAFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                if (isUser(list)) Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                    Btn("MERGE WITH…") { mergeFrom = list }; Btn("UNGROUP (delete playlist)") { confirm.ask("Delete playlist “$list”?", "remove the playlist and its order", "delete any music files", true) { Playlists.delete(list); list = "all" } } }
                if (select) Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Btn("ALL") { chosen = shown.map { it.path }.toSet() }; Btn("NONE") { chosen = emptySet() }; Text("${chosen.size} selected", color = Color.White, fontSize = 12.sp)
                    Box { Btn("ADD TO…") { addMenu = true }; DropdownMenu(addMenu, { addMenu = false }) { Playlists.names.forEach { n -> DropdownMenuItem({ Text(n) }, { Playlists.add(n, chosen); addMenu = false; select = false; chosen = emptySet() }) } } }
                    if (isUser(list) || list == FAV) Btn("REMOVE FROM LIST") { Playlists.remove(list, chosen); chosen = emptySet() }
                    Btn("DELETE", color = Color(0xFFE53935)) { if (chosen.isNotEmpty()) delAsk = true }
                }
            }
        }
        if (wide) Row(Modifier.fillMaxSize()) { Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { player(Modifier.fillMaxWidth()) }; LazyColumn(Modifier.weight(1f)) { item { header() }; rows() } }
        else LazyColumn(Modifier.fillMaxSize()) { item { player(Modifier.fillMaxWidth()) }; item { header() }; rows() }
        Box(Modifier.align(Alignment.BottomCenter)) { MiniPlayerBar() }
    }
    if (showQueue) QueueDialog { showQueue = false }
    confirm.Host()
    if (delAsk) {
        val names = Music.tracks.filter { it.path in chosen }
        AlertDialog(onDismissRequest = { delAsk = false },
            confirmButton = { TextButton({ names.forEach { tr -> if (!tr.isUri) { File(tr.path).delete(); Playlists.names.forEach { Playlists.remove(it, listOf(tr.path)) } } }; delAsk = false; select = false; chosen = emptySet(); Music.scan() }) { Text("Delete ${names.size}") } },
            dismissButton = { TextButton({ delAsk = false }) { Text("Cancel") } }, title = { Text("Are you sure?") },
            text = { Column { Text("These files will be deleted from the app (linked-folder tracks are only removed from lists):", fontSize = 12.sp); Column(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())) { names.forEach { Text("• " + it.title, fontSize = 11.sp) } } } })
    }
    if (newList) { var nm by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { newList = false }, confirmButton = { TextButton({ Playlists.create(nm); newList = false }) { Text("Create") } }, dismissButton = { TextButton({ newList = false }) { Text("Cancel") } },
            title = { Text("New playlist") }, text = { OutlinedTextField(nm, { nm = it }, singleLine = true, label = { Text("Name") }) }) }
    mergeFrom?.let { from -> AlertDialog(onDismissRequest = { mergeFrom = null }, confirmButton = {}, dismissButton = { TextButton({ mergeFrom = null }) { Text("Cancel") } }, title = { Text("Merge “$from” with…") },
        text = { Column { Playlists.names.filter { it != from && it != FAV }.forEach { o -> Btn(o, Modifier.fillMaxWidth().padding(2.dp)) { Playlists.merge(from, o, from); list = from; mergeFrom = null } } } }) }
    if (showFailed) AlertDialog(onDismissRequest = { showFailed = false },
        confirmButton = { TextButton({ Picker.pick(arrayOf("audio/*", "application/octet-stream")) { Music.addFiles(ctx, it) }; showFailed = false }) { Text("Try files again") } },
        dismissButton = { Row { TextButton({ Music.clearFailed(); showFailed = false }) { Text("Clear list") }; TextButton({ showFailed = false }) { Text("Close") } } },
        title = { Text("Files that could not be added") },
        text = { Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
            Text("This is only a catalogue, not a playlist. Each entry says why.", fontSize = 11.sp)
            Music.failed.forEach { f -> Column(Modifier.padding(vertical = 4.dp)) { Text(f.name, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text(f.reason, fontSize = 11.sp, color = Color(0xFFFFB74D)); Text(f.why, fontSize = 10.sp) } } } })
}

private fun Brush3(a: Color, b: Color) = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(a, b))
@Composable private fun Key(text: String, big: Boolean = false, onClick: () -> Unit) =
    Box(Modifier.size(if (big) 52.dp else 40.dp).clip(RoundedCornerShape(50)).background(if (big) Skins.current().accent else Color(0xFF111114)).forgeClick(onClick = onClick), Alignment.Center) { Text(text, color = if (big) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = if (big) 20.sp else 12.sp) }

/** progress bar + time: owns its own once-per-0.3-second timer, so only this small piece redraws while a song plays */
@Composable
private fun ProgressBar(accent: Color) {
    var pos by remember { mutableIntStateOf(0) }; var dur by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { pos = Music.pos(); dur = Music.dur(); kotlinx.coroutines.delay(300) } }
    var w by remember { mutableStateOf(IntSize.Zero) }
    Column {
        androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(26.dp).onSizeChanged { w = it }.pointerInput(dur) {
            detectDragGestures(onDragStart = { o -> if (dur > 0 && w.width > 0) Music.seek((o.x / w.width * dur).toInt()) }, onDrag = { c, _ -> if (dur > 0 && w.width > 0) Music.seek((c.position.x / w.width).coerceIn(0f, 1f).times(dur).toInt()) })
        }) {
            drawRect(Color.White.copy(.2f), Offset(0f, size.height / 2 - 3f), Size(size.width, 6f)); drawRect(accent, Offset(0f, size.height / 2 - 3f), Size(if (dur > 0) size.width * pos / dur else 0f, 6f))
        }
        Text("${fmt(pos)} / ${fmt(dur)}", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}

object MiniHide { var hidden by mutableStateOf(false) }

@Composable
fun QueueDialog(close: () -> Unit) {
    val q = Music.queueView(); val skin = Skins.current()
    fun title(p: String) = Music.byPath[p]?.title ?: p.substringAfterLast('/')
    AlertDialog(onDismissRequest = close, confirmButton = { TextButton(close) { Text("Close") } },
        title = { Text(if (q.shuffled) "Queue · shuffled order" else "Queue · list order") },
        text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
            if (q.before.isNotEmpty()) {
                Text(if (q.shuffled) "Played before (BACK walks through these, newest last)" else "Before this song", fontSize = 11.sp, color = Color(0x99FFFFFF))
                q.before.forEach { p -> Text("   " + title(p), fontSize = 13.sp, modifier = Modifier.fillMaxWidth().clickable { Music.jumpTo(p); close() }.padding(vertical = 5.dp)) }
            }
            Text("▶ NOW: " + (q.current?.let { title(it) } ?: "nothing playing"), color = skin.accent, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 6.dp))
            Text(if (q.shuffled) "Coming up (random, every song once per round)" else "Next in the list", fontSize = 11.sp, color = Color(0x99FFFFFF))
            q.after.forEachIndexed { i, p -> Text("${i + 1}.  " + title(p), fontSize = 13.sp, modifier = Modifier.fillMaxWidth().clickable { Music.jumpTo(p); close() }.padding(vertical = 5.dp)) }
            if (q.shuffled && q.after.isEmpty()) Text("The next song is picked at random when this one ends. A new round starts once every song has played.", fontSize = 12.sp)
            Text("Tap any song to jump to it.", fontSize = 10.sp, color = Color(0x99FFFFFF), modifier = Modifier.padding(top = 8.dp))
        } })
}

/** compact player shown under the tab bar on every tab: queue, hide (comes back as a small ♪ chip), previous / play / next */
@Composable
fun MiniPlayerBar(modifier: Modifier = Modifier) {
    val cur = Music.tracks.getOrNull(Music.current) ?: return
    if (!Store.b("miniBanner", true)) return
    var q by remember { mutableStateOf(false) }
    if (MiniHide.hidden) {
        Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { Text("♪", color = Color.White, fontSize = 16.sp, modifier = Modifier.padding(6.dp).clip(RoundedCornerShape(16.dp)).background(Color.Black.copy(.6f)).clickable { MiniHide.hidden = false }.padding(horizontal = 12.dp, vertical = 6.dp)) }
        return
    }
    Row(modifier.fillMaxWidth().background(Color.Black.copy(.7f)).padding(horizontal = 10.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("♪ " + cur.title, color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f).clickable { q = true })
        Key("⏮") { Music.prev() }; Spacer(Modifier.width(4.dp)); Key(if (Music.playing) "⏸" else "▶") { Music.toggle() }; Spacer(Modifier.width(4.dp)); Key("⏭") { Music.next() }
        Spacer(Modifier.width(4.dp)); Key("☰") { q = true }; Spacer(Modifier.width(4.dp)); Key("▾") { MiniHide.hidden = true }
    }
    if (q) QueueDialog { q = false }
}
