package com.sonicforge.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

/** One on-screen control. x/y are fractions of the screen, s is a size multiplier. */
data class CtrlEl(val id: String, val x: Float, val y: Float, val s: Float = 1f, val on: Boolean = true)

data class PadLayout(
    val stick: Boolean = false, val opacity: Float = 0.75f, val shape: String = "round",
    val land: List<CtrlEl>, val port: List<CtrlEl>
) {
    fun els(landscape: Boolean) = if (landscape) land else port
    fun edit(landscape: Boolean, id: String, f: (CtrlEl) -> CtrlEl): PadLayout {
        val m = { l: List<CtrlEl> -> l.map { if (it.id == id) f(it) else it } }
        return if (landscape) copy(land = m(land)) else copy(port = m(port))
    }
    fun toJson(): String {
        fun arr(l: List<CtrlEl>) = JSONArray().also { a -> l.forEach { a.put(JSONObject().put("id", it.id).put("x", it.x.toDouble()).put("y", it.y.toDouble()).put("s", it.s.toDouble()).put("on", it.on)) } }
        return JSONObject().put("stick", stick).put("opacity", opacity.toDouble()).put("shape", shape).put("land", arr(land)).put("port", arr(port)).toString()
    }
    companion object {
        fun fromJson(t: String): PadLayout? = try {
            val o = JSONObject(t)
            fun els(a: JSONArray) = (0 until a.length()).map { val e = a.getJSONObject(it); CtrlEl(e.getString("id"), e.getDouble("x").toFloat(), e.getDouble("y").toFloat(), e.getDouble("s").toFloat(), e.getBoolean("on")) }
            val d = default()
            val l = els(o.getJSONArray("land")); val p = els(o.getJSONArray("port"))   // older saves get any new buttons added automatically
            PadLayout(o.getBoolean("stick"), o.getDouble("opacity").toFloat(), o.getString("shape"),
                l + d.land.filter { n -> l.none { it.id == n.id } }, p + d.port.filter { n -> p.none { it.id == n.id } })
        } catch (_: Exception) { null }
        fun default() = PadLayout(
            land = listOf(
                CtrlEl("dpad", .14f, .64f), CtrlEl("A", .66f, .78f), CtrlEl("B", .78f, .68f), CtrlEl("C", .90f, .56f),
                CtrlEl("X", .66f, .42f, .8f, false), CtrlEl("Y", .78f, .32f, .8f, false), CtrlEl("Z", .90f, .22f, .8f, false),
                CtrlEl("START", .56f, .90f), CtrlEl("MODE", .44f, .90f), CtrlEl("SAVE", .36f, .10f), CtrlEl("LOAD", .46f, .10f), CtrlEl("MENU", .56f, .10f),
                CtrlEl("REW", .14f, .10f), CtrlEl("FF", .24f, .10f), CtrlEl("L", .08f, .22f, .9f, false), CtrlEl("R", .92f, .22f, .9f, false)),
            port = listOf(
                CtrlEl("dpad", .24f, .83f), CtrlEl("A", .56f, .90f), CtrlEl("B", .72f, .82f), CtrlEl("C", .88f, .72f),
                CtrlEl("X", .50f, .76f, .8f, false), CtrlEl("Y", .66f, .68f, .8f, false), CtrlEl("Z", .82f, .60f, .8f, false),
                CtrlEl("START", .62f, .66f), CtrlEl("MODE", .38f, .66f), CtrlEl("SAVE", .20f, .60f), CtrlEl("LOAD", .30f, .60f), CtrlEl("MENU", .80f, .60f),
                CtrlEl("REW", .46f, .58f), CtrlEl("FF", .56f, .58f), CtrlEl("L", .12f, .52f, .9f, false), CtrlEl("R", .88f, .52f, .9f, false))
        )
    }
}

/** Ready-made layouts (slots 11..16, not editable) built by the program. */
object Factory {
    val names = mapOf(17 to "GBA / Game Boy", 11 to "Classic ABC", 12 to "Close ABC", 13 to "6-button wide", 14 to "6-button close", 15 to "Stick + ABC close", 16 to "Stick + 6-button close")
    private fun e(id: String, x: Float, y: Float, s: Float = 1f, on: Boolean = true) = CtrlEl(id, x, y, s, on)
    private fun buttons(land: Boolean, six: Boolean, close: Boolean): List<CtrlEl> = if (land) when {
        !close -> listOf(e("A", .66f, .78f), e("B", .78f, .68f), e("C", .90f, .56f), e("X", .66f, .42f, .8f, six), e("Y", .78f, .32f, .8f, six), e("Z", .90f, .22f, .8f, six))
        six -> listOf(e("A", .70f, .84f, .85f), e("B", .79f, .84f, .85f), e("C", .88f, .84f, .85f), e("X", .70f, .68f, .85f), e("Y", .79f, .68f, .85f), e("Z", .88f, .68f, .85f))
        else -> listOf(e("A", .72f, .80f, .9f), e("B", .81f, .70f, .9f), e("C", .90f, .60f, .9f), e("X", .72f, .62f, .8f, false), e("Y", .81f, .52f, .8f, false), e("Z", .90f, .42f, .8f, false))
    } else when {
        !close -> listOf(e("A", .56f, .90f), e("B", .72f, .82f), e("C", .88f, .72f), e("X", .50f, .76f, .8f, six), e("Y", .66f, .68f, .8f, six), e("Z", .82f, .60f, .8f, six))
        six -> listOf(e("A", .55f, .92f, .9f), e("B", .72f, .92f, .9f), e("C", .89f, .92f, .9f), e("X", .55f, .79f, .9f), e("Y", .72f, .79f, .9f), e("Z", .89f, .79f, .9f))
        else -> listOf(e("A", .60f, .90f, .9f), e("B", .74f, .82f, .9f), e("C", .88f, .74f, .9f), e("X", .60f, .74f, .8f, false), e("Y", .74f, .66f, .8f, false), e("Z", .88f, .58f, .8f, false))
    }
    private fun gba(): PadLayout = PadLayout(stick = false, opacity = .75f, shape = "round",
        land = listOf(e("dpad", .14f, .64f), e("A", .88f, .66f), e("B", .78f, .78f), e("L", .08f, .16f), e("R", .92f, .16f), e("START", .56f, .94f), e("MODE", .44f, .94f), e("SAVE", .36f, .08f), e("LOAD", .46f, .08f), e("MENU", .56f, .08f), e("REW", .24f, .08f), e("FF", .30f, .08f)),
        port = listOf(e("dpad", .22f, .84f), e("A", .88f, .78f), e("B", .74f, .88f), e("L", .12f, .60f), e("R", .88f, .60f), e("START", .62f, .66f), e("MODE", .38f, .66f), e("SAVE", .20f, .54f), e("LOAD", .30f, .54f), e("MENU", .80f, .54f), e("REW", .46f, .56f), e("FF", .56f, .56f)))
    fun build(n: Int): PadLayout {
        if (n == 17) return gba()
        val six = n == 13 || n == 14 || n == 16; val close = n != 11 && n != 13; val stick = n == 15 || n == 16
        val land = listOf(e("dpad", .14f, .64f)) + buttons(true, six, close) + listOf(e("START", .56f, .94f), e("MODE", .44f, .94f), e("SAVE", .36f, .08f), e("LOAD", .46f, .08f), e("MENU", .56f, .08f), e("REW", .14f, .08f), e("FF", .24f, .08f), e("L", .08f, .22f, .9f, false), e("R", .92f, .22f, .9f, false))
        val port = listOf(e("dpad", .22f, .84f)) + buttons(false, six, close) + listOf(e("START", .62f, .64f), e("MODE", .38f, .64f), e("SAVE", .20f, .58f), e("LOAD", .30f, .58f), e("MENU", .80f, .58f), e("REW", .46f, .56f), e("FF", .56f, .56f), e("L", .12f, .52f, .9f, false), e("R", .88f, .52f, .9f, false))
        return PadLayout(stick = stick, opacity = .75f, shape = "round", land = land, port = port)
    }
}

/** User slots 1..6 (editable, each has its own colour) + ready-made 11..16 + the active layout. All writes are read-back verified. */
object PadLayouts {
    val slotColors = listOf(Color(0xFFE53935), Color(0xFFFB8C00), Color(0xFFFDD835), Color(0xFF43A047), Color(0xFF1E88E5), Color(0xFF8E24AA))
    val factoryColors = listOf(Color(0xFF00BCD4), Color(0xFF26C6DA), Color(0xFF80DEEA), Color(0xFF4DB6AC), Color(0xFF9575CD), Color(0xFFBA68C8))
    var active by mutableStateOf(PadLayout.default())
    var activeSlot by mutableStateOf(0)       // 0 = working copy, 1..6 = my preset, 11..16 = ready-made
    fun colorOf(n: Int): Color? = when (n) { in 1..6 -> slotColors[n - 1]; in 11..16 -> factoryColors[n - 11]; 17 -> Color(0xFF7986CB); else -> null }
    fun init() {
        Store.read("layout_active.json")?.let { PadLayout.fromJson(it) }?.let { active = it }
        activeSlot = Store.i("layoutSlot", 0)
    }
    /** rotation: 0 portrait, 1 landscape, 2 portrait flipped, 3 landscape flipped. mode "layout" = per layout, "all" = one value, "pairs" = portrait pair / landscape pair */
    fun opacityFor(rotation: Int, own: Float): Float = when (Store.s("opMode", "layout")) {
        "all" -> Store.i("opAll", 75) / 100f
        "pairs" -> (if (rotation == 1 || rotation == 3) Store.i("opLandPair", 75) else Store.i("opPortPair", 75)) / 100f
        else -> own }
    fun update(l: PadLayout) { active = l }
    fun persistActive() { Store.writeVerified("layout_active.json", active.toJson()) }
    fun commit() { val ok = Store.writeVerified("layout_active.json", active.toJson()); Store.events.tryEmit(SaveEvent("Layout saved", ok)) }
    fun slot(n: Int): PadLayout? = if (n >= 11) Factory.build(n) else Store.read("layout_slot$n.json")?.let { PadLayout.fromJson(it) }
    fun saveSlot(n: Int): Boolean {
        if (n !in 1..6) return false
        val ok = Store.writeVerified("layout_slot$n.json", active.toJson()) && slot(n) == active
        if (ok) { activeSlot = n; Store.setI("layoutSlot", n) }
        persistActive()
        Store.events.tryEmit(SaveEvent("Preset $n saved", ok)); return ok
    }
    fun loadSlot(n: Int): Boolean {
        val l = slot(n) ?: run { Store.events.tryEmit(SaveEvent("Preset $n is empty", false)); return false }
        active = l; activeSlot = n; Store.setI("layoutSlot", n); persistActive()
        Store.events.tryEmit(SaveEvent(if (n >= 11) "${Factory.names[n]} loaded" else "Preset $n loaded", true)); return true
    }
}
