package com.sonicforge.core

data class ShaderDef(val id: String, val name: String, val body: String)

object Shaders {
    const val VERT = """#version 300 es
layout(location=0) in vec2 aPos; out vec2 vUv;
void main(){ vUv = vec2(aPos.x*0.5+0.5, 0.5-aPos.y*0.5); gl_Position = vec4(aPos,0.0,1.0); }"""

    private const val PRE = """#version 300 es
precision highp float;
in vec2 vUv; out vec4 fragColor;
uniform sampler2D uTex; uniform vec2 uTexSize; uniform vec2 uOut; uniform float uTime;
vec3 S(vec2 uv){ return texture(uTex, uv).rgb; }
float H(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233))) * 43758.5453); }
vec3 sat(vec3 c, float s){ float l = dot(c, vec3(.299,.587,.114)); return mix(vec3(l), c, s); }
"""

    val list = listOf(
        ShaderDef("none", "Clean", "void main(){ fragColor = vec4(S(vUv),1.0); }"),
        ShaderDef("crt", "CRT Scanlines", """
void main(){
  vec2 uv = vUv*2.0-1.0; uv *= 1.0 + dot(uv,uv)*0.05; uv = uv*0.5+0.5;
  if(uv.x<0.||uv.x>1.||uv.y<0.||uv.y>1.){ fragColor=vec4(0,0,0,1); return; }
  vec3 c = S(uv);
  c *= 0.80 + 0.20*sin(uv.y*uTexSize.y*6.28318);
  c *= 0.92 + 0.08*sin(vUv.x*uOut.x*3.14159);
  c *= 1.0 - 0.45*pow(length(vUv-0.5)*1.15, 2.2);
  fragColor = vec4(c*1.15, 1.0);
}"""),
        ShaderDef("bloom", "Bloom Glow", """
void main(){
  vec3 c = S(vUv); vec3 b = vec3(0.0); vec2 px = 1.5/uTexSize;
  for(int i=-2;i<=2;i++) for(int j=-2;j<=2;j++){ b += max(S(vUv+vec2(float(i),float(j))*px)-0.5, 0.0); }
  fragColor = vec4(c + b/25.0*2.4, 1.0);
}"""),
        ShaderDef("bloomlite", "Bloom Light", """
void main(){
  vec3 c = S(vUv); vec3 b = vec3(0.0); vec2 px = 1.2/uTexSize;
  for(int i=-1;i<=1;i++) for(int j=-1;j<=1;j++){ b += max(S(vUv+vec2(float(i),float(j))*px)-0.62, 0.0); }
  fragColor = vec4(c + b/9.0*1.1, 1.0);
}"""),
        ShaderDef("anime", "Anime Cel", """
void main(){
  vec2 px = 1.0/uTexSize; vec3 c = S(vUv);
  float e = abs(dot(S(vUv+vec2(px.x,0.)) - S(vUv-vec2(px.x,0.)), vec3(.333))) + abs(dot(S(vUv+vec2(0.,px.y)) - S(vUv-vec2(0.,px.y)), vec3(.333)));
  c = sat(c, 1.45); c = floor(c*6.0+0.5)/6.0; c = c*0.92 + vec3(0.08,0.07,0.09);
  c *= 1.0 - smoothstep(0.10,0.35,e)*0.85;
  fragColor = vec4(c,1.0);
}"""),
        ShaderDef("cinematic", "Cinematic", """
void main(){
  if(abs(vUv.y-0.5) > 0.405){ fragColor = vec4(0,0,0,1); return; }
  vec3 c = S(vUv);
  float l = dot(c, vec3(.299,.587,.114));
  c = mix(c*vec3(0.88,1.0,1.12), c*vec3(1.15,1.0,0.85), smoothstep(0.25,0.75,l));
  c = (c-0.5)*1.12+0.5; c = sat(c, 0.9);
  c *= 1.0 - 0.6*pow(length(vUv-0.5)*1.25, 2.4);
  c += (H(vUv*uTexSize + uTime) - 0.5) * 0.05;
  fragColor = vec4(c,1.0);
}"""),
        ShaderDef("vibes", "VHS Vibes", """
void main(){
  vec2 uv = vUv;
  float g = step(0.96, H(vec2(floor(uTime*8.0), floor(uv.y*60.0))));
  uv.x += g*0.01 + sin(uv.y*30.0+uTime*2.0)*0.0008;
  float o = 0.003;
  vec3 c = vec3(S(uv+vec2(o,0.)).r, S(uv).g, S(uv-vec2(o,0.)).b);
  c *= vec3(1.05,0.9,1.2); c *= 0.9 + 0.1*sin(uv.y*uTexSize.y*3.14159*2.0);
  c += (H(uv*uTexSize + uTime) - 0.5) * 0.06;
  fragColor = vec4(c,1.0);
}"""),
        ShaderDef("greenhill", "Green Hill", """
void main(){
  vec3 c = S(vUv); vec3 b = vec3(0.0); vec2 px = 1.2/uTexSize;
  for(int i=-1;i<=1;i++) for(int j=-1;j<=1;j++) b += S(vUv+vec2(float(i),float(j))*px);
  c = mix(c, b/9.0, 0.25); c = sat(c, 1.3) * vec3(1.06,1.03,0.94);
  c = pow(c, vec3(0.93));
  fragColor = vec4(c,1.0);
}"""),
        ShaderDef("future", "Future Neon", """
void main(){
  vec3 c = S(vUv); vec2 px = 1.0/uTexSize;
  float e = length(S(vUv+vec2(px.x,0.)) - S(vUv-vec2(px.x,0.))) + length(S(vUv+vec2(0.,px.y)) - S(vUv-vec2(0.,px.y)));
  c = c*vec3(0.75,1.0,1.2) + vec3(0.0,0.9,1.0)*e*0.9;
  vec2 g = fract(vUv*uTexSize*vec2(1.0,1.0));
  c *= 0.9 + 0.1*step(0.12, min(g.x,g.y));
  c += 0.04*sin(vUv.y*20.0 - uTime*2.0);
  fragColor = vec4(c,1.0);
}"""),
        ShaderDef("sakura", "Sakura", """
void main(){
  vec3 c = S(vUv); c = mix(c, c*vec3(1.12,0.95,1.05), 0.7); c = sat(c, 1.1) + vec3(0.05,0.0,0.03);
  vec2 p = vUv*vec2(uOut.x/uOut.y, 1.0)*14.0; p.y += uTime*0.6; p.x += sin(uTime+p.y)*0.4;
  vec2 id = floor(p); vec2 f = fract(p)-0.5;
  float on = step(0.93, H(id)); c += vec3(1.0,0.7,0.8)*on*smoothstep(0.18,0.05,length(f))*0.8;
  fragColor = vec4(c,1.0);
}"""),
        ShaderDef("lcd", "Pixel LCD", """
void main(){ vec2 p = vUv*uTexSize; vec2 f = fract(p); vec3 c = S((floor(p)+0.5)/uTexSize);
  float g = smoothstep(0.0,0.18,f.x)*smoothstep(0.0,0.18,f.y); fragColor = vec4(c*mix(0.5,1.0,g)*1.18, 1.0); }"""),
        ShaderDef("gameboy", "Pocket Green", """
void main(){ float l = dot(S(vUv), vec3(.299,.587,.114));
  vec3 a = vec3(.06,.22,.06), b = vec3(.19,.38,.19), c = vec3(.55,.67,.06), d = vec3(.61,.74,.06);
  vec3 o = l < 0.25 ? a : (l < 0.5 ? b : (l < 0.75 ? c : d));
  vec2 f = fract(vUv*uTexSize); o *= 0.9 + 0.1*step(0.1, min(f.x,f.y)); fragColor = vec4(o,1.0); }"""),
        ShaderDef("sepia", "Old Film", """
void main(){ vec3 c = S(vUv); float l = dot(c, vec3(.299,.587,.114)); vec3 s = vec3(l*1.07, l*0.74, l*0.43);
  s *= 1.0 - 0.5*pow(length(vUv-0.5)*1.2, 2.0); s += (H(vUv*uTexSize + uTime) - 0.5)*0.06; fragColor = vec4(s,1.0); }"""),
        ShaderDef("noir", "Comic Noir", """
void main(){ vec3 c = S(vUv); float l = dot(c, vec3(.299,.587,.114)); vec2 g = fract(vUv*uTexSize*0.5) - 0.5;
  float dots = step(length(g), l*0.65); vec3 o = vec3(mix(l, dots, 0.5)); o = smoothstep(0.08, 0.92, o); fragColor = vec4(o,1.0); }"""),
        ShaderDef("glitch", "Glitch", """
void main(){ vec2 uv = vUv; float row = floor(uv.y*24.0); float t = floor(uTime*9.0); float on = step(0.85, H(vec2(row,t)));
  uv.x += on*(H(vec2(t,row)) - 0.5)*0.08; float o = 0.004 + on*0.012;
  vec3 c = vec3(S(uv+vec2(o,0.)).r, S(uv).g, S(uv-vec2(o,0.)).b); c += on*0.08; fragColor = vec4(c,1.0); }"""),
        ShaderDef("synthwave", "Synthwave", """
void main(){ vec3 c = S(vUv); float l = dot(c, vec3(.299,.587,.114));
  c = mix(vec3(l)*vec3(1.1,0.5,1.2), c*vec3(1.15,0.85,1.25), 0.55);
  c += vec3(0.9,0.2,0.7)*smoothstep(0.55,1.0,vUv.y)*0.18; c += vec3(0.0,0.8,1.0)*smoothstep(0.45,0.0,vUv.y)*0.12;
  c *= 0.92 + 0.08*sin(vUv.y*uTexSize.y*3.14159*2.0); fragColor = vec4(c,1.0); }"""),
        ShaderDef("aqua", "Aqua Zone", """
void main(){ vec2 uv = vUv; uv.x += sin(uv.y*28.0+uTime*2.0)*0.004; uv.y += sin(uv.x*22.0+uTime*1.6)*0.003;
  vec3 c = S(uv)*vec3(0.75,1.0,1.15); float ca = sin(uv.x*40.0+uTime)*sin(uv.y*36.0-uTime*1.3);
  c += vec3(0.0,0.12,0.14)*smoothstep(0.6,1.0,ca); fragColor = vec4(c,1.0); }"""),
        ShaderDef("snow", "Snowfall", """
void main(){ vec3 c = S(vUv); c = mix(c, c*vec3(0.9,1.0,1.15), 0.6) + vec3(0.0,0.02,0.05);
  for(int k=0;k<2;k++){ float sc = 10.0 + float(k)*8.0; vec2 p = vUv*vec2(uOut.x/uOut.y,1.0)*sc; p.y += uTime*(0.5+float(k)*0.4); p.x += sin(uTime*0.7+p.y)*0.3;
    vec2 id = floor(p); vec2 f = fract(p) - 0.5; float on = step(0.9, H(id+float(k)*7.0)); c += vec3(1.0)*on*smoothstep(0.14,0.04,length(f)); }
  fragColor = vec4(c,1.0); }"""),
        ShaderDef("ember", "Lava Embers", """
void main(){ vec3 c = S(vUv)*vec3(1.12,0.95,0.85); c += vec3(0.15,0.04,0.0)*smoothstep(0.7,1.0,vUv.y);
  vec2 p = vUv*vec2(uOut.x/uOut.y,1.0)*16.0; p.y -= uTime*1.2; p.x += sin(uTime+p.y*0.8)*0.4;
  vec2 id = floor(p); vec2 f = fract(p) - 0.5; float on = step(0.92, H(id)); c += vec3(1.0,0.5,0.1)*on*smoothstep(0.12,0.02,length(f)); fragColor = vec4(c,1.0); }"""),
        ShaderDef("emerald", "Emerald Sparkle", """
void main(){ vec3 c = S(vUv); c = mix(c, c*vec3(0.85,1.15,1.0), 0.6); vec2 g = floor(vUv*uTexSize*0.5);
  float tw = step(0.985, H(g))*(0.5 + 0.5*sin(uTime*5.0 + H(g+3.0)*6.28)); c += vec3(0.4,1.0,0.7)*tw*0.8; fragColor = vec4(c,1.0); }"""),
        ShaderDef("dream", "Dream Glow", """
void main(){ vec3 c = S(vUv); vec3 b = vec3(0.0); vec2 px = 2.5/uTexSize;
  for(int i=-2;i<=2;i++) for(int j=-2;j<=2;j++) b += S(vUv+vec2(float(i),float(j))*px);
  b /= 25.0; c = mix(c, b, 0.45); c = sat(c, 0.85) + vec3(0.04,0.02,0.06); c = pow(c, vec3(0.9)); fragColor = vec4(c,1.0); }"""),
        ShaderDef("arcade", "Arcade Cabinet", """
void main(){ vec2 uv = vUv*2.0-1.0; uv *= 1.0 + dot(uv,uv)*0.09; vec2 q = uv*0.5+0.5;
  if(q.x<0.||q.x>1.||q.y<0.||q.y>1.){ fragColor = vec4(0,0,0,1); return; }
  vec3 c = S(q); float m = mod(floor(vUv.x*uOut.x), 3.0);
  c *= vec3(m==0.0?1.0:0.78, m==1.0?1.0:0.78, m==2.0?1.0:0.78); c *= 0.82 + 0.18*sin(q.y*uTexSize.y*6.28318); c *= 1.25; fragColor = vec4(c,1.0); }"""),
    ).map { it.copy(body = PRE + it.body) }

    fun byId(id: String) = list.firstOrNull { it.id == id } ?: list[0]
}
