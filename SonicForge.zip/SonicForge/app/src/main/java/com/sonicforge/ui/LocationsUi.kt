package com.sonicforge.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import com.sonicforge.data.Logger
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.audio.Music
import com.sonicforge.data.Library
import com.sonicforge.data.Store
import java.io.File

private fun sizeOf(f: File): String { val b = f.walkTopDown().filter { it.isFile }.sumOf { it.length() }; return if (b < 1048576) "${b / 1024} KB" else "%.1f MB".format(b / 1048576.0) }
private fun count(f: File) = f.walkTopDown().count { it.isFile }
private fun copyPath(ctx: Context, p: String) { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("path", p)); Toast.makeText(ctx, "Path copied", Toast.LENGTH_SHORT).show() }
private fun openExternal(ctx: Context, sub: String) {
    if (Store.s("extFm").isNotEmpty()) { copyPath(ctx, ctx.getExternalFilesDir(null)?.path + "/" + sub); if (ExternalApps.launch(ctx, "extFm")) return }
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("content://com.android.externalstorage.documents/document/primary%3AAndroid%2Fdata%2F${ctx.packageName}%2Ffiles%2F$sub"), "vnd.android.document/directory").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (_: Exception) { Toast.makeText(ctx, "Android blocks opening Android/data here. Path copied; use the in-app buttons instead.", Toast.LENGTH_LONG).show(); copyPath(ctx, ctx.getExternalFilesDir(null)?.path + "/" + sub) }
}

@Composable
private fun Loc(title: String, path: String, what: String, content: @Composable () -> Unit) {
    val ctx = LocalContext.current; val skin = Skins.current(); var browse by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(.4f)).padding(12.dp)) {
        Text(title, color = skin.accent, fontWeight = FontWeight.Black)
        Text(what, color = Color.White, fontSize = 12.sp)
        Text(path, color = Color(0x99FFFFFF), fontSize = 10.sp, modifier = Modifier.padding(vertical = 3.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("BROWSE") { browse = true }; Btn("COPY PATH") { copyPath(ctx, path) }; content() }
        if (browse) FolderBrowser(File(path), title) { browse = false }
    }
}

/** Every folder the app uses, what lives there, and buttons to add files, link folders or look at them. */
@Composable
fun LocationsScreen() {
    val ctx = LocalContext.current; val fd = ctx.filesDir
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("LOCATIONS", color = Skins.current().accent, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Text("The app never asks for storage permission. It reads only what you pick, and keeps copies in its own private folders (invisible to other apps). Use the buttons here to add things or link your own folders.", color = Color(0xCCFFFFFF), fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        Loc("Games", "${fd.path}/roms", "${Library.roms.size} games, ${sizeOf(File(fd, "roms"))}. Copies of the ROMs/discs you imported.") {
            Btn("+ ADD GAMES") { Picker.pick { Library.importUris(ctx, it) } }
            if (Store.b("proMode", false)) Btn(if (Store.s("romFolder").isEmpty()) "LINK FOLDER" else "UNLINK") { if (Store.s("romFolder").isEmpty()) Picker.pickTree { Library.linkFolder(ctx, it) } else { Store.set("romFolder", ""); Store.set("scanned", "") } } }
        Loc("Sega CD BIOS", "${fd.path}/system", "Put bios_CD_U.bin, bios_CD_E.bin or bios_CD_J.bin here (your own dump). Needed for Sega CD games.") { Btn("+ ADD BIOS") { Picker.pick { Library.addBios(ctx, it) } } }
        Loc("Saves", "${fd.path}/saves", "${count(File(fd, "saves"))} files, ${sizeOf(File(fd, "saves"))}. .srm = game saves, .st1-.st4 = save states, .prev = previous save of a slot.") {}
        Loc("Settings & presets", "${fd.path}/data", "settings.json, library.json, control layouts, vibration presets. Back these up in SETTINGS ▸ DATA & PRIVACY.") {}
        Loc("Pictures (covers, logos, backgrounds)", "${fd.path}/art", "${count(File(fd, "art"))} images, ${sizeOf(File(fd, "art"))}. Change them from a game's page or CUSTOMIZE ▸ BACKGROUNDS.") {}
        Loc("Menu sounds", "${fd.path}/sounds", "Sound packs and the custom sounds you picked (SETTINGS ▸ LAUNCHER SOUNDS).") {}
        Loc("Music", "${fd.path}/music", "${Music.tracks.size} tracks. Imported music is copied here.") {
            Btn("+ ADD MUSIC") { Picker.pick(arrayOf("audio/*", "application/ogg")) { Music.addFiles(ctx, it) } }
            if (Store.b("proMode", false)) Btn(if (Store.s("musicFolder").isEmpty()) "LINK FOLDER" else "UNLINK") { if (Store.s("musicFolder").isEmpty()) Picker.pickTree { u -> try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; Store.set("musicFolder", u.toString()); Music.scan() } else { Store.set("musicFolder", ""); Music.scan() } } }
        Loc("Visible app folder", "${ctx.getExternalFilesDir(null)?.path}", "music/ (drop audio files here) and screenshots/. Some phones hide Android/data from file managers.") { Btn("OPEN") { openExternal(ctx, "music") } }
        Loc("Logs", "${fd.path}/logs", "app.log and crash reports. Hidden viewer: SETTINGS ▸ ABOUT APP, tap the version line 5 times.") {}
    }
}

/** simple in-app browser for one of the app's own folders: look inside, copy a path, delete a file */
@Composable
private fun FolderBrowser(dir: File, title: String, close: () -> Unit) {
    val ctx = LocalContext.current; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val t = tick
    var sub by remember { mutableStateOf(dir) }; var del by remember { mutableStateOf<File?>(null) }
    val files = (sub.listFiles() ?: emptyArray()).sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    AlertDialog(onDismissRequest = close, confirmButton = { TextButton(close) { Text("Close") } }, title = { Text(title) },
        text = { Column {
            Text(sub.path, fontSize = 10.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 4.dp)) { if (sub != dir) Btn("◀ UP") { sub = sub.parentFile ?: dir }; Btn("COPY PATH") { copyPath(ctx, sub.path) } }
            Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                if (files.isEmpty()) Text("(this folder is empty)", fontSize = 12.sp)
                files.forEach { f -> Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text((if (f.isDirectory) "📁 " else "📄 ") + f.name, fontSize = 12.sp, modifier = Modifier.weight(1f).clickable(enabled = f.isDirectory) { sub = f })
                    Text(if (f.isDirectory) "${count(f)} files" else if (f.length() < 1048576) "${f.length() / 1024} KB" else "%.1f MB".format(f.length() / 1048576.0), fontSize = 10.sp)
                    Text("🗑", modifier = Modifier.clickable { del = f }.padding(8.dp)) } }
            } } })
    del?.let { f -> AlertDialog(onDismissRequest = { del = null }, containerColor = Color(0xFF0D0D14),
        confirmButton = { TextButton({ f.deleteRecursively(); Logger.notice("Deleted ${f.name} from ${dir.name}"); del = null; tick++ }) { Text("Delete") } },
        dismissButton = { TextButton({ del = null }) { Text("Cancel") } }, title = { Text("Delete “${f.name}”?") }, text = { Text("This removes it from the phone for good. Games that used it will need to be imported again.") }) }
}
