package com.sonicforge.audio

import android.content.Context
import android.media.MediaPlayer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import com.sonicforge.data.Library
import com.sonicforge.data.Logger
import com.sonicforge.data.SaveEvent
import com.sonicforge.data.Store
import java.io.File
import kotlin.math.log10
import kotlin.math.min

data class Track(val title: String, val path: String, val isUri: Boolean = false)

/**
 * Music engine for the Music tab and the in-game mini player.
 * Formats = whatever Android decodes (MP3, AAC/M4A, OGG, Opus, FLAC, WAV, MIDI ...). Volume goes up to 200% (above 100% uses Android's loudness enhancer).
 * "Music in game" policy: pause (default; resumes where it was after the game) / keep playing / play my playlist.
 */
object Music {
    val exts = setOf("mp3", "m4a", "m4b", "m4r", "aac", "adts", "ogg", "oga", "opus", "flac", "wav", "wave", "mid", "midi", "xmf", "mxmf", "rtttl", "rtx", "ota", "imy", "3gp", "3ga", "amr", "awb", "mka", "weba", "webm", "mp4", "ac3", "mp2")
    /** formats Android cannot decode: we say why instead of silently dropping them */
    val knownUnsupported = mapOf(
        "wma" to "WMA (Windows Media) is not part of Android; only a few phones decode it", "ape" to "Monkey's Audio (APE) has no Android decoder", "wv" to "WavPack has no Android decoder",
        "dsf" to "DSD audio has no Android decoder", "dff" to "DSD audio has no Android decoder", "vgm" to "VGM is a chiptune log, not a recording", "vgz" to "VGM is a chiptune log, not a recording",
        "nsf" to "NSF is a chiptune player format", "mod" to "tracker modules (MOD/XM/IT/S3M) need a tracker player", "xm" to "tracker modules (MOD/XM/IT/S3M) need a tracker player",
        "it" to "tracker modules (MOD/XM/IT/S3M) need a tracker player", "s3m" to "tracker modules (MOD/XM/IT/S3M) need a tracker player", "ra" to "RealAudio is obsolete and not supported")
    data class Failed(val name: String, val reason: String, val why: String)
    val failed = mutableStateListOf<Failed>()
    var importStatus by mutableStateOf("")
    val tracks = mutableStateListOf<Track>()
    var current by mutableIntStateOf(-1)
    var playing by mutableStateOf(false)
    private var _shuffle by mutableStateOf(false)
    /** shuffle plays every song of the current list once per round, in random order; going back replays the songs in the order they were played */
    var shuffle: Boolean
        get() = _shuffle
        set(v) { _shuffle = v; bag.clear(); forward.clear(); bagStarted = false; changed() }
    private val history = ArrayList<String>()      // paths played before the current one
    private val forward = ArrayList<String>()      // paths to replay when you go forward again after going back
    private val bag = ArrayList<String>()          // songs not yet played in this shuffle round
    private var bagStarted = false
    private var scope: List<String> = emptyList()  // the list being played (empty = everything)
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    var repeat by mutableIntStateOf(1)           // 0 off, 1 all, 2 one
    private var mp: MediaPlayer? = null
    private var le: LoudnessEnhancer? = null
    private lateinit var app: Context
    lateinit var internalDir: File
    var externalDir: File? = null
    private var resumeAfterGame = false
    var onChange: (() -> Unit)? = null
    private fun changed() { try { onChange?.invoke() } catch (_: Exception) {} }

    fun init(ctx: Context) {
        app = ctx.applicationContext
        internalDir = File(ctx.filesDir, "music").apply { mkdirs() }
        externalDir = ctx.getExternalFilesDir("music")?.apply { mkdirs() }
        if (!Store.b("testTune3", false)) kotlin.concurrent.thread { try { File(internalDir, "Test Tune - Speed Rush (2 min).wav").writeBytes(Synth.tuneRush()); Store.setB("testTune3", true); scan() } catch (e: Exception) { Logger.w("Music", "could not make the long test tune: $e") } }
        if (!Store.b("testTunes", false)) kotlin.concurrent.thread {
            try { File(internalDir, "Test Tune - Hill Stroll.wav").writeBytes(Synth.tuneHill()); File(internalDir, "Test Tune - Neon Night.wav").writeBytes(Synth.tuneNeon()); Store.setB("testTunes", true); scan() } catch (e: Throwable) { Logger.w("Music", "could not make the test tunes: $e") }
        }
        scan()
    }
    val byPath = HashMap<String, Track>()           // main thread only
    private val statCache = java.util.concurrent.ConcurrentHashMap<String, LongArray>()   // size and date, read once per scan
    fun scan(report: Boolean = false) {
        kotlin.concurrent.thread(name = "music-scan") {
            val out = ArrayList<Track>()
            try {
                listOfNotNull(internalDir, externalDir).forEach { d ->
                    d.listFiles()?.filter { it.isFile && it.extension.lowercase() in exts }?.forEach { out.add(Track(it.nameWithoutExtension, it.path)) } }
                val u = Store.s("musicFolder")
                if (u.isNotEmpty()) try {
                    DocumentFile.fromTreeUri(app, Uri.parse(u))?.listFiles()?.filter { it.isFile && (it.name ?: "").substringAfterLast('.', "").lowercase() in exts }
                        ?.forEach { out.add(Track((it.name ?: "?").substringBeforeLast('.'), it.uri.toString(), true)) }
                } catch (e: Exception) { Logger.w("Music", "linked folder scan failed: $e") }
            } catch (e: Throwable) { Logger.e("Music", "scan failed", e) }
            out.forEach { if (!it.isUri) File(it.path).let { f -> statCache[it.path] = longArrayOf(f.length(), f.lastModified()) } }
            val order = Store.s("musOrder").split('\n').filter { it.isNotEmpty() }
            val sorted = out.sortedWith(compareBy({ val i = order.indexOf(it.path); if (i < 0) Int.MAX_VALUE else i }, { it.title.lowercase() }))
            main.post {   // the list is only ever changed on the main thread, so the screen can't read it half-updated
                val cur = tracks.getOrNull(current)?.path
                tracks.clear(); tracks.addAll(sorted)
                current = if (cur == null) -1 else tracks.indexOfFirst { it.path == cur }
                byPath.clear(); sorted.forEach { byPath[it.path] = it }
                if (report) Store.events.tryEmit(SaveEvent("Music refreshed: ${tracks.size} tracks (${tracks.count { !it.isUri }} in the app folders, ${tracks.count { it.isUri }} from the linked folder). Files you dropped into the music folder show up now.", true))
            }
        }
    }
    /** Imports in the background (hundreds of files are fine) and records every file that failed, with the reason. */
    fun addFiles(ctx: Context, uris: List<Uri>, target: String? = null) {
        kotlin.concurrent.thread {
            var ok = 0; var n = 0; val added = ArrayList<String>()
            for (u in uris) {
                n++; importStatus = "Importing $n / ${uris.size}..."
                val name = Library.displayName(ctx, u); val ext = name.substringAfterLast('.', "").lowercase()
                if (ext !in exts) {
                    val why = knownUnsupported[ext] ?: "Android has no decoder for .$ext"
                    failed.add(Failed(name, "Unsupported format .$ext", "$why. Convert it to MP3, FLAC, OGG or WAV and add it again. Check more at developer.android.com, Supported media formats."))
                    Logger.w("Music", "unsupported audio format: $name ($why)"); continue
                }
                try {
                    val dst = File(internalDir, name)
                    ctx.contentResolver.openInputStream(u)!!.use { i -> dst.outputStream().use { i.copyTo(it) } }
                    val dur = try { val r = android.media.MediaMetadataRetriever(); r.setDataSource(dst.path); val d = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION); r.release(); d } catch (_: Exception) { null }
                    if (dur == null) {
                        failed.add(Failed(name, "Android can't decode it", "The codec inside this file isn't available on this phone (for example Opus before Android 10, or an unusual FLAC/AC3). Convert it to MP3, FLAC or OGG and try again. Check more at developer.android.com, Supported media formats."))
                        Logger.w("Music", "cannot decode: $name (unsupported audio, cannot decode)"); dst.delete()
                    } else { ok++; added.add(dst.path) }
                } catch (e: Exception) {
                    failed.add(Failed(name, "Could not copy", (if ((e.message ?: "").contains("ENOSPC")) "The phone storage is full. " else "The file could not be read (permission lost, or the file moved). ") + "Pick it again."))
                    Logger.w("Music", "copy failed for $name: $e")
                }
            }
            importStatus = ""
            if (target != null && added.isNotEmpty()) try { Playlists.add(target, added) } catch (e: Throwable) { Logger.w("Music", "could not add to playlist $target: $e") }
            Store.events.tryEmit(SaveEvent("Music: $ok added" + (if (target != null && ok > 0) " to “$target”" else "") + (if (failed.isNotEmpty()) ", ${failed.size} failed (see the FAILED list)" else ""), failed.isEmpty())); scan()
        }
    }
    fun clearFailed() { failed.clear() }
    private val artistCache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val lenCache = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val queued = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val pending = java.util.concurrent.atomic.AtomicInteger(0)
    private val metaExec = java.util.concurrent.Executors.newSingleThreadExecutor()
    var metaTick by mutableIntStateOf(0)       // read by the screen so it redraws when artists/lengths arrive
    private fun load(t: Track) {
        if (!queued.add(t.path)) return
        pending.incrementAndGet()
        metaExec.execute {
            try { artistCache[t.path] = meta(t, android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""; lenCache[t.path] = meta(t, android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L } catch (_: Throwable) {}
            val left = pending.decrementAndGet(); if (left == 0 || left % 8 == 0) main.post { metaTick++ }
        }
    }
    private fun meta(t: Track, key: Int): String? = try { val r = android.media.MediaMetadataRetriever(); if (t.isUri) r.setDataSource(app, Uri.parse(t.path)) else r.setDataSource(t.path); val v = r.extractMetadata(key); r.release(); v } catch (_: Exception) { null }
    fun artist(t: Track): String { val a = artistCache[t.path]; if (a == null) { load(t); return "" }; return a }
    fun lengthMs(t: Track): Long { val l = lenCache[t.path]; if (l == null) { load(t); return 0L }; return l }
    fun sizeOf(t: Track): Long = statCache[t.path]?.get(0) ?: if (t.isUri) 0L else File(t.path).length()
    fun dateOf(t: Track): Long = statCache[t.path]?.get(1) ?: if (t.isUri) 0L else File(t.path).lastModified()
    fun delete(i: Int) { val t = tracks[i]; if (t.isUri) return; if (i == current) stop(); File(t.path).delete(); scan() }

    private fun vol() = Store.i("volMusic", 100) / 100f
    fun applyVolume() {
        val v = vol(); try { mp?.setVolume(min(1f, v), min(1f, v)) } catch (_: Exception) {}
        try { le?.setTargetGain(if (v > 1f) (2000 * log10(v.toDouble())).toInt() else 0); le?.enabled = v > 1f } catch (_: Exception) {}
    }
    private fun start(i: Int) {
        if (i !in tracks.indices) return
        release()
        val t = tracks[i]
        try {
            mp = MediaPlayer().apply {
                if (t.isUri) setDataSource(app, Uri.parse(t.path)) else setDataSource(t.path)
                setOnCompletionListener { onDone() }
                setOnErrorListener { _, w, x -> Logger.w("Music", "player error $w/$x on ${t.title}"); Store.events.tryEmit(SaveEvent("Can't play this file", false)); playing = false; true }
                prepare(); start()
            }
            le = try { LoudnessEnhancer(mp!!.audioSessionId) } catch (_: Exception) { null }
            applyVolume(); current = i; playing = true; changed()
        } catch (e: Exception) { Logger.w("Music", "can't play ${t.title}: $e"); Store.events.tryEmit(SaveEvent("Can't play this file", false)); release() }
    }
    private fun curPath() = tracks.getOrNull(current)?.path
    private fun scopePaths(): List<String> { val all = tracks.map { it.path }; return if (scope.isEmpty()) all else scope.filter { it in all } }
    private fun startPath(path: String) { val i = tracks.indexOfFirst { it.path == path }; if (i >= 0) start(i) }
    /** you chose a song: remember the one before it (for BACK) and play it */
    fun play(i: Int) { if (i !in tracks.indices) return; if (mp != null) curPath()?.let { if (history.lastOrNull() != it) history.add(it); if (history.size > 500) history.removeAt(0) }; forward.clear(); start(i) }
    /** play a song and make `inList` the queue (the list you are looking at) */
    fun playPath(path: String, inList: List<String>? = null) { if (inList != null) { scope = inList; bag.clear(); forward.clear(); bagStarted = false }; val i = tracks.indexOfFirst { it.path == path }; if (i >= 0) play(i) }
    /** resume if paused (keeps the position), otherwise start the current/first track */
    fun toggle() { val m = mp; if (m == null) play(if (current >= 0) current else 0) else try { if (m.isPlaying) { m.pause(); playing = false } else { m.start(); playing = true }; changed() } catch (_: Exception) {} }
    fun resume() { val m = mp; if (m != null) try { if (!m.isPlaying) m.start(); playing = true } catch (_: Exception) {} else play(if (current >= 0) current else 0) }
    fun next() {
        if (tracks.isEmpty()) return
        val sp = scopePaths(); if (sp.isEmpty()) return
        val cur = curPath()
        cur?.let { if (history.lastOrNull() != it) history.add(it); if (history.size > 500) history.removeAt(0) }
        if (shuffle) {
            val target = if (forward.isNotEmpty()) forward.removeAt(forward.size - 1) else {
                if (bag.isEmpty()) { bag.addAll(sp.shuffled().filter { it != cur }.ifEmpty { sp }); bagStarted = true }   // a new round: every song once, never the one that just played first
                bag.removeAt(0)
            }
            startPath(target)
        } else {
            val i = sp.indexOf(cur); startPath(sp[(i + 1) % sp.size])
        }
    }
    fun prev() {
        if (tracks.isEmpty()) return
        if (pos() > 3000) { seek(0); return }
        if (history.isNotEmpty()) { val back = history.removeAt(history.size - 1); curPath()?.let { forward.add(it) }; startPath(back); return }
        val sp = scopePaths(); if (sp.isEmpty()) return
        val i = sp.indexOf(curPath()); startPath(sp[(i - 1 + sp.size) % sp.size])
    }
    private fun onDone() {
        when {
            repeat == 2 -> start(current)
            shuffle && bagStarted && bag.isEmpty() && forward.isEmpty() && repeat == 0 -> { playing = false; changed() }   // the round is over
            !shuffle && repeat == 0 && scopePaths().lastOrNull() == curPath() -> { playing = false; changed() }
            else -> next()
        }
    }
    class QueueView(val before: List<String>, val current: String?, val after: List<String>, val shuffled: Boolean)
    /** what the QUEUE panel shows: songs played before, the current one, and what comes next (in shuffle: the real upcoming order) */
    fun queueView(): QueueView {
        val sp = scopePaths(); val cur = curPath()
        if (shuffle) return QueueView(history.takeLast(40), cur, forward.asReversed().toList() + bag.toList(), true)
        val i = sp.indexOf(cur)
        return QueueView(if (i > 0) sp.subList(0, i).toList() else emptyList(), cur, if (i >= 0) sp.subList(i + 1, sp.size).toList() else sp, false)
    }
    /** a tap in the queue panel: play that song, keeping the shuffle round consistent */
    fun jumpTo(path: String) { bag.remove(path); forward.remove(path); val i = tracks.indexOfFirst { it.path == path }; if (i >= 0) play(i) }
    /** manual order of the ALL list (saved) */
    fun moveInAll(path: String, delta: Int) {
        val i = tracks.indexOfFirst { it.path == path }; val j = i + delta
        if (i < 0 || j !in tracks.indices) return
        val cur = curPath(); val t = tracks.removeAt(i); tracks.add(j, t)
        Store.set("musOrder", tracks.joinToString("\n") { it.path }); current = if (cur == null) -1 else tracks.indexOfFirst { it.path == cur }
    }
    fun pos() = try { mp?.currentPosition ?: 0 } catch (_: Exception) { 0 }
    fun dur() = try { mp?.duration ?: 0 } catch (_: Exception) { 0 }
    fun seek(ms: Int) { try { mp?.seekTo(ms) } catch (_: Exception) {} }
    fun pause() { try { if (mp?.isPlaying == true) mp?.pause() } catch (_: Exception) {}; playing = false; changed() }
    fun stop() { release(); playing = false; changed() }
    private fun release() { try { le?.release() } catch (_: Exception) {}; le = null; try { mp?.release() } catch (_: Exception) {}; mp = null }

    fun gameStart(trackPath: String) {
        resumeAfterGame = playing
        when (Store.s("musicInGame", "pause")) {
            "keep" -> {}
            "play" -> if (!playing && tracks.isNotEmpty()) resume()
            else -> pause()
        }
        if (trackPath.isNotEmpty()) playPath(trackPath)
    }
    fun gameEnd() { if (Store.s("musicInGame", "pause") == "pause" && resumeAfterGame) resume() }
}
