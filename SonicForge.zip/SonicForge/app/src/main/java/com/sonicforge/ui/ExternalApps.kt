package com.sonicforge.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.sonicforge.data.Store

/** Lets you pick any installed app as your file manager or text editor (stored as a package name in Store keys extFm / extEdit). */
object ExternalApps {
    fun apps(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
    }
    fun label(ctx: Context, key: String): String { val p = Store.s(key); return if (p.isEmpty()) "built-in" else apps(ctx).firstOrNull { it.first == p }?.second ?: p }
    /** opens the chosen app; false when none is chosen or it can't be started */
    fun launch(ctx: Context, key: String): Boolean {
        val p = Store.s(key); if (p.isEmpty()) return false
        val i = ctx.packageManager.getLaunchIntentForPackage(p) ?: return false
        return try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (_: Exception) { false }
    }
}

@Composable
fun AppPicker(key: String, onClose: () -> Unit) {
    val ctx = LocalContext.current; val list = remember { ExternalApps.apps(ctx) }
    AlertDialog(onDismissRequest = onClose, confirmButton = { TextButton(onClose) { Text("Close") } },
        title = { Text(if (key == "extFm") "Choose your file manager" else "Choose your text editor") },
        text = { Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
            Btn("Use the built-in / system default", Modifier.fillMaxWidth().padding(2.dp), selected = Store.s(key).isEmpty()) { Store.set(key, ""); onClose() }
            list.forEach { (pkg, name) -> Btn(name, Modifier.fillMaxWidth().padding(2.dp), selected = Store.s(key) == pkg) { Store.set(key, pkg); onClose() } }
        } })
}
