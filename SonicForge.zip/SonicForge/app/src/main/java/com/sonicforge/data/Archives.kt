package com.sonicforge.data

import android.content.Context
import android.net.Uri
import com.github.junrar.Junrar
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import java.io.File
import java.util.zip.ZipInputStream

/** Unpacks .zip / .rar (RAR4) / .7z (or copies a plain file) into a temp folder, keeping the original file names (a CD .cue needs them). */
object Archives {
    val romExts = setOf("bin", "md", "gen", "smd", "sms", "gg", "sg", "32x", "gba", "gb", "gbc", "swf")
    val cdExts = setOf("cue", "chd", "iso")
    val archiveExts = setOf("zip", "rar", "7z")
    class Extracted(val dir: File, val files: List<File>)

    fun safe(n: String) = n.substringAfterLast('/').substringAfterLast('\\').replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").ifEmpty { "file" }
    private fun uniq(d: File, n: String): File { var f = File(d, n); var i = 1; while (f.exists()) f = File(d, "${i++}_$n"); return f }

    fun extractAll(ctx: Context, items: List<Pair<Uri, String>>): Extracted {
        val out = File(ctx.cacheDir, "extract_${System.nanoTime()}").apply { mkdirs() }
        val files = mutableListOf<File>()
        for ((uri, name) in items) {
            val low = name.lowercase()
            when {
                low.endsWith(".zip") -> ZipInputStream(ctx.contentResolver.openInputStream(uri)!!).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        if (!e.isDirectory && !e.name.startsWith("__MACOSX")) { val f = uniq(out, safe(e.name)); f.outputStream().use { z.copyTo(it) }; files.add(f) }
                        e = z.nextEntry
                    }
                }
                low.endsWith(".rar") -> {
                    val src = File(out, "src_" + safe(name)); ctx.contentResolver.openInputStream(uri)!!.use { i -> src.outputStream().use { i.copyTo(it) } }
                    val dest = File(out, "rar_" + System.nanoTime()).apply { mkdirs() }
                    Junrar.extract(src, dest); src.delete()      // throws on RAR5 / encrypted
                    dest.walkTopDown().filter { it.isFile }.forEach { f -> val t = uniq(out, safe(f.name)); f.renameTo(t); files.add(t) }
                }
                low.endsWith(".7z") -> {
                    val src = File(out, "src_" + safe(name)); ctx.contentResolver.openInputStream(uri)!!.use { i -> src.outputStream().use { i.copyTo(it) } }
                    @Suppress("DEPRECATION") SevenZFile(src).use { sz ->
                        var e = sz.nextEntry; val buf = ByteArray(65536)
                        while (e != null) {
                            if (!e.isDirectory) { val f = uniq(out, safe(e.name)); f.outputStream().use { o -> var n = sz.read(buf); while (n > 0) { o.write(buf, 0, n); n = sz.read(buf) } }; files.add(f) }
                            e = sz.nextEntry
                        }
                    }
                    src.delete()
                }
                else -> { val f = uniq(out, safe(name)); ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }; files.add(f) }
            }
        }
        return Extracted(out, files)
    }
    fun cleanup(ctx: Context) { ctx.cacheDir.listFiles()?.filter { it.name.startsWith("extract_") }?.forEach { it.deleteRecursively() } }
}
