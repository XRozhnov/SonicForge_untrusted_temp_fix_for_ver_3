package com.sonicforge.ui

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import com.sonicforge.core.Bits
import com.sonicforge.data.CtrlEl
import com.sonicforge.data.PadLayout
import com.sonicforge.input.Haptics
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

fun ctrlRadius(id: String, s: Float, w: Float, h: Float): Float {
    val m = min(w, h)
    return when (id) { "dpad" -> m * .17f * s; "A", "B", "C" -> m * .085f * s; "X", "Y", "Z", "L", "R" -> m * .07f * s; "START", "MODE" -> m * .06f * s; else -> m * .05f * s }
}
private fun label(id: String) = when (id) { "START" -> "ST"; "MODE" -> "MD"; "SAVE" -> "SV"; "LOAD" -> "LD"; "MENU" -> "≡"; "REW" -> "⏪"; "FF" -> "⏩"; else -> id }

data class Hit(val id: String, val dx: Float, val dy: Float, val r: Float)

fun hitTest(l: PadLayout, land: Boolean, w: Float, h: Float, p: Offset, pad: Float = 1.15f): Hit? {
    var best: Hit? = null; var bd = Float.MAX_VALUE
    for (e in l.els(land)) {
        if (!e.on) continue
        val r = ctrlRadius(e.id, e.s, w, h); val dx = p.x - e.x * w; val dy = p.y - e.y * h
        val d = sqrt(dx * dx + dy * dy)
        if (d <= r * (if (e.id == "dpad") 1.35f else pad) && d < bd) { bd = d; best = Hit(e.id, dx, dy, r) }
    }
    return best
}
fun dirMask(dx: Float, dy: Float, r: Float): Int {
    val t = r * .28f; var m = 0
    if (dy < -t) m = m or Bits.UP; if (dy > t) m = m or Bits.DOWN; if (dx < -t) m = m or Bits.LEFT; if (dx > t) m = m or Bits.RIGHT
    return m
}
fun bitFor(id: String) = com.sonicforge.core.Systems.bit(com.sonicforge.core.PadSys.current, id)

private fun DrawScope.shape(kind: String, c: Offset, r: Float, fill: Color, line: Color) {
    when (kind) {
        "square" -> { drawRoundRect(fill, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), CornerRadius(r * .3f)); drawRoundRect(line, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), CornerRadius(r * .3f), style = Stroke(3f)) }
        "pixel" -> { drawRect(fill, Offset(c.x - r, c.y - r), Size(r * 2, r * 2)); drawRect(line, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), style = Stroke(5f)) }
        "hex" -> { val p = Path(); for (i in 0..5) { val a = Math.PI / 3 * i; val x = c.x + r * cos(a).toFloat(); val y = c.y + r * sin(a).toFloat(); if (i == 0) p.moveTo(x, y) else p.lineTo(x, y) }; p.close()
            drawPath(p, fill); drawPath(p, line, style = Stroke(3f)) }
        else -> { drawCircle(fill, r, c); drawCircle(line, r, c, style = Stroke(3f)) }
    }
}

/** Shared by the in-game overlay and the layout editor. */
fun DrawScope.drawPad(l: PadLayout, land: Boolean, skin: Skin, pressed: Set<String>, stick: Offset, sel: String?, outline: Color, opacity: Float = l.opacity) {
    val w = size.width; val h = size.height
    val paint = Paint().apply { color = android.graphics.Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true; isAntiAlias = true }
    for (e in l.els(land)) {
        if (!e.on && sel == null) continue
        val c = Offset(e.x * w, e.y * h); val r = ctrlRadius(e.id, e.s, w, h); val down = e.id in pressed
        val a = if (e.on) opacity else .25f
        val fill = (if (down) skin.accent else skin.bgBot).copy(alpha = if (down) a else a * .7f)
        val line = skin.accent.copy(alpha = a)
        if (e.id == "dpad") {
            if (l.stick) {
                drawCircle(fill.copy(alpha = a * .5f), r, c); drawCircle(line, r, c, style = Stroke(3f))
                val k = Offset(stick.x.coerceIn(-r * .6f, r * .6f), stick.y.coerceIn(-r * .6f, r * .6f))
                shape(l.shape, c + k, r * .5f, skin.accent.copy(alpha = a), skin.c2.copy(alpha = a))
            } else {
                val arm = r * .38f
                shape(if (l.shape == "round") "square" else l.shape, c, r * .34f, fill, line)
                for ((dx, dy, id) in listOf(Triple(0f, -1f, "u"), Triple(0f, 1f, "d"), Triple(-1f, 0f, "l"), Triple(1f, 0f, "r"))) {
                    val on = when (id) { "u" -> stick.y < -r * .28f; "d" -> stick.y > r * .28f; "l" -> stick.x < -r * .28f; else -> stick.x > r * .28f } && "dpad" in pressed
                    shape(if (l.shape == "round") "square" else l.shape, Offset(c.x + dx * r * .68f, c.y + dy * r * .68f), arm, if (on) skin.accent.copy(alpha = a) else fill, line)
                }
            }
        } else if (e.id == "START" || e.id == "MODE") {
            drawRoundRect(fill, Offset(c.x - r * 1.4f, c.y - r * .6f), Size(r * 2.8f, r * 1.2f), CornerRadius(r * .6f))
            drawRoundRect(line, Offset(c.x - r * 1.4f, c.y - r * .6f), Size(r * 2.8f, r * 1.2f), CornerRadius(r * .6f), style = Stroke(3f))
            paint.textSize = r * .8f; drawContext.canvas.nativeCanvas.drawText(label(e.id), c.x, c.y + r * .28f, paint)
        } else {
            shape(l.shape, c, r, fill, line)
            paint.textSize = r * .85f; drawContext.canvas.nativeCanvas.drawText(label(e.id), c.x, c.y + r * .3f, paint)
        }
        if (sel == e.id) drawCircle(outline, r * 1.3f, c, style = Stroke(5f))
    }
}

@Composable
fun ControlsOverlay(layout: PadLayout, land: Boolean, onMask: (Int) -> Unit, onAction: (String) -> Unit, onHeld: (Set<String>) -> Unit = {}, opacity: Float? = null, modifier: Modifier = Modifier) {
    val skin = Skins.current()
    var pressed by remember { mutableStateOf(setOf<String>()) }
    var stick by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    val cbHeld by rememberUpdatedState(onHeld); val cbMask by rememberUpdatedState(onMask); val cbAct by rememberUpdatedState(onAction)
    Canvas(modifier.fillMaxSize().onSizeChanged { size = it }.pointerInput(layout, land) {
        awaitPointerEventScope {
            var prev = setOf<String>()
            while (true) {
                val ev = awaitPointerEvent()
                val now = mutableSetOf<String>(); var mask = 0; var so = Offset.Zero
                for (c in ev.changes) {
                    if (!c.pressed) continue
                    val h = hitTest(layout, land, size.width.toFloat(), size.height.toFloat(), c.position) ?: continue
                    now.add(h.id)
                    if (h.id == "dpad") { mask = mask or dirMask(h.dx, h.dy, h.r); so = Offset(h.dx, h.dy) } else mask = mask or bitFor(h.id)
                }
                for (id in now) if (id !in prev) { Haptics.gameTouch(); if (id == "SAVE" || id == "LOAD" || id == "MENU") cbAct(id) }
                prev = now; pressed = now; stick = so; cbMask(mask); cbHeld(now)
                ev.changes.forEach { it.consume() }
            }
        }
    }) { drawPad(layout, land, skin, pressed, stick, null, skin.accent, opacity ?: layout.opacity) }
}
