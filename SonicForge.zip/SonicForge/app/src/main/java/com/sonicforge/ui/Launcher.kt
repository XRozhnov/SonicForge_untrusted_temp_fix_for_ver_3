package com.sonicforge.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.OpenBor
import com.sonicforge.audio.Music
import com.sonicforge.core.Systems
import com.sonicforge.data.CheatDb
import com.sonicforge.data.Tips
import com.sonicforge.audio.Sfx
import com.sonicforge.core.Shaders
import com.sonicforge.data.Library
import com.sonicforge.data.Rom
import com.sonicforge.data.Store
import com.sonicforge.input.Haptics
import java.io.File

@Composable
fun LauncherScreen(onPlay: (Rom) -> Unit) {
    val skin = Skins.current(); val ctx = LocalContext.current
    var sysF by remember { mutableStateOf("all") }
    var sysTab by remember { mutableStateOf("md") }
    val roms = Library.roms.filter { Systems.tabOf(it.sys) == sysTab && (sysTab != "md" || sysF == "all" || it.sys == sysF) }
    var selId by remember { mutableStateOf<String?>(null) }
    val rom = roms.firstOrNull { it.id == selId } ?: roms.firstOrNull()
    val linked = Store.s("romFolder").isNotEmpty()
    val actions: @Composable () -> Unit = {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Btn("+ ADD GAME") { Picker.pick { Library.importUris(ctx, it) } }
            Btn(if (linked) "📁 SCAN FOLDER" else "📁 LINK FOLDER") { if (linked) Library.scanFolder(ctx) else Picker.pickTree { Library.linkFolder(ctx, it) } }
        }
    }
    val filters: @Composable () -> Unit = {
        Column { Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { listOf("all" to "ALL", "md" to "MD", "sms" to "SMS", "gg" to "GG").forEach { (k, n) -> Btn(n, selected = sysF == k) { sysF = k } } }
            Text("MD = Mega Drive / Genesis · SMS = Master System · GG = Game Gear. The row above picks the console collection (SEGA CD, 32X, Game Boy, OpenBOR, Flash).", color = Color(0x99FFFFFF), fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp)) }
    }
    Column(Modifier.fillMaxSize()) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("md" to "MEGA DRIVE", "scd" to "SEGA CD", "x32" to "32X", "gba" to "GAME BOY", "bor" to "OPENBOR", "flash" to "FLASH").filter { it.first == "md" || Store.b("experiments", true) }
            .forEach { (k, n) -> Btn(n + " (" + Library.roms.count { Systems.tabOf(it.sys) == k } + ")", selected = sysTab == k) { sysTab = k } } }
    BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
        val wide = maxWidth >= 640.dp
        val list: @Composable () -> Unit = {
            if (wide) Column(Modifier.width(240.dp).fillMaxHeight().background(Color.Black.copy(.35f)).padding(8.dp)) {
                Text("LIBRARY", color = skin.accent, fontWeight = FontWeight.Black, letterSpacing = 2.sp, modifier = Modifier.padding(6.dp))
                filters(); Spacer(Modifier.height(6.dp))
                LazyColumn(Modifier.weight(1f)) { items(roms, key = { it.id }) { r ->
                    val s = r.id == rom?.id
                    Text(r.title + (if (r.variant.isNotEmpty()) "  [" + r.variant + "]" else ""), color = if (s) skin.accent else Color.White, fontWeight = if (s) FontWeight.Bold else FontWeight.Normal, maxLines = 2,
                        modifier = Modifier.fillMaxWidth().background(if (s) Color.White.copy(.12f) else Color.Transparent).forgeClick { selId = r.id }.padding(10.dp))
                } }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { Btn("+ ADD GAME", Modifier.fillMaxWidth()) { Picker.pick { Library.importUris(ctx, it) } }
                    Btn(if (linked) "📁 SCAN FOLDER" else "📁 LINK FOLDER", Modifier.fillMaxWidth()) { if (linked) Library.scanFolder(ctx) else Picker.pickTree { Library.linkFolder(ctx, it) } } }
            } else Column(Modifier.fillMaxWidth().background(Color.Black.copy(.35f)).padding(6.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) { filters(); actions() }
                LazyRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(roms, key = { it.id }) { r -> Btn(r.title, selected = r.id == rom?.id) { selId = r.id } } }
            }
        }
        val body: @Composable (Modifier) -> Unit = { m ->
            if (rom == null) Box(m, Alignment.Center) { Text("No games yet.\nTap + ADD GAME and pick your ROMs\n(.bin .md .gen .smd .sms .gg — or a .zip / .rar / .7z).", color = Color.White, textAlign = TextAlign.Center) }
            else GameHero(rom, m) { onPlay(it) }
        }
        if (wide) Row(Modifier.fillMaxSize()) { list(); body(Modifier.weight(1f).fillMaxHeight()) }
        else Column(Modifier.fillMaxSize()) { list(); body(Modifier.weight(1f).fillMaxWidth()) }
    }
    }
}

@Composable
private fun GameHero(rom: Rom, modifier: Modifier, onPlay: (Rom) -> Unit) {
    val skin = Skins.current(); val ctx = LocalContext.current
    var edit by remember { mutableStateOf(false) }; var confirmDel by remember { mutableStateOf(false) }
    val bg = rememberBitmap(rom.bg); val logo = rememberBitmap(rom.logo)
    Column(modifier.verticalScroll(rememberScrollState()).padding(12.dp)) {
        Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(skin.radius.dp)).skinBorder(skin)) {
            if (bg != null) Image(bg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else Box(Modifier.fillMaxSize().skinBg(skin))
            Particles(skin.deco)
            Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA000000)))))
            if (logo != null) Image(logo, null, Modifier.align(Alignment.BottomStart).padding(16.dp).height(84.dp), contentScale = ContentScale.Fit)
            else Text(rom.title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.BottomStart).padding(16.dp))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clip(RoundedCornerShape(12.dp)).background(skin.accent).clickable { Sfx.play("launch"); Haptics.ui(); onPlay(rom) }.padding(horizontal = 30.dp, vertical = 12.dp)) {
                Text("▶  PLAY", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 18.sp) }
            Btn("🖼 BACKGROUND") { Picker.pick(arrayOf("image/*")) { u -> u.firstOrNull()?.let { Library.setArt(ctx, rom, it, false) } } }
            Btn("🏷 LOGO") { Picker.pick(arrayOf("image/*")) { u -> u.firstOrNull()?.let { Library.setArt(ctx, rom, it, true) } } }
            Btn("RESET ART") { rom.bg?.let { File(it).delete() }; rom.logo?.let { File(it).delete() }; Library.update(rom.copy(bg = null, logo = null)) }
            Btn("🩹 PATCH") { Picker.pick { u -> u.firstOrNull()?.let { Library.applyPatch(ctx, rom, it) } } }
            Btn("✎ EDIT") { edit = true }
            Btn("▲") { Library.move(rom.id, -1) }; Btn("▼") { Library.move(rom.id, 1) }
            Btn("🗑 REMOVE", color = Color(0xFFE53935)) { confirmDel = true }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(.4f)).padding(12.dp)) {
            Text("ABOUT THE GAME", color = skin.accent, fontWeight = FontWeight.Black, letterSpacing = 2.sp, fontSize = 12.sp)
            Text(rom.desc, color = Color.White, modifier = Modifier.padding(vertical = 6.dp))
            MiniScene(rom.scene, Modifier.clip(RoundedCornerShape(8.dp)), rom.cBody, rom.cSky, rom.cGround)
            Text("Tap the hero for a spin-dash, collect the rings!", color = Color(0x99FFFFFF), fontSize = 10.sp)
            if (rom.group.isNotEmpty()) Text("Group: ${rom.group}" + (if (rom.variant.isNotEmpty()) "  ·  Version: ${rom.variant}" else ""), color = Color(0xCCFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            Text(Systems.byId(rom.sys).label + " · " + Systems.byId(rom.sys).exts + (if (Systems.byId(rom.sys).experimental) "  ·  experimental" else ""), color = Color(0x99FFFFFF), fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
            if (rom.sys == "bor") Text(OpenBor.report(ctx), color = Color(0xFFFFCC80), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            if (!java.io.File(Library.dir, rom.file).exists()) Text("⚠ The game file is missing (an earlier import failed). Use + ADD GAME and pick it again: the game will be repaired.", color = Color(0xFFFFAB91), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Tips.forRom(rom).forEach { Text("💡 $it", color = Color(0xFFB2EBF2), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
        }
    }
    if (edit) EditDialog(rom) { edit = false }
    if (confirmDel) AlertDialog(onDismissRequest = { confirmDel = false },
        confirmButton = { TextButton({ Library.remove(rom); confirmDel = false }) { Text("Remove") } },
        dismissButton = { TextButton({ confirmDel = false }) { Text("Cancel") } },
        title = { Text("Remove ${rom.title}?") }, text = { Text("Deletes the imported ROM copy from the app. Your original file is untouched. Saves are kept.") })
}

private val PALETTE = listOf(0, 0xFF1E88E5.toInt(), 0xFFE53935.toInt(), 0xFFFFD54F.toInt(), 0xFF43A047.toInt(), 0xFFEC407A.toInt(), 0xFF212121.toInt(), 0xFF90A4AE.toInt(), 0xFF7E57C2.toInt(), 0xFFFFFFFF.toInt())
@Composable private fun Swatches(label: String, v: Int, set: (Int) -> Unit) {
    Text(label, Modifier.padding(top = 6.dp), fontSize = 12.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PALETTE.forEach { c -> Box(Modifier.size(28.dp).clip(CircleShape).background(if (c == 0) Color.Gray else Color(c)).border(if (v == c) 3.dp else 1.dp, if (v == c) Color.White else Color.DarkGray, CircleShape).clickable { set(c) }, Alignment.Center) { if (c == 0) Text("A", fontSize = 11.sp, color = Color.White) } }
    }
}
@Composable private fun Pick(label: String, opts: List<Pair<String, String>>, cur: String, set: (String) -> Unit) {
    Text(label, Modifier.padding(top = 8.dp), fontSize = 12.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) { opts.forEach { (k, n) -> FilterChip(cur == k, { set(k) }, { Text(n, fontSize = 11.sp) }) } }
}

@Composable
private fun EditDialog(rom: Rom, close: () -> Unit) {
    var title by remember { mutableStateOf(rom.title) }; var desc by remember { mutableStateOf(rom.desc) }
    var scene by remember { mutableStateOf(rom.scene) }; var cheats by remember { mutableStateOf(rom.cheats) }
    var cb by remember { mutableIntStateOf(rom.cBody) }; var cs by remember { mutableIntStateOf(rom.cSky) }; var cg by remember { mutableIntStateOf(rom.cGround) }
    var shader by remember { mutableStateOf(rom.shader) }; var skin by remember { mutableStateOf(rom.skin) }; var slot by remember { mutableIntStateOf(rom.slot) }; var track by remember { mutableStateOf(rom.track) }
    var group by remember { mutableStateOf(rom.group) }; var variant by remember { mutableStateOf(rom.variant) }; var profile by remember { mutableStateOf(rom.profile) }
    var rings by remember { mutableStateOf(if (rom.rings >= 0) rom.rings.toString(16).uppercase() else "") }
    var lives by remember { mutableStateOf(if (rom.lives >= 0) rom.lives.toString(16).uppercase() else "") }
    AlertDialog(onDismissRequest = close,
        confirmButton = { TextButton({ Library.update(rom.copy(title = title.ifBlank { rom.title }, group = group, variant = variant, profile = profile, desc = desc, scene = scene, cBody = cb, cSky = cs, cGround = cg, cheats = cheats,
            shader = shader, skin = skin, slot = slot, track = track, rings = rings.toIntOrNull(16) ?: -1, lives = lives.toIntOrNull(16) ?: -1)); close() }) { Text("Save") } },
        dismissButton = { TextButton(close) { Text("Cancel") } },
        title = { Text("Edit game") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) {
            OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
            OutlinedTextField(desc, { desc = it }, label = { Text("Description") })
            OutlinedTextField(group, { group = it }, label = { Text("Group (for example Sonic 2)") }, singleLine = true)
            OutlinedTextField(variant, { variant = it }, label = { Text("Version label (Original, French translation, Hack...)") }, singleLine = true)
            Text("Games with the same group are shown together; the version label appears after the title.", fontSize = 10.sp)
            Pick("Vibration profile", listOf("auto" to "Auto", "s1" to "Sonic 1", "s2" to "Sonic 2", "s3k" to "S3&K basic", "s3kx" to "S3&K advanced (exp.)", "generic" to "My counter (Ring Finder)", "off" to "Off"), profile) { profile = it }
            Pick("Scene palette", SCENE_PRESETS.map { it.name to it.name }, "") { n -> SCENE_PRESETS.firstOrNull { it.name == n }?.let { cs = it.sky; cg = it.ground; cb = it.body } }
            Pick("Scene", listOf("classic", "metal", "boom", "shadow", "amy", "exe", "score", "heroes").map { it to it }, scene) { scene = it }
            Swatches("Scene: hero colour", cb) { cb = it }; Swatches("Scene: sky colour", cs) { cs = it }; Swatches("Scene: ground colour", cg) { cg = it }
            Text("— Per-game overrides (empty = use global settings) —", Modifier.padding(top = 12.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Pick("Shader", listOf("" to "Global") + Shaders.list.map { it.id to it.name }, shader) { shader = it }
            Pick("Skin", listOf("" to "Global") + Skins.all.map { it.id to it.name }, skin) { skin = it }
            Pick("Control preset", (0..6).map { it.toString() to (if (it == 0) "Global" else "Slot $it") }, slot.toString()) { slot = it.toInt() }
            Pick("Music track", listOf("" to "None") + Music.tracks.map { it.path to it.title }, track) { track = it }
            Text("Cheats — one per line: NAME=CODE (Game Genie like ABCD-EFGH, or Action Replay). Start a line with # to disable it.", Modifier.padding(top = 12.dp), fontSize = 11.sp)
            OutlinedTextField(cheats, { cheats = it }, label = { Text("Cheats") }, minLines = 2)
            if (CheatDb.forRom(rom).isNotEmpty()) Btn("＋ ADD KNOWN CODES") { cheats = (cheats + "\n" + CheatDb.asLines(CheatDb.forRom(rom))).trim() }
            Text("Haptic events (experimental): work-RAM addresses in hex, e.g. FE20 rings / FE12 lives (Sonic 1/2/3&K). Empty = off.", fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            OutlinedTextField(rings, { rings = it.filter { c -> c.isLetterOrDigit() }.take(4) }, label = { Text("Rings address") }, singleLine = true)
            OutlinedTextField(lives, { lives = it.filter { c -> c.isLetterOrDigit() }.take(4) }, label = { Text("Lives address") }, singleLine = true)
        } })
}
