package com.sonicforge.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Store

/** Global switch for the guide overlay. First launch opens it once; after that only when the user asks (SETTINGS > ABOUT APP > OPEN GUIDE). */
object Guide { var show by mutableStateOf(false) }

private data class Page(val emoji: String, val title: String, val lines: List<String>, val c1: Color, val c2: Color, val goto: String? = null, val gotoLabel: String = "")

private val pages = listOf(
    Page("👋", "Welcome to SonicForge", listOf(
        "Hi! I'm Tails, and I'll walk you through the launcher. It is an offline hub for retro Sonic games with a music player, mini-games and a lot of customisation.",
        "📍 Reopen this tour any time: HELP ▸ Quick start, or SETTINGS ▸ ABOUT APP ▸ OPEN GUIDE. Swipe or tap NEXT. If you skip it, I'll ask you to confirm.",
        "Tabs at the top: GAMES, MINI-GAMES, MUSIC, CUSTOMIZE, LOCATIONS, SETTINGS, HELP."), Color(0xFFEF6C00), Color(0xFFFFCA28)),
    Page("🎮", "Games: bring your own", listOf(
        "GAMES ▸ + ADD GAME. Use your own original game files (.zip, .rar (RAR4), .7z or the ROM itself). 📁 LINK FOLDER scans a folder.",
        "Mega Drive, Master System and Game Gear are fully supported; Sega CD (needs your BIOS), 32X and Game Boy Advance are experimental; OpenBOR opens in its own app.",
        "Give games versions (Original, French translation, Hack) and re-order them. Every game page has tips and cheats."), Color(0xFF2E7D32), Color(0xFF76FF03), "games", "Open GAMES"),
    Page("✨", "What makes this launcher different", listOf(
        "• Vibration that reacts to the game: rings, hits, jumps, spin dash, springs, shields, drowning and even a ring-stealing bite. It reads the game's memory, so it works with many ROM hacks too, and a Ring Finder lets you teach it any game.",
        "• Rewind, fast-forward, previous-save protection, two-step pause menu, tilt (glitch) mode.",
        "• 20+ shaders, 18 skins, effects behind the game, six ready-made and six custom control layouts.",
        "• No internet permission at all, and one-file backups."), Color(0xFF00695C), Color(0xFF1DE9B6)),
    Page("🧑‍🤝‍🧑", "Meet the helpers", listOf(
        "Each helper knows one area, and they point you to each other:",
        "• Tails (me): the launcher and every setting, in simple, technical or developer depth.",
        "• Sonic: how the games play, their stories, abilities and famous glitches.   • Amy: customisation and other games to try.",
        "• Knuckles: hidden things and keeping your data safe.   • Dr. Eggman: music.   • Metal Sonic: comics, TV and films.",
        "• Motobug: official facts.   • Buzz Bomber: fan creations.   • Shadow: advanced tricks, consoles and what's next.",
        "They work offline and can be wrong or out of date: for anything important check manuals and fan wikis."), Color(0xFF1565C0), Color(0xFF00B0FF), "help", "Open HELP"),
    Page("🎨", "Make it yours", listOf(
        "CUSTOMIZE: skins, frame and shaders, the touch-control editor with presets, backgrounds. A game's ✎ EDIT can have its own shader, skin, controls, music and cheats.",
        "SETTINGS ▸ VIDEO: screen margins for notches and rounded corners (there is a preview), aspect ratio, classic mode, FPS counters.",
        "Amy can tell you more about looks and extras."), Color(0xFFAD1457), Color(0xFFFF4081), "custom", "Open CUSTOMIZE"),
    Page("🎵", "Music, files & safety", listOf(
        "MUSIC: playlists, sorting, covers, equalizers, background play with a notification and headphone buttons (1 press play/pause, 2 next, 3 back).",
        "LOCATIONS shows every folder the app uses. SETTINGS ▸ DATA & PRIVACY: LIGHT or FULL backups, named by you. Updating is simply installing the new APK over the old one.",
        "Classic mode hides advanced settings; Pro mode shows them (SETTINGS ▸ GENERAL). Classic is the default so nothing important gets changed by accident."), Color(0xFF6A1B9A), Color(0xFFE040FB), "music", "Open MUSIC"),
    Page("🛟", "Questions? Ask a helper", listOf(
        "HELP ▸ ASK A HELPER: pick questions from a list, type your own, or both.",
        "That's the whole tour, and you can replay it from the settings. Have fun!"), Color(0xFF37474F), Color(0xFF90A4AE), "help", "Ask a helper"),
)

@Composable
fun GuideOverlay(onGoto: (String) -> Unit) {
    if (!Guide.show) return
    val skin = Skins.current()
    var page by remember { mutableIntStateOf(0) }; var again by remember { mutableStateOf(false) }; var drag by remember { mutableFloatStateOf(0f) }
    var askSkip by remember { mutableStateOf(false) }
    val close = { Store.setB("guideSeen", !again); Guide.show = false }
    if (askSkip) ConfirmDialog("Skip the tutorial?", "close the tour", "delete anything; you can replay it from SETTINGS ▸ ABOUT APP ▸ OPEN GUIDE", yes = "YES, SKIP", force = true, onYes = { askSkip = false; close() }, onNo = { askSkip = false })
    Box(Modifier.fillMaxSize().background(Color(0xE6000000)).clickable(enabled = true) {}.systemBarsPadding()) {
        Column(Modifier.align(Alignment.Center).fillMaxWidth(.94f).widthIn(max = 560.dp).fillMaxHeight(.94f).clip(RoundedCornerShape(24.dp)).background(Color(0xFF15151C))) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("GUIDE  ${page + 1}/${pages.size}", color = skin.accent, fontWeight = FontWeight.Black, letterSpacing = 2.sp, modifier = Modifier.weight(1f))
                Text("✕", color = Color.White, fontSize = 22.sp, modifier = Modifier.clip(CircleShape).clickable { askSkip = true }.padding(horizontal = 12.dp, vertical = 4.dp))
            }
            val p = pages[page]
            // our own swipe handling (no experimental Pager API)
            Column(Modifier.weight(1f).padding(horizontal = 14.dp).clip(RoundedCornerShape(20.dp)).background(Brush.verticalGradient(listOf(p.c1, p.c2.copy(alpha = .75f))))
                .pointerInput(page) { detectHorizontalDragGestures(onDragStart = { drag = 0f }, onDragEnd = { if (drag < -80f && page < pages.size - 1) page++ else if (drag > 80f && page > 0) page-- }, onHorizontalDrag = { _, d -> drag += d }) }
                .verticalScroll(rememberScrollState()).padding(20.dp)) {
                Text(p.emoji, fontSize = 64.sp)
                Text(p.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 8.dp))
                p.lines.forEach { Text(it, color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(vertical = 5.dp)) }
                if (p.goto != null) { Spacer(Modifier.height(12.dp)); Btn("▶ " + p.gotoLabel, color = Color.White) { Guide.show = false; Store.setB("guideSeen", !again); onGoto(p.goto) } }
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                    pages.indices.forEach { i -> Box(Modifier.size(if (i == page) 12.dp else 8.dp).clip(CircleShape).background(if (i == page) skin.accent else Color(0x55FFFFFF)).clickable { page = i }) }
                }
                if (page > 0) { Btn("◀") { page-- }; Spacer(Modifier.width(6.dp)) }
                if (page < pages.size - 1) { Btn("SKIP") { askSkip = true }; Spacer(Modifier.width(8.dp)); Btn("NEXT", selected = true) { page++ } }
                else Btn("DONE", selected = true) { close() }
            }
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Show this guide again next launch", color = Color(0xAAFFFFFF), fontSize = 11.sp, modifier = Modifier.weight(1f))
                Switch(again, { again = it })
            }
        }
    }
}
