package com.sonicforge.core

import java.nio.ByteBuffer

/** JNI facade over the libretro host in bridge.cpp. */
object Emu {
    init { System.loadLibrary("bridge") }
    external fun loadCore(path: String, sysDir: String, saveDir: String): Boolean
    /** returns [fps, sampleRate, width, height, aspect] or null */
    external fun loadGame(path: String, fullPath: Boolean): DoubleArray?
    external fun run()
    external fun fetchFrame(dst: ByteBuffer): Long
    external fun getAudio(out: ShortArray): Int
    external fun setInput(mask: Int)
    external fun reset()
    external fun serializeSize(): Int
    external fun serialize(out: ByteArray): Boolean
    external fun unserialize(data: ByteArray): Boolean
    external fun getSram(): ByteArray?
    external fun setSram(d: ByteArray)
    external fun readRam(start: Int, len: Int): ByteArray?
    external fun setCheats(codes: Array<String>)
    external fun setPadType(device: Int)
    external fun writeRam(offset: Int, value: Int)
    external fun popLogs(): String
    external fun lastError(): String
    external fun coreInfo(): String
    external fun unload()
}

/** libretro joypad bit positions. Genesis Plus GX maps: MD-A=Y, MD-B=B, MD-C=A, Mode=Select. */
object Bits {
    const val B = 1 shl 0; const val Y = 1 shl 1; const val SELECT = 1 shl 2; const val START = 1 shl 3
    const val UP = 1 shl 4; const val DOWN = 1 shl 5; const val LEFT = 1 shl 6; const val RIGHT = 1 shl 7; const val A = 1 shl 8
    const val X = 1 shl 9; const val L = 1 shl 10; const val R = 1 shl 11
}
