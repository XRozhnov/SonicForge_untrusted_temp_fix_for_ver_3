package com.sonicforge.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One recorded problem. note = the app's own comment (never the original message): English + the launcher's language. */
data class Issue(val id: Long, val time: String, val sev: String, val src: String, val ctx: String, val msg: String, val noteEn: String, val noteLoc: String, var pinned: Boolean)

/**
 * Logging in three modes (SETTINGS ▸ ABOUT ▸ tap version 5×): OFF (memory only), ERRORS (default: only problems are saved, not the emulator's chatter), FULL (also a rolling text log).
 * Problems (errors, crashes, recognised warnings) become Issues with a comment from CrashKB. You can KEEP (pin) or DELETE each one; unpinned old ones are pruned automatically.
 */
object Logger {
    private val buf = ArrayDeque<String>()
    private val issues = ArrayList<Issue>()
    lateinit var dir: File
    var context = ""                      // "Game | system | core version", set by the emulator session
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    fun mode() = Store.s("logMode", "errors")

    fun init(ctx: Context) {
        dir = File(ctx.filesDir, "logs").apply { mkdirs() }
        loadIssues()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val trace = android.util.Log.getStackTraceString(e)
                record("CRASH", "app", "Crash in thread ${t.name}\n$trace", force = true)
                File(dir, "crash_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt").writeText("Thread: ${t.name}\nContext: $context\n$trace\n\n--- last log lines ---\n" + text().takeLast(6000))
                Store.setRaw("crashPending", "1")
            } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
        i("App", "started, Android ${android.os.Build.VERSION.SDK_INT}, ${android.os.Build.MODEL}, abi ${android.os.Build.SUPPORTED_ABIS.firstOrNull()}")
    }

    private fun add(level: String, tag: String, msg: String, toFile: Boolean) {
        val line = "${fmt.format(Date())} $level/$tag: $msg"
        synchronized(buf) { buf.addLast(line); if (buf.size > 1500) buf.removeFirst() }
        if (toFile && mode() == "full") try { val f = File(dir, "app.log"); if (f.length() > 300_000) f.writeText(f.readText().takeLast(100_000)); f.appendText(line + "\n") } catch (_: Throwable) {}
    }
    fun d(tag: String, msg: String) = add("D", tag, msg, false)
    fun i(tag: String, msg: String) = add("I", tag, msg, true)
    fun w(tag: String, msg: String) { add("W", tag, msg, true); record("WARN", "app", "$tag: $msg") }
    fun e(tag: String, msg: String, t: Throwable? = null) { val m = msg + (t?.let { "\n" + android.util.Log.getStackTraceString(it) } ?: ""); add("E", tag, m, true); record("ERROR", "app", "$tag: $m") }
    /** a line from the emulator core's own console (level 0 debug, 1 info, 2 warn, 3 error) */
    fun core(level: Int, msg: String) {
        add(when (level) { 3 -> "E"; 2 -> "W"; 1 -> "I"; else -> "D" }, "core", msg, level >= 1)
        if (level >= 3) record("ERROR", "emulator", msg) else if (level == 2) record("WARN", "emulator", msg)
    }

    private fun record(sev: String, src: String, msg: String, force: Boolean = false) {
        if (mode() == "off" && !force) return
        val known = CrashKB.match(msg)
        if (sev == "WARN" && known == null && mode() != "full") return          // unexplained warnings are noise unless FULL
        val (en, loc) = CrashKB.comments(msg, context)
        synchronized(issues) {
            if (issues.any { it.msg == msg && System.currentTimeMillis() - it.id < 60_000 }) return     // de-duplicate bursts
            issues.add(Issue(System.currentTimeMillis(), stamp.format(Date()), sev, src, context, msg.take(4000), en, loc, false))
            val unpinned = issues.filter { !it.pinned }; if (unpinned.size > 300) issues.remove(unpinned.first())
            saveIssues()
        }
    }

    private fun saveIssues() { try { val a = JSONArray(); issues.forEach { a.put(JSONObject().put("id", it.id).put("t", it.time).put("sev", it.sev).put("src", it.src).put("ctx", it.ctx).put("msg", it.msg).put("en", it.noteEn).put("loc", it.noteLoc).put("pin", it.pinned)) }; File(dir, "issues.json").writeText(a.toString()) } catch (_: Throwable) {} }
    private fun loadIssues() { try { val f = File(dir, "issues.json"); if (f.exists()) { val a = JSONArray(f.readText()); for (k in 0 until a.length()) { val o = a.getJSONObject(k); issues.add(Issue(o.getLong("id"), o.getString("t"), o.getString("sev"), o.getString("src"), o.getString("ctx"), o.getString("msg"), o.getString("en"), o.getString("loc"), o.optBoolean("pin"))) } } } catch (_: Throwable) {} }

    // ---- notices: every pop-up the app shows is kept here in FULL (the system pop-up can cut long texts) ----
    val notices = androidx.compose.runtime.mutableStateListOf<String>()
    fun notice(text: String, ok: Boolean = true) {
        val line = "${stamp.format(Date())}  ${if (ok) "OK  " else "WARN"}  $text"
        android.os.Handler(android.os.Looper.getMainLooper()).post { notices.add(0, line); while (notices.size > 300) notices.removeAt(notices.size - 1) }
        try { val f = File(dir, "notices.log"); if (f.length() > 200_000) f.writeText(f.readText().takeLast(80_000)); f.appendText(line + "\n") } catch (_: Throwable) {}
        if (!ok) w("Notice", text) else d("Notice", text)
    }
    fun noticesText(): String = notices.joinToString("\n")
    /** watches the main thread: if the screen freezes for more than 4 seconds (Android's "isn't responding"), where it was stuck is written to the log */
    fun startWatchdog() {
        val main = android.os.Handler(android.os.Looper.getMainLooper())
        kotlin.concurrent.thread(name = "watchdog", isDaemon = true) {
            while (true) {
                val pong = java.util.concurrent.atomic.AtomicBoolean(false)
                main.post { pong.set(true) }
                Thread.sleep(4000)
                if (!pong.get()) {
                    val st = android.os.Looper.getMainLooper().thread.stackTrace.joinToString("\n") { "  at $it" }
                    e("Watchdog", "The main thread was blocked for more than 4 seconds (Android may show 'isn't responding'). It was stuck here:\n$st")
                    Thread.sleep(10000)
                }
            }
        }
    }
    /** Android remembers why the app's last process ended (not responding, native crash, low memory...). We write it into the log at the next start. */
    @Suppress("NewApi")
    fun reportLastExit(ctx: Context) {
        if (android.os.Build.VERSION.SDK_INT < 30) return
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val seen = Store.s("lastExitSeen").toLongOrNull() ?: 0L; var newest = seen
            for (r in am.getHistoricalProcessExitReasons(ctx.packageName, 0, 4)) {
                if (r.timestamp <= seen) continue
                newest = maxOf(newest, r.timestamp)
                val name = when (r.reason) {
                    android.app.ApplicationExitInfo.REASON_ANR -> "ANR (the app did not respond)"
                    android.app.ApplicationExitInfo.REASON_CRASH -> "crash (Java/Kotlin exception)"
                    android.app.ApplicationExitInfo.REASON_CRASH_NATIVE -> "native crash (inside the emulator core or a system library)"
                    android.app.ApplicationExitInfo.REASON_LOW_MEMORY -> "closed because the phone ran out of memory"
                    android.app.ApplicationExitInfo.REASON_SIGNALED -> "killed by a signal"
                    android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "closed for using too many resources"
                    else -> ""
                }
                if (name.isEmpty()) continue
                var trace = ""
                if (r.reason == android.app.ApplicationExitInfo.REASON_ANR || r.reason == android.app.ApplicationExitInfo.REASON_CRASH_NATIVE) trace = try { r.traceInputStream?.bufferedReader()?.readText()?.take(5000) ?: "" } catch (_: Throwable) { "" }
                e("PreviousRun", "The last run of the app ended: $name. ${r.description ?: ""}\n$trace")
            }
            if (newest > seen) Store.set("lastExitSeen", newest.toString())
        } catch (t: Throwable) { w("Logger", "could not read the exit reason: $t") }
    }
    fun fullReport(): String = "SonicForge report\nAndroid ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}), ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}, ABIs ${android.os.Build.SUPPORTED_ABIS.joinToString()}\n\n=== PROBLEMS ===\n" + issuesText() + "\n\n=== NOTICES (every pop-up, complete) ===\n" + noticesText() + "\n\n=== CONSOLE ===\n" + text()
    fun issueList(): List<Issue> = synchronized(issues) { issues.sortedByDescending { it.id } }
    fun pin(id: Long) = synchronized(issues) { issues.firstOrNull { it.id == id }?.let { it.pinned = !it.pinned }; saveIssues() }
    fun delete(id: Long) = synchronized(issues) { issues.removeAll { it.id == id }; saveIssues() }
    fun clearUnpinned() = synchronized(issues) { issues.removeAll { !it.pinned }; saveIssues() }
    fun issuesText(): String = issueList().joinToString("\n\n") { "[${it.time}] ${it.sev} (${it.src})${if (it.ctx.isNotEmpty()) " ${it.ctx}" else ""}\n${it.msg}\n# SonicForge note (EN): ${it.noteEn}\n# SonicForge note: ${it.noteLoc}" }
    fun text(): String = synchronized(buf) { buf.joinToString("\n") }
    fun fileTail(): String = try { File(dir, "app.log").takeIf { it.exists() }?.readText()?.takeLast(20000) ?: "" } catch (_: Throwable) { "" }
    fun clearAll() { synchronized(buf) { buf.clear() }; File(dir, "app.log").delete(); synchronized(issues) { issues.clear(); saveIssues() }; dir.listFiles()?.filter { it.name.startsWith("crash_") }?.forEach { it.delete() }; Store.setRaw("crashPending", "") }
}
