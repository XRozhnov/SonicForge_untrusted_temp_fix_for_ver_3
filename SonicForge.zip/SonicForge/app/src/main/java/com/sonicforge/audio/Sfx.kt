package com.sonicforge.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.net.Uri
import com.sonicforge.data.Library
import com.sonicforge.data.Logger
import com.sonicforge.data.Store
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Launcher/UI sounds: 3 built-in packs (chip / soft / arcade); each event can also use your own short audio file.
 * All packs are loaded once, so choosing a pack (or a custom sound) takes effect on the very next tap: no preview or confirm step.
 * Sound files are made and loaded in the background; the app never waits for them.
 */
object Sfx {
    val events = listOf("click", "confirm", "back", "launch", "error")
    val packs = listOf("chip" to "Chip", "soft" to "Soft", "arcade" to "Arcade")
    private var sp: SoundPool? = null
    private val ids = ConcurrentHashMap<String, Int>()      // "chip_click", "soft_launch", "custom_click" ...
    lateinit var dir: File

    fun init(ctx: Context) {
        dir = File(ctx.filesDir, "sounds").apply { mkdirs() }
        sp = SoundPool.Builder().setMaxStreams(4)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
        kotlin.concurrent.thread(name = "sfx-load") {
            try {
                packs.forEach { (p, _) -> events.forEach { ev ->
                    val f = File(dir, "${p}_$ev.wav")
                    if (!f.exists() || f.length() == 0L) f.writeBytes(Synth.uiSound(ev, p))
                    sp?.load(f.path, 1)?.let { ids["${p}_$ev"] = it }
                } }
                events.forEach { loadCustom(it) }
            } catch (e: Throwable) { Logger.w("Sfx", "could not prepare the menu sounds: $e") }
        }
    }
    private fun loadCustom(ev: String) {
        val c = Store.s("sfx_$ev"); ids.remove("custom_$ev")?.let { sp?.unload(it) }
        if (c.isNotEmpty() && File(c).exists()) sp?.load(c, 1)?.let { ids["custom_$ev"] = it }
    }
    fun reloadAll() { events.forEach { loadCustom(it) } }
    /** plays the sound for an event using whatever pack / custom file is selected right now */
    fun play(ev: String) {
        try {
            val v = (Store.i("volUi", 100) / 100f).coerceIn(0f, 1f)
            val key = if (Store.s("sfx_$ev").isNotEmpty() && ids.containsKey("custom_$ev")) "custom_$ev" else "${Store.s("sfxPack", "chip")}_$ev"
            ids[key]?.let { sp?.play(it, v, v, 1, 0, 1f) }
        } catch (_: Throwable) {}
    }
    fun setPack(p: String) { Store.set("sfxPack", p) }
    fun setCustom(ctx: Context, ev: String, uri: Uri) {
        val name = Library.displayName(ctx, uri).substringAfterLast('.', "wav")
        val f = File(dir, "custom_${ev}_${System.currentTimeMillis()}.$name")
        try { ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } } } catch (_: Exception) { return }
        Store.set("sfx_$ev", f.path); loadCustom(ev)
    }
    fun reset(ev: String) { Store.set("sfx_$ev", ""); loadCustom(ev) }
}
