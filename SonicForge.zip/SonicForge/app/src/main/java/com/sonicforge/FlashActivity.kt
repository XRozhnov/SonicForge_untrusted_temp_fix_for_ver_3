package com.sonicforge

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import com.sonicforge.data.Library
import com.sonicforge.data.Logger
import com.sonicforge.data.Rom
import com.sonicforge.data.Store
import com.sonicforge.input.Haptics
import com.sonicforge.ui.*
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.abs

/**
 * Flash games and movies (.swf) through the Ruffle web player inside a WebView (experimental).
 * Input: real key events and real mouse events are injected into the WebView, so the page sees ordinary keyboard and mouse input.
 *  - touch: "direct" (the finger is the mouse) or "touchpad" (drag = move the cursor, tap = left click, two-finger tap = right click, two-finger drag = scroll, plus hold buttons)
 *  - gamepad: left stick / D-pad -> arrow keys or WASD (or the mouse), face buttons -> Space/Enter/Z/X..., right stick -> mouse cursor, triggers -> clicks
 * Speed depends on the SWF's own frame rate and on Ruffle's render quality: lower the quality if it stutters. Ruffle can't change a game's frame rate.
 */
class FlashActivity : ComponentActivity() {
    private var web: WebView? = null
    private var cx by mutableFloatStateOf(300f); private var cy by mutableFloatStateOf(300f)
    private var lmb by mutableStateOf(false); private var rmb by mutableStateOf(false)
    private var quick by mutableStateOf(false)
    private var reloadToken by mutableIntStateOf(0)
    private var rsx by mutableFloatStateOf(0f); private var rsy by mutableFloatStateOf(0f)
    private var downTime = 0L
    private val padKeys = HashSet<Int>()
    private lateinit var rom: Rom
    private var hasRuffle = false

    // ---------- input injection ----------
    private fun sendKey(code: Int, down: Boolean) {
        val w = web ?: return; val t = SystemClock.uptimeMillis()
        w.dispatchKeyEvent(KeyEvent(t, t, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0))
        if (down && Store.b("flashHaptic", false)) Haptics.gameTouch()
    }
    private fun buttons() = (if (lmb) MotionEvent.BUTTON_PRIMARY else 0) or (if (rmb) MotionEvent.BUTTON_SECONDARY else 0)
    private fun ptr(action: Int, vScroll: Float = 0f, hScroll: Float = 0f) {
        val w = web ?: return; val t = SystemClock.uptimeMillis(); if (action == MotionEvent.ACTION_DOWN) downTime = t
        val pp = MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_MOUSE }
        val pc = MotionEvent.PointerCoords().apply { x = cx; y = cy; pressure = if (buttons() != 0) 1f else 0f; size = 1f; setAxisValue(MotionEvent.AXIS_VSCROLL, vScroll); setAxisValue(MotionEvent.AXIS_HSCROLL, hScroll) }
        val ev = MotionEvent.obtain(downTime, t, action, 1, arrayOf(pp), arrayOf(pc), 0, if (action == MotionEvent.ACTION_UP) 0 else buttons(), 1f, 1f, 0, 0, InputDevice.SOURCE_MOUSE, 0)
        if (action == MotionEvent.ACTION_HOVER_MOVE || action == MotionEvent.ACTION_SCROLL) w.dispatchGenericMotionEvent(ev) else w.dispatchTouchEvent(ev)
        ev.recycle()
    }
    private fun moveCursor(dx: Float, dy: Float) {
        val w = web ?: return
        cx = (cx + dx).coerceIn(0f, w.width.toFloat()); cy = (cy + dy).coerceIn(0f, w.height.toFloat())
        ptr(if (buttons() != 0) MotionEvent.ACTION_MOVE else MotionEvent.ACTION_HOVER_MOVE)
    }
    private fun setButton(primary: Boolean, down: Boolean) {
        if (down) { if (primary) lmb = true else rmb = true; ptr(MotionEvent.ACTION_DOWN) } else { ptr(MotionEvent.ACTION_UP); if (primary) lmb = false else rmb = false }
    }
    private fun click(primary: Boolean) { setButton(primary, true); setButton(primary, false) }

    // ---------- page ----------
    private fun html(): String {
        val q = Store.s("flashQuality", "high"); val sc = Store.s("flashScale", "showAll"); val res = Store.s("flashRes", "fit")
        val size = if (res == "fit") "width:100%;height:100%" else "width:${res.substringBefore('x')}px;height:${res.substringAfter('x')}px"
        val host = "https://appassets.androidplatform.net"
        return """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden;touch-action:none}body{display:flex;align-items:center;justify-content:center}#c{$size}</style>
<script>window.RufflePlayer=window.RufflePlayer||{};window.RufflePlayer.config={publicPath:"$host/assets/ruffle/",autoplay:"auto",unmuteOverlay:"hidden",splashScreen:false,contextMenu:"off",quality:"$q",scale:"$sc",letterbox:"on",warnOnUnsupportedContent:false};</script>
<script src="$host/assets/ruffle/ruffle.js"></script></head><body><div id="c"></div>
<script>window.addEventListener("load",function(){var r=window.RufflePlayer.newest();var p=r.createPlayer();p.style.width="100%";p.style.height="100%";document.getElementById("c").appendChild(p);p.load("$host/roms/${rom.file}");});</script></body></html>"""
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun makeWeb(): WebView {
        val handlerAssets = WebViewAssetLoader.PathHandler { path ->
            try {
                val mime = when { path.endsWith(".wasm") -> "application/wasm"; path.endsWith(".js") -> "text/javascript"; path.endsWith(".json") -> "application/json"; path.endsWith(".css") -> "text/css"; else -> "application/octet-stream" }
                WebResourceResponse(mime, null, assets.open("ruffle/$path"))
            } catch (_: Exception) { null }
        }
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/ruffle/", handlerAssets)
            .addPathHandler("/roms/", WebViewAssetLoader.InternalStoragePathHandler(this, File(filesDir, "roms"))).build()
        return WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false; settings.cacheMode = WebSettings.LOAD_DEFAULT; setBackgroundColor(android.graphics.Color.BLACK)
            isFocusable = true; isFocusableInTouchMode = true
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) { Logger.i("Flash", "page started") }
            }
            loadDataWithBaseURL("https://appassets.androidplatform.net/", html(), "text/html", "utf-8", null)
            requestFocus()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply { hide(WindowInsetsCompat.Type.systemBars()); systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = Orient.flag(Store.s("orientGame", "auto"))
        val r = Library.roms.firstOrNull { it.id == intent.getStringExtra("rom") }
        if (r == null) { finish(); return }
        rom = r; Haptics.currentGame = r.id
        hasRuffle = try { assets.list("ruffle")?.contains("ruffle.js") == true } catch (_: Exception) { false }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() { quick = !quick } })
        setContent { ForgeTheme(Skins.current()) { Screen() } }
    }

    private data class K(val label: String, val code: Int, val fx: Float, val fy: Float)
    private fun keyset(name: String): List<K> = when (name) {
        "arrows+space" -> listOf(K("◀", KeyEvent.KEYCODE_DPAD_LEFT, .07f, .78f), K("▶", KeyEvent.KEYCODE_DPAD_RIGHT, .21f, .78f), K("▲", KeyEvent.KEYCODE_DPAD_UP, .14f, .64f), K("▼", KeyEvent.KEYCODE_DPAD_DOWN, .14f, .90f),
            K("SPACE", KeyEvent.KEYCODE_SPACE, .88f, .80f), K("ENTER", KeyEvent.KEYCODE_ENTER, .88f, .62f))
        "wasd" -> listOf(K("A", KeyEvent.KEYCODE_A, .07f, .78f), K("D", KeyEvent.KEYCODE_D, .21f, .78f), K("W", KeyEvent.KEYCODE_W, .14f, .64f), K("S", KeyEvent.KEYCODE_S, .14f, .90f),
            K("SPACE", KeyEvent.KEYCODE_SPACE, .88f, .80f), K("E", KeyEvent.KEYCODE_E, .88f, .62f))
        "zx" -> listOf(K("◀", KeyEvent.KEYCODE_DPAD_LEFT, .07f, .78f), K("▶", KeyEvent.KEYCODE_DPAD_RIGHT, .21f, .78f), K("▲", KeyEvent.KEYCODE_DPAD_UP, .14f, .64f), K("▼", KeyEvent.KEYCODE_DPAD_DOWN, .14f, .90f),
            K("Z", KeyEvent.KEYCODE_Z, .80f, .80f), K("X", KeyEvent.KEYCODE_X, .92f, .66f), K("C", KeyEvent.KEYCODE_C, .92f, .88f))
        "movie" -> listOf(K("SPACE", KeyEvent.KEYCODE_SPACE, .88f, .88f), K("ENTER", KeyEvent.KEYCODE_ENTER, .72f, .88f), K("ESC", KeyEvent.KEYCODE_ESCAPE, .12f, .88f))
        else -> emptyList()   // "none" = mouse only
    }

    @Composable
    private fun Screen() {
        val mouse = Store.s("flashMouse", "direct"); val stickMode = Store.s("flashStick", "arrows")
        val showCursor = Store.b("flashCursor", true) && (mouse == "touchpad" || stickMode == "mouse")
        val keys = keyset(Store.s("flashKeys", "arrows+space")); val opacity = Store.i("flashKeyAlpha", 60) / 100f
        LaunchedEffect(Unit) { while (true) { delay(16); val sp = Store.i("flashSpeed", 50) / 50f * 14f; if (abs(rsx) > .15f || abs(rsy) > .15f) moveCursor(rsx * sp, rsy * sp) } }
        LaunchedEffect(reloadToken) { if (reloadToken > 0) web?.loadDataWithBaseURL("https://appassets.androidplatform.net/", html(), "text/html", "utf-8", null) }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (!hasRuffle) Column(Modifier.align(Alignment.Center).padding(24.dp)) {
                Text("Ruffle (the Flash player) is not included in this build.", color = Color.White, fontWeight = FontWeight.Bold)
                Text("It is downloaded while the APK is built (fetch_extras.sh). That download failed or was skipped. Rebuild with internet access in the build step, or ask Tails.", color = Color(0xCCFFFFFF), modifier = Modifier.padding(top = 8.dp))
                Btn("◀ BACK", Modifier.padding(top = 12.dp)) { finish() }
            } else {
                AndroidView(factory = { makeWeb().also { web = it; it.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ -> if (cx == 300f && cy == 300f) { cx = v.width / 2f; cy = v.height / 2f } } } }, modifier = Modifier.fillMaxSize())
                if (mouse == "touchpad") Box(Modifier.fillMaxSize().pointerInput(Unit) { awaitPointerEventScope {
                    var moved = 0f; var downAt = 0L; var maxFingers = 0
                    while (true) {
                        val ev = awaitPointerEvent(); val ch = ev.changes; val n = ch.count { it.pressed }
                        if (n > maxFingers) maxFingers = n
                        if (n == 0) { if (ch.isNotEmpty() && moved < 12f && SystemClock.uptimeMillis() - downAt < 300) click(maxFingers < 2); moved = 0f; maxFingers = 0; downAt = 0L }
                        else {
                            if (downAt == 0L) downAt = SystemClock.uptimeMillis()
                            if (n == 1) { val c = ch.first { it.pressed }; val d = c.position - c.previousPosition; val sp = Store.i("flashSpeed", 50) / 50f * 1.6f; moved += abs(d.x) + abs(d.y); moveCursor(d.x * sp, d.y * sp) }
                            else if (n >= 2) { var sy = 0f; var sx = 0f; ch.filter { it.pressed }.forEach { sy += (it.position - it.previousPosition).y; sx += (it.position - it.previousPosition).x }
                                moved += abs(sx) + abs(sy); ptr(MotionEvent.ACTION_SCROLL, -sy / n / 20f, sx / n / 20f) }
                        }
                        ch.forEach { it.consume() }
                    } } })
                if (showCursor) androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                    val p = Path().apply { moveTo(cx, cy); lineTo(cx, cy + 34f); lineTo(cx + 9f, cy + 26f); lineTo(cx + 17f, cy + 40f); lineTo(cx + 23f, cy + 37f); lineTo(cx + 15f, cy + 23f); lineTo(cx + 27f, cy + 23f); close() }
                    drawPath(p, Color.White); drawPath(p, Color.Black, style = androidx.compose.ui.graphics.drawscope.Stroke(2f)) }
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    keys.forEach { k ->
                        Box(Modifier.offset(maxWidth * k.fx - 28.dp, maxHeight * k.fy - 28.dp).size(if (k.label.length > 2) 70.dp else 56.dp).clip(CircleShape).background(Color.White.copy(alpha = opacity * .35f)).border(2.dp, Color.White.copy(alpha = opacity), CircleShape)
                            .pointerInput(k) { detectTapGestures(onPress = { sendKey(k.code, true); tryAwaitRelease(); sendKey(k.code, false) }) }, Alignment.Center) { Text(k.label, color = Color.White.copy(alpha = opacity + .2f), fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    }
                    if (mouse == "touchpad" || stickMode == "mouse") Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            for (left in listOf(true, false)) Box(Modifier.size(64.dp).clip(CircleShape).background(if ((if (left) lmb else rmb)) Color(0xFF69F0AE).copy(.6f) else Color.White.copy(.25f)).border(2.dp, Color.White.copy(.8f), CircleShape)
                                .pointerInput(left) { detectTapGestures(onPress = { setButton(left, true); tryAwaitRelease(); setButton(left, false) }) }, Alignment.Center) { Text(if (left) "LEFT\nHOLD" else "RIGHT\nHOLD", color = Color.White, fontSize = 9.sp) } }
                    }
                }
            }
            if (Store.b("flashKbOn", false)) Box(Modifier.align(Alignment.BottomCenter)) { FullKeyboard(Store.i("flashKbAlpha", 55) / 100f) }
            Row(Modifier.align(Alignment.TopEnd).padding(6.dp).background(Color(0x66000000), RoundedCornerShape(20.dp)).padding(horizontal = 4.dp)) {
                Text("≡ CONTROLS", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable { quick = true }.padding(8.dp))
                Text("⌨", color = if (Store.b("flashKbOn", false)) Color(0xFF9BFF9B) else Color.White, fontSize = 14.sp, modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable { Store.setB("flashKbOn", !Store.b("flashKbOn", false)) }.padding(8.dp))
                Text("✕", color = Color(0xFFFFCDD2), fontSize = 14.sp, modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable { finish() }.padding(8.dp))
            }
            if (quick) QuickMenu()
        }
    }

    @Composable
    private fun QuickMenu() {
        Box(Modifier.fillMaxSize().background(Color(0xAA000000)).clickable(enabled = false) {}, Alignment.Center) {
            Column(Modifier.widthIn(max = 460.dp).fillMaxWidth(.92f).fillMaxHeight(.92f).clip(RoundedCornerShape(16.dp)).background(Color(0xF015151C)).verticalScroll(rememberScrollState()).padding(14.dp)) {
                Text("FLASH CONTROLS — ${rom.title}", color = Skins.current().accent, fontWeight = FontWeight.Black)
                Text("Experimental. Changes apply immediately, except quality/scale/resolution (press RELOAD).", color = Color(0x99FFFFFF), fontSize = 10.sp)
                Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("▶ BACK TO GAME", selected = true) { quick = false }; Btn("RELOAD") { reloadToken++; quick = false }; Btn("EXIT", color = Color(0xFFE53935)) { finish() } }
                SChips("Mouse (touch)", "flashMouse", "direct", listOf("direct" to "Direct touch", "touchpad" to "Touchpad"))
                Text("Direct: your finger is the mouse. Touchpad: drag moves the cursor, tap = left click, two-finger tap = right click, two-finger drag = scroll, and you can HOLD the LEFT/RIGHT buttons with one finger while another moves the cursor (to drag objects).", color = Color(0xAAFFFFFF), fontSize = 11.sp)
                SChips("Gamepad: left stick / D-pad", "flashStick", "arrows", listOf("arrows" to "Arrow keys", "wasd" to "W A S D", "mouse" to "Mouse cursor"))
                Text("Right stick always moves the cursor; L2 = left click, R2 = right click, L1 = Shift, R1 = Ctrl. A real gamepad touchpad (PlayStation) is not exposed by Android, so it can't be used.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
                SChips("On-screen keys", "flashKeys", "arrows+space", listOf("arrows+space" to "Arrows + Space/Enter", "wasd" to "WASD + Space", "zx" to "Arrows + Z X C", "movie" to "Movie (Space/Enter/Esc)", "none" to "None (mouse only)"))
                SSlider("On-screen key opacity", "flashKeyAlpha", 60); SSlider("Cursor speed", "flashSpeed", 50); SToggle("Show cursor", "flashCursor", true)
                SToggle("Vibration for key presses (off by default)", "flashHaptic", false)
                H("Gamepad buttons: choose the key for each")
                Text("Every gamepad button can press any key (or a mouse click) inside the Flash game, like the button settings of a normal game. Tap a box to change it.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
                BIND_BUTTONS.forEach { b ->
                    var open by remember { mutableStateOf(false) }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                        Text(b, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(80.dp))
                        Box { Btn(bound(b)) { open = true }; DropdownMenu(open, { open = false }) { BIND_CHOICES.forEach { c -> DropdownMenuItem({ Text(c) }, { Store.set("flb_$b", c); open = false }) } } }
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("PLATFORMER") { Store.set("flb_A", "SPACE"); Store.set("flb_B", "ENTER"); Store.set("flb_X", "Z"); Store.set("flb_Y", "X") }
                    Btn("ADVENTURE") { Store.set("flb_A", "ENTER"); Store.set("flb_B", "ESC"); Store.set("flb_X", "SPACE"); Store.set("flb_Y", "TAB") }
                    Btn("RESET BUTTONS") { BIND_BUTTONS.forEach { Store.set("flb_$it", "") } }
                }
                H("Full keyboard over the game")
                SToggle("Show the full keyboard (see-through)", "flashKbOn", false, "Also available from the ⌨ button at the top right.")
                SSlider("Keyboard opacity", "flashKbAlpha", 55)
                H("Picture")
                SChips("Quality (RELOAD)", "flashQuality", "high", listOf("low" to "Low (fastest)", "medium" to "Medium", "high" to "High", "best" to "Best"))
                SChips("Scale mode (RELOAD)", "flashScale", "showAll", listOf("showAll" to "Show all", "noBorder" to "Fill (crop)", "exactFit" to "Stretch", "noScale" to "No scale"))
                SChips("Resolution (RELOAD)", "flashRes", "fit", listOf("fit" to "Fit screen", "640x480" to "640×480", "800x600" to "800×600", "1024x768" to "1024×768", "1280x720" to "1280×720"))
                Text("PERFORMANCE: Flash games run at the frame rate they were made for (often 24-30 fps) and Ruffle can't change it. If a game is slow, lower the quality, use a smaller resolution, or close other apps. Ruffle does not play every game: older (ActionScript 1/2) content works best; some ActionScript 3 games, 3D and some video features may not work.", color = Color(0xCCFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }

    // ---------- key names and gamepad bindings ----------
    private val KEYS: Map<String, Int> = buildMap {
        put("SPACE", KeyEvent.KEYCODE_SPACE); put("ENTER", KeyEvent.KEYCODE_ENTER); put("ESC", KeyEvent.KEYCODE_ESCAPE); put("TAB", KeyEvent.KEYCODE_TAB)
        put("SHIFT", KeyEvent.KEYCODE_SHIFT_LEFT); put("CTRL", KeyEvent.KEYCODE_CTRL_LEFT); put("ALT", KeyEvent.KEYCODE_ALT_LEFT)
        put("UP", KeyEvent.KEYCODE_DPAD_UP); put("DOWN", KeyEvent.KEYCODE_DPAD_DOWN); put("LEFT", KeyEvent.KEYCODE_DPAD_LEFT); put("RIGHT", KeyEvent.KEYCODE_DPAD_RIGHT)
        for (c in 'A'..'Z') put(c.toString(), KeyEvent.KEYCODE_A + (c - 'A'))
        for (d in 0..9) put(d.toString(), KeyEvent.KEYCODE_0 + d)
    }
    private val BIND_CHOICES = listOf("NONE", "SPACE", "ENTER", "ESC", "TAB", "SHIFT", "CTRL", "ALT", "UP", "DOWN", "LEFT", "RIGHT", "W", "A", "S", "D", "Q", "E", "R", "F", "Z", "X", "C", "V", "1", "2", "3", "4", "MOUSE L", "MOUSE R")
    private val BIND_BUTTONS = listOf("A", "B", "X", "Y", "L1", "R1", "L2", "R2", "START", "SELECT")
    private fun defaultBind(b: String) = when (b) { "A" -> "SPACE"; "B" -> "ENTER"; "X" -> "Z"; "Y" -> "X"; "L1" -> "SHIFT"; "R1" -> "CTRL"; "L2" -> "MOUSE L"; "R2" -> "MOUSE R"; "START" -> "ENTER"; "SELECT" -> "ESC"; else -> "NONE" }
    private fun bound(b: String) = Store.s("flb_$b").ifEmpty { defaultBind(b) }
    private fun act(name: String, down: Boolean) { when (name) { "NONE" -> {}; "MOUSE L" -> setButton(true, down); "MOUSE R" -> setButton(false, down); else -> KEYS[name]?.let { sendKey(it, down) } } }

    @Composable private fun KeyBtn(label: String, code: Int, m: Modifier, alpha: Float) =
        Box(m.height(36.dp).clip(RoundedCornerShape(6.dp)).background(Color.White.copy(alpha = alpha * .35f)).border(1.dp, Color.White.copy(alpha = alpha), RoundedCornerShape(6.dp))
            .pointerInput(code) { detectTapGestures(onPress = { sendKey(code, true); tryAwaitRelease(); sendKey(code, false) }) }, Alignment.Center) { Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }

    /** a full keyboard drawn over the lower part of the game, see-through so the picture stays visible (like the official Ruffle app, but optional and transparent) */
    @Composable private fun FullKeyboard(alpha: Float) {
        val rows = listOf("1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
        Column(Modifier.fillMaxWidth().background(Color.Black.copy(alpha = alpha * .5f)).padding(4.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            rows.forEach { r -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) { r.forEach { ch -> KeyBtn(ch.toString(), KEYS[ch.toString()] ?: 0, Modifier.weight(1f), alpha) } } }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                KeyBtn("ESC", KEYS["ESC"]!!, Modifier.weight(1f), alpha); KeyBtn("TAB", KEYS["TAB"]!!, Modifier.weight(1f), alpha); KeyBtn("SHIFT", KEYS["SHIFT"]!!, Modifier.weight(1.2f), alpha)
                KeyBtn("CTRL", KEYS["CTRL"]!!, Modifier.weight(1.2f), alpha); KeyBtn("ALT", KEYS["ALT"]!!, Modifier.weight(1f), alpha); KeyBtn("SPACE", KEYS["SPACE"]!!, Modifier.weight(3f), alpha)
                KeyBtn("←", KEYS["LEFT"]!!, Modifier.weight(1f), alpha); KeyBtn("↑", KEYS["UP"]!!, Modifier.weight(1f), alpha); KeyBtn("↓", KEYS["DOWN"]!!, Modifier.weight(1f), alpha); KeyBtn("→", KEYS["RIGHT"]!!, Modifier.weight(1f), alpha)
                KeyBtn("ENTER", KEYS["ENTER"]!!, Modifier.weight(1.4f), alpha)
            }
        }
    }

    // ---------- gamepad ----------
    private fun stickKeys(want: Set<Int>, owned: MutableSet<Int>) { (owned - want).forEach { sendKey(it, false) }; (want - owned).forEach { sendKey(it, true) }; owned.clear(); owned.addAll(want) }
    private val stickHeld = HashSet<Int>()
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) com.sonicforge.input.Pads.lastKey = com.sonicforge.input.Pads.keyName(e.keyCode)
        val gp = (e.source and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD || (e.source and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD
        if (!gp || e.keyCode == KeyEvent.KEYCODE_BACK || quick) return super.dispatchKeyEvent(e)
        val down = e.action == KeyEvent.ACTION_DOWN; if (down && e.repeatCount > 0) return true
        val wasd = Store.s("flashStick", "arrows") == "wasd"
        val btn = when (e.keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> "A"; KeyEvent.KEYCODE_BUTTON_B -> "B"; KeyEvent.KEYCODE_BUTTON_X -> "X"; KeyEvent.KEYCODE_BUTTON_Y -> "Y"
            KeyEvent.KEYCODE_BUTTON_L1 -> "L1"; KeyEvent.KEYCODE_BUTTON_R1 -> "R1"; KeyEvent.KEYCODE_BUTTON_L2 -> "L2"; KeyEvent.KEYCODE_BUTTON_R2 -> "R2"
            KeyEvent.KEYCODE_BUTTON_START -> "START"; KeyEvent.KEYCODE_BUTTON_SELECT -> "SELECT"; else -> null
        }
        when {
            btn != null -> act(bound(btn), down)
            e.keyCode == KeyEvent.KEYCODE_DPAD_UP -> sendKey(if (wasd) KeyEvent.KEYCODE_W else KeyEvent.KEYCODE_DPAD_UP, down)
            e.keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> sendKey(if (wasd) KeyEvent.KEYCODE_S else KeyEvent.KEYCODE_DPAD_DOWN, down)
            e.keyCode == KeyEvent.KEYCODE_DPAD_LEFT -> sendKey(if (wasd) KeyEvent.KEYCODE_A else KeyEvent.KEYCODE_DPAD_LEFT, down)
            e.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT -> sendKey(if (wasd) KeyEvent.KEYCODE_D else KeyEvent.KEYCODE_DPAD_RIGHT, down)
            e.keyCode == KeyEvent.KEYCODE_BUTTON_MODE -> if (down) quick = !quick
            else -> return super.dispatchKeyEvent(e)
        }
        return true
    }
    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) != 0 && e.action == MotionEvent.ACTION_MOVE && !quick) {
            val x = e.getAxisValue(MotionEvent.AXIS_X) + e.getAxisValue(MotionEvent.AXIS_HAT_X); val y = e.getAxisValue(MotionEvent.AXIS_Y) + e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val mode = Store.s("flashStick", "arrows"); val dz = .35f
            if (mode == "mouse") { stickKeys(emptySet(), stickHeld); if (abs(x) > .15f || abs(y) > .15f) moveCursor(x * 14f * Store.i("flashSpeed", 50) / 50f, y * 14f * Store.i("flashSpeed", 50) / 50f) }
            else { val wasd = mode == "wasd"; val w = HashSet<Int>()
                if (x < -dz) w.add(if (wasd) KeyEvent.KEYCODE_A else KeyEvent.KEYCODE_DPAD_LEFT); if (x > dz) w.add(if (wasd) KeyEvent.KEYCODE_D else KeyEvent.KEYCODE_DPAD_RIGHT)
                if (y < -dz) w.add(if (wasd) KeyEvent.KEYCODE_W else KeyEvent.KEYCODE_DPAD_UP); if (y > dz) w.add(if (wasd) KeyEvent.KEYCODE_S else KeyEvent.KEYCODE_DPAD_DOWN)
                stickKeys(w, stickHeld) }
            rsx = e.getAxisValue(MotionEvent.AXIS_Z).let { if (abs(it) < .1f) e.getAxisValue(MotionEvent.AXIS_RX) else it }; rsy = e.getAxisValue(MotionEvent.AXIS_RZ).let { if (abs(it) < .1f) e.getAxisValue(MotionEvent.AXIS_RY) else it }
            return true
        }
        return super.onGenericMotionEvent(e)
    }
    override fun onPause() { super.onPause(); web?.onPause() }
    override fun onResume() { super.onResume(); web?.onResume() }
    override fun onDestroy() { super.onDestroy(); web?.destroy(); Haptics.currentGame = "" }
}
