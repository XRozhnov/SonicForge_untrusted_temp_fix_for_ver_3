package com.sonicforge.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Logger
import com.sonicforge.data.Store

data class Release(val version: String, val name: String, val date: String, val items: List<String>)

object Changelog {
    val all = listOf(
        Release("0.3.4", "Rock Solid Rings", "Nov 2026", listOf(
            "🎨 DRAW tab (new): pixel-art canvas with layers (show/hide, opacity, CLIP to the layer below), pencil / eraser / fill / eyedropper, zoom and pan, add a picture onto a layer or as a new layer, resize the canvas, undo, export PNG. Your drawing is saved and reopens next time",
            "🔊 Menu sounds: they only play when you tap something (the little scene under a game used to make them by itself); a new sound pack applies at once, no preview needed; sounds are prepared in the background",
            "🔧 GAMES RUN AGAIN: importing a ROM, ZIP, RAR or 7z really saves the game now (the save step was switched off by mistake in 0.3.3, so the core 'rejected' every ROM). A game whose file is missing is flagged and is repaired by importing it again",
            "💽 Sega CD BIOS: any BIOS dump works whatever its file name; you can pick a whole zip of them. The app reads the region from the file itself and installs it under the name the core needs",
            "🕹 Mini-games no longer crash (an endless loop in the hero colour code). The little scene under a game no longer makes sounds by itself",
            "🎵 Music: the screen can't freeze or crash any more (song details load in the background, the list changes safely), 600+ songs are fine; shuffle plays every song once per round and BACK returns to the songs you really heard; QUEUE panel (what played, what is next); favourites ♥ and built-in lists (Recent, Imported, Built-in, Linked folder); MOVE mode; adding music while a playlist is open puts it into that playlist; a hide-able mini player on every tab; the current song and the list can no longer get out of step after an import",
            "🧾 Logs: every pop-up is also kept in full (NOTICES tab), COPY / SAVE FILE / SHARE for the whole log, one entry, or only errors; the app now records freezes ('not responding') and why the last run ended",
            "🕹 Flash (experimental): Ruffle is now downloaded in two ways at build time; full see-through keyboard over the game (⌨), a key for every gamepad button, left stick/D-pad as arrows, WASD or mouse, touchpad mouse mode",
            "🎛 Sliders: ↺ back to default and tap the number to type an exact value; moving a screen margin shows the real picture area on your screen; vibration test tells you what it did and has RESET ALL",
            "🧭 Settings re-organised: SCREEN & LOOK, SOUND & MUSIC, ABOUT & UPDATES hold everything of their kind; LOCATIONS can BROWSE every app folder; the 'show game UI again' button moved to SETTINGS ▸ GENERAL",
            "📲 Quick Settings tiles: Launcher, Music play/pause, Last game, Ask a character (pull down the shade, tap the pencil, drag a tile in)",
            "🌐 The language switch always shows an English 'Languages' under it (so you can find it in any language); welcome title translated into every language; darker 'Are you sure?' pop-ups; MD/SMS/GG explained",
            "🧰 Build: 7z and RAR4 archives are read; build.yml updated (copy it from SETTINGS ▸ ABOUT & UPDATES) so Ruffle is really included; three APKs per build")),
        Release("0.3.3", "Emerald Everything Plus", "Nov 2026", listOf(
            "🛠 Build stability: no experimental Compose API any more (own swipe pages); one build now makes THREE APKs: Universal, arm64-v8a, armeabi-v7a",
            "📺 Android TV / remote basics (same APK), minimum Android 8.0 stated; ABI and Android info in ABOUT APP",
            "🎮 Systems: Mega Drive, Master System, Game Gear, Sega CD (BIOS needed), optional 32X and Game Boy Advance cores, OpenBOR via its own app with a CPU-match report, Flash games through Ruffle (experimental)",
            "🕹 Flash: touch mouse or touchpad mode (tap, two-finger right-click and scroll, hold buttons), gamepad sticks as arrows/WASD/mouse, on-screen key sets, quality/scale/resolution",
            "⏯ Two-step pause menu that freezes the game; mini music player, vibration, cheats, screen, controls and tools inside it",
            "🕹 Controls: 7 ready-made layouts (close 6-button, GBA) + 6 of your own, gamepad/keyboard maps with APPLY/CANCEL/RESET, combos, controller visualisation, opacity per orientation, Pocket Lock, Stay Awake, quick opacity, UI rescue button",
            "📳 Vibration: 18 events (rings, hits, jump, spin dash, springs, Tails flying, drowning, ring bite and drain, extra life, shields, speed shoes, footsteps), templates, presets, per-game switches, Ring Finder for any game",
            "🎚 Volumes up to 200% with snap, -1/+1 and reset; music in game never restarts your song; 3 menu sound packs",
            "🎵 Music: playlists (merge/ungroup/reorder), multi-select, sorting, covers, equalizers, ±10/30 s, scratch disc, details toggles, failed-import list with reasons, background notification + headphone multi-click, 2-minute test track",
            "🧩 11 mini-games with pause, mute, best, rules, 3-2-1-GO; Speed Cafe uses real menu names; the scene under each game really collects rings; 28 colour palettes",
            "🎨 22 shaders (incl. a lighter bloom), 18 skins, effects behind the game, screen margins/corners/classic mode with a preview, FPS counters (emulated vs screen)",
            "🧑‍🤝‍🧑 9 helpers with 110+ answers (Tails in three depths), character-led tutorial with skip confirmation, Classic/Pro mode, confirmations with delay",
            "🗂 LOCATIONS tab, LIGHT/FULL named backups, logs and crash reports with explanations in two languages (hidden near the version), 13 languages incl. Brazilian Portuguese, Korean, Hindi, Turkish")),
        Release("0.2.0", "Archives n' Cheats", "Oct 2026", listOf(
            "📦 Import ROMs from .zip, .rar and .7z; link a ROM folder; IPS/BPS patches", "🔑 Per-game cheats", "⏪ Rewind, fast-forward, 6-button option, screenshots",
            "🎨 RGB colour pickers, per-game shader/skin/layout/music", "🕹 Tails Flyer and Zone Trivia", "🌍 10 languages, guide, version history")),
        Release("0.1.0", "Customisation n' Blue", "Oct 2026", listOf(
            "First release: launcher with per-game art, mini-scenes", "Genesis Plus GX emulation with saves, save states, FPS control",
            "9 shaders, 10 skins, touch-control editor with 6 presets, controller remapping", "Retro music player, custom launcher sounds, independent volumes, vibration, no INTERNET permission")),
    )
    val unfinished = listOf(
        "Translations of the What's new text, the tutorial, help topics and character dialogues (only buttons and titles are translated)",
        "Music: more equalizer styles, two more player looks, one 'all characters' guide, playlist covers, lyrics/timestamps, karaoke",
        "Image import: recommended sizes and a small crop editor (like changing a Discord avatar) that keeps no unused copies",
        "Console cores: Nintendo DS, SRB2, 3DS/Saturn/Dreamcast are not included (see HELP ▸ systems for why)",
        "Android TV remote layout and an x86 build; home-screen widgets",
        "Holiday themes, gradient/image backgrounds, PNG-mask frames, per-tab presets",
        "Hack-specific vibration profiles (Sonic 2 XL, Hellfire Saga...), wind in Sky Battery, breakable walls")
    val planned = listOf(
        "Drawing tab, round two: brush shapes, selection/move, layer folders, blend modes, a gallery of several drawings",
        "Simple text editor and a file explorer (multi-select, format groups, hidden/system toggle)",
        "Comics reader (Kotatsu-style), photo gallery, video player (YouTube-style controls)",
        "Music: Auxio / YouTube Music style library (songs, albums, artists, genres, playlists with pictures)",
        "Flash: per-game control profiles, Ruffle updates")
}

fun copyText(ctx: Context, t: String) { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("log", t)); Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show() }

@Composable
fun AboutTab() {
    val ctx = LocalContext.current; val skin = Skins.current()
    val (ver, code) = remember { try { val i = ctx.packageManager.getPackageInfo(ctx.packageName, 0); (i.versionName ?: "?") to (if (Build.VERSION.SDK_INT >= 28) i.longVersionCode else @Suppress("DEPRECATION") i.versionCode.toLong()) } catch (_: Exception) { "?" to 0L } }
    val rel = Changelog.all.first(); var taps by remember { mutableIntStateOf(0) }; var logs by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(84.dp).clip(RoundedCornerShape(20.dp))) {   // the Chaos-Emerald gem logo
            val w = size.width; drawRect(Color(0xFF0B1F3A))
            val gem = Path().apply { moveTo(w * .33f, w * .3f); lineTo(w * .67f, w * .3f); lineTo(w * .8f, w * .47f); lineTo(w * .5f, w * .79f); lineTo(w * .2f, w * .47f); close() }
            drawPath(gem, Color(0xFF1DE9B6)); drawPath(gem, Color.White, style = Stroke(w * .03f))
            drawLine(Color.White, Offset(w * .2f, w * .47f), Offset(w * .8f, w * .47f), w * .025f); drawLine(Color.White, Offset(w * .33f, w * .3f), Offset(w * .41f, w * .47f), w * .025f); drawLine(Color.White, Offset(w * .67f, w * .3f), Offset(w * .59f, w * .47f), w * .025f)
        }
        Text("SonicForge", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 8.dp))
        Text("Version $ver  ·  “${rel.name}”", color = skin.accent, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { taps++; if (taps >= 5) { taps = 0; logs = true } }.padding(6.dp))
        Text("build $code", color = Color(0x99FFFFFF), fontSize = 11.sp)
    }
    Btn("OPEN GUIDE", Modifier.fillMaxWidth()) { Guide.show = true }
    H("Your device & which APK")
    val abis = Build.SUPPORTED_ABIS.joinToString(); val is64 = Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()
    Text("CPU types supported: $abis\nThis app is running as ${if (android.os.Process.is64Bit()) "64-bit" else "32-bit"}.\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}). SonicForge needs Android 8.0 (API 26) or newer.", color = Color.White, fontSize = 12.sp)
    Text(if (is64) "Recommended APK: arm64-v8a (or Universal)." else if (Build.SUPPORTED_ABIS.any { it.startsWith("armeabi") }) "Recommended APK: armeabi-v7a (or Universal)." else "Your CPU isn't ARM: use the Universal APK (the emulator cores may not run).", color = skin.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Text("Universal = works everywhere, largest. arm64-v8a = nearly all phones since about 2017, smaller. armeabi-v7a = older 32-bit phones. Android TV uses the same APK.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
    H("Credits & licences")
    Text("Emulation: Genesis Plus GX, PicoDrive and mGBA (libretro cores, their own licences; Genesis Plus GX is non-commercial). Archives: junrar, Apache Commons Compress, XZ for Java.\nNo ROMs, no ads, no internet permission.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    if (logs) LogsDialog { logs = false }
}

@Composable
fun UpdatesTab() {
    val skin = Skins.current()
    var open by remember { mutableStateOf(setOf(Changelog.all.first().version)) }
    H("Version history")
    Changelog.all.forEach { r ->
        val isOpen = r.version in open
        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(.4f)).forgeClick { open = if (isOpen) open - r.version else open + r.version }.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("v${r.version}  “${r.name}”", color = skin.accent, fontWeight = FontWeight.Black); Text(r.date, color = Color(0x99FFFFFF), fontSize = 11.sp) }
                Text(if (isOpen) "▲" else "▼", color = Color.White)
            }
            if (isOpen) r.items.forEach { Text("• $it", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
        }
    }
    H("Not finished yet (carried over)")
    Changelog.unfinished.forEach { Text("• $it", color = Color(0xCCFFCC80), fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) }
    H("Planned for later builds")
    Changelog.planned.forEach { Text("• $it", color = Color(0xCCFFFFFF), fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) }
    H("Build workflow file (build.yml)")
    val wctx = androidx.compose.ui.platform.LocalContext.current
    Text("GitHub only reads the workflow from the REPOSITORY ROOT, not from inside SonicForge.zip. After every update that changes the build steps, replace the file in your repo with this one.", color = Color(0xCCFFFFFF), fontSize = 12.sp)
    Text("Path in your repo:  .github/workflows/build.yml", color = skin.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Btn("COPY build.yml (zip method)") {
        val txt = try { wctx.assets.open("build-workflow.yml").bufferedReader().readText() } catch (e: Exception) { "" }
        if (txt.isNotEmpty()) { (wctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("build.yml", txt)); com.sonicforge.data.Store.events.tryEmit(com.sonicforge.data.SaveEvent("build.yml copied (${txt.length} characters). Paste it into .github/workflows/build.yml in your repo.", true)) }
    }
}
