package com.sonicforge.audio

import com.sonicforge.data.Store
import org.json.JSONArray
import org.json.JSONObject

/** Named lists of track paths. Deleting a playlist never deletes files ("ungroup"); two playlists can be merged. */
object Playlists {
    val names = androidx.compose.runtime.mutableStateListOf<String>()
    private val map = LinkedHashMap<String, MutableList<String>>()
    fun load() {
        map.clear(); names.clear()
        try { val o = JSONObject(Store.read("playlists.json") ?: "{}"); o.keys().forEach { k -> val a = o.getJSONArray(k); map[k] = MutableList(a.length()) { a.getString(it) } } } catch (_: Exception) {}
        names.addAll(map.keys)
    }
    private fun save() { val o = JSONObject(); map.forEach { (k, v) -> o.put(k, JSONArray(v)) }; Store.writeVerified("playlists.json", o.toString()); names.clear(); names.addAll(map.keys) }
    fun tracks(name: String): List<String> = map[name] ?: emptyList()
    fun create(name: String) { val n = name.trim().ifEmpty { return }; if (n !in map) { map[n] = mutableListOf(); save() } }
    fun add(name: String, paths: Collection<String>) { val l = map.getOrPut(name) { mutableListOf() }; paths.forEach { if (it !in l) l.add(it) }; save() }
    fun remove(name: String, paths: Collection<String>) { map[name]?.removeAll(paths.toSet()); save() }
    fun delete(name: String) { map.remove(name); save() }
    fun merge(a: String, b: String, into: String) { val l = (tracks(a) + tracks(b)).distinct().toMutableList(); map.remove(a); map.remove(b); map[into.trim().ifEmpty { a }] = l; save() }
    fun move(name: String, from: Int, to: Int) { val l = map[name] ?: return; if (from in l.indices && to in l.indices) { val t = l.removeAt(from); l.add(to, t); save() } }
}
