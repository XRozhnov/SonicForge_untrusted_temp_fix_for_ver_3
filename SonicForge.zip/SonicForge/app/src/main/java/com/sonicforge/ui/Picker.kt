package com.sonicforge.ui

import android.net.Uri

/** Bridge from composables to the Activity's system pickers (Storage Access Framework: the app only sees what you pick). */
object Picker {
    var launcher: ((Array<String>, (List<Uri>) -> Unit) -> Unit)? = null
    var creator: ((String, (Uri) -> Unit) -> Unit)? = null
    var tree: (((Uri) -> Unit) -> Unit)? = null
    var textCreator: ((String, (Uri) -> Unit) -> Unit)? = null
    fun createText(name: String, cb: (Uri) -> Unit) { textCreator?.invoke(name, cb) }
    fun pick(mime: Array<String> = arrayOf("*/*"), cb: (List<Uri>) -> Unit) { launcher?.invoke(mime, cb) }
    fun create(name: String, cb: (Uri) -> Unit) { creator?.invoke(name, cb) }
    fun pickTree(cb: (Uri) -> Unit) { tree?.invoke(cb) }
}
