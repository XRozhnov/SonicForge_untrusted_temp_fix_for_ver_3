package com.sonicforge.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Library
import com.sonicforge.data.Store
import com.sonicforge.input.Haptics
import kotlin.math.roundToInt

/** The vibration settings. Used in SETTINGS ▸ VIBRATION (full) and in the in-game menu (compact = same controls, no long explanations). */
@Composable
fun HapticsPanel(compact: Boolean) {
    val game = Haptics.currentGame
    H("Master switches")
    SToggle("Vibration: APP (menus & buttons)", "hapAppOn", true, if (compact) null else "Launcher taps. Independent from the emulator.")
    SToggle("Vibration: EMULATOR (touch buttons & game events)", "hapGameOn", true, if (compact) null else "Your per-event settings are kept when this is off.")
    if (compact && game.isNotEmpty()) {
        val on = Store.s("hapG_$game", "1") != "0"
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Vibration for THIS game", color = Color.White, modifier = Modifier.weight(1f)); Switch(on, { Store.set("hapG_$game", if (it) "1" else "0") }) }
    } else if (!compact) {
        H("Apply to these games")
        Text("Switch vibration off for a game without losing your settings.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
        Library.roms.forEach { r ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(r.title, color = Color.White, maxLines = 1); Text(com.sonicforge.core.Systems.byId(r.sys).label + if (r.sys in setOf("md", "scd")) "" else " (touch buttons only)", color = Color(0x88FFFFFF), fontSize = 10.sp) }
                Switch(Store.s("hapG_${r.id}", "1") != "0", { Store.set("hapG_${r.id}", if (it) "1" else "0") }) }
        }
    }
    H("Templates & presets")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("QUIET") { Haptics.template("quiet") }; Btn("MEDIUM") { Haptics.template("medium") }; Btn("MAX") { Haptics.template("max") } }
    Text("Built-in presets: 1 = rings + buttons only · 2 = classic set · 3 = everything. 4-9 are empty slots for you.", color = Color(0xAAFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (n in 1..9) Btn(if (n <= 3) "$n" else if (Haptics.presetExists(n)) "$n" else "$n ∅", color = if (n <= 3) Color(0xFF26C6DA) else null) { Haptics.loadPreset(n) } }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("SAVE CURRENT TO", color = Skins.current().accent, fontSize = 11.sp, fontWeight = FontWeight.Bold); for (n in 4..9) Btn("$n") { Haptics.savePreset(n) } }
    if (!compact) { SSlider("App vibration strength", "hapApp", 35); Btn("TEST APP VIBRATION") { Haptics.test("ui"); Store.events.tryEmit(com.sonicforge.data.SaveEvent("Test buzz sent at ${Store.i("hapApp", 35)}%. If you felt nothing: raise the strength, or check that vibration is on in your phone's settings.", true)) } }
    Btn("RESET ALL VIBRATION VALUES") { Store.set("hapApp", ""); Haptics.events.forEach { Store.set("hapE_${it.id}_amp", "") }; Store.events.tryEmit(com.sonicforge.data.SaveEvent("Vibration strengths reset to their defaults", true)) }
    H("Events (on/off + strength)")
    Haptics.events.forEach { e ->
        val amp = Haptics.evAmp(e.id)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Switch(Haptics.evOn(e.id), { Store.setB("hapE_${e.id}_on", it) })
            Spacer(Modifier.width(6.dp))
            Column(Modifier.weight(1f)) { SSlider(e.label, "hapE_${e.id}_amp", Haptics.defAmp(e.id), 100, "%") }
            Btn("▶") { Haptics.test(e.id) }
        }
    }
    if (!compact) {
        SToggle("Footsteps (experimental)", "hapSteps", false, "A tick for each step; pace follows running speed (faster with speed shoes). Works on Sonic 1/2 profiles only.")
        SSlider("Footstep calibration (match the sprite's steps)", "hapStepCal", 100, 200, "%")
        H("What works where")
        Text("• Mega Drive: Sonic 1, 2 (full), 3 & Knuckles (rings/lives; advanced events are experimental), ROM hacks (best effort).\n• Sega CD, 32X, GBA, Master System, Game Gear: touch-button vibration only.\n• Ring bite/drain: any game whose ring counter drops in small steps (for example robotic piranhas that steal rings).\n• The app reads the game's memory, it can't know about events in unknown games. Wrong addresses can cause odd buzzing: switch the event off or the game's profile to Off in ✎ EDIT.", color = Color(0xCCFFFFFF), fontSize = 11.sp)
    }
}
