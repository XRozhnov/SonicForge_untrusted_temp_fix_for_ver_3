package com.sonicforge

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.sonicforge.audio.Music
import com.sonicforge.audio.MusicService
import com.sonicforge.data.Store

/** Quick Settings tiles (pull down the notification shade, tap the pencil, drag a tile in). Four tiles: launcher, music, last game, characters. */
abstract class BaseTile : TileService() {
    abstract fun target(): Intent
    override fun onStartListening() { qsTile?.apply { state = Tile.STATE_INACTIVE; updateTile() } }
    override fun onClick() { open(target()) }
    @SuppressLint("StartActivityAndCollapseDeprecated")
    protected fun open(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        else @Suppress("DEPRECATION") startActivityAndCollapse(i)
    }
}

/** just opens the launcher */
class LauncherTile : BaseTile() { override fun target() = Intent(this, MainActivity::class.java) }

/** starts the last game you played (or opens the GAMES tab if none yet) */
class GameTile : BaseTile() {
    override fun target(): Intent { val id = Store.s("lastGame"); return Intent(this, MainActivity::class.java).apply { if (id.isNotEmpty()) putExtra("play", id) else putExtra("tab", "games") } }
}

/** opens the HELP tab where the characters answer questions */
class CharacterTile : BaseTile() { override fun target() = Intent(this, MainActivity::class.java).putExtra("tab", "help") }

/** play / pause the launcher music without opening the app */
class MusicTile : TileService() {
    override fun onStartListening() = refresh()
    override fun onClick() {
        try { Music.toggle(); if (Music.playing) MusicService.ensure(applicationContext) } catch (_: Throwable) {}
        refresh()
    }
    private fun refresh() { qsTile?.apply { state = if (Music.playing) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE; label = if (Music.playing) "Music: pause" else "Music: play"; updateTile() } }
}
