package com.sonicforge.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.sin
import kotlin.random.Random

val FX_KINDS = listOf("off" to "Off", "boulders" to "Boulders", "rings" to "Rings", "snow" to "Snowflakes", "embers" to "Embers", "bubbles" to "Bubbles", "custom" to "My PNG")

/** Spinning/falling objects drawn BEHIND the game (or over it if you choose). kind: boulders | rings | snow | embers | bubbles | custom (your own PNG). */
@Composable
fun FxLayer(kind: String, bmp: ImageBitmap? = null, modifier: Modifier = Modifier) {
    if (kind == "off" || kind.isEmpty() || (kind == "custom" && bmp == null)) return
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { while (true) withFrameNanos { t = it / 1e9f } }
    val seeds = remember { List(16) { floatArrayOf(Random.nextFloat(), Random.nextFloat(), .5f + Random.nextFloat()) } }
    Canvas(modifier.fillMaxSize()) {
        val rise = kind == "embers" || kind == "bubbles"
        seeds.forEach { s ->
            val sz = size.height * (.03f + .035f * s[2])
            val y = if (rise) size.height - ((s[1] + t * .07f * s[2]) % 1.1f) * size.height else ((s[1] + t * .08f * s[2]) % 1.1f) * size.height - sz
            val x = ((s[0] + sin(t * .6f * s[2] + s[1] * 6f) * .04f + 1f) % 1f) * size.width
            val c = Offset(x, y)
            rotate(t * 60f * s[2] * (if (s[0] > .5f) 1f else -1f), c) {
                when (kind) {
                    "boulders" -> { drawCircle(Color(0xFF7A7A7A), sz, c); drawCircle(Color(0xFF555555), sz * .45f, c + Offset(-sz * .3f, -sz * .25f)); drawCircle(Color(0xFF9E9E9E), sz * .2f, c + Offset(sz * .3f, sz * .3f)) }
                    "rings" -> drawCircle(Color(0xFFFFD54F), sz * .7f, c, style = Stroke(sz * .2f))
                    "snow" -> { drawCircle(Color(0xDDFFFFFF), sz * .35f, c); drawLine(Color(0xDDFFFFFF), c - Offset(sz * .8f, 0f), c + Offset(sz * .8f, 0f), 3f); drawLine(Color(0xDDFFFFFF), c - Offset(0f, sz * .8f), c + Offset(0f, sz * .8f), 3f) }
                    "embers" -> drawCircle(Color(0xCCFF9800), sz * .3f, c)
                    "bubbles" -> drawCircle(Color(0x9980DEEA), sz * .8f, c, style = Stroke(3f))
                    "custom" -> bmp?.let { drawImage(it, dstOffset = IntOffset((x - sz).toInt(), (y - sz).toInt()), dstSize = IntSize((sz * 2).toInt(), (sz * 2).toInt())) }
                }
            }
        }
    }
}
