package com.sonicforge.data

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.mutableStateListOf
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

/** A game in the launcher. sys: md (Mega Drive/Genesis), sms, gg, scd (Sega CD), bor (OpenBOR pak). */
data class Rom(
    val id: String, val title: String, val file: String, val desc: String = "", val scene: String = "classic",
    val rings: Int = -1, val lives: Int = -1,
    val bg: String? = null, val logo: String? = null,
    val sys: String = "md",
    val shader: String = "", val slot: Int = 0, val skin: String = "", val track: String = "",
    val cBody: Int = 0, val cSky: Int = 0, val cGround: Int = 0,
    val cheats: String = "",
    val profile: String = "auto",                         // RAM profile for vibration events: auto | s1 | s2 | s3k | generic | off
    val group: String = "", val variant: String = ""      // e.g. group "Sonic 2", variant "French translation"
)

object Library {
    val roms = mutableStateListOf<Rom>()
    lateinit var dir: File; lateinit var art: File; lateinit var system: File
    private val main = Handler(Looper.getMainLooper())
    private fun toast(ctx: Context, t: String) { Logger.notice(t, !t.lowercase().let { it.contains("could not") || it.contains("no new") || it.contains("failed") || it.contains("no sega") }); main.post { Toast.makeText(ctx, t, Toast.LENGTH_LONG).show() } }

    private data class Known(val key: String, val title: String, val scene: String, val profile: String, val desc: String)
    private val known = listOf(
        Known("knuckles", "Sonic 3 & Knuckles", "classic", "s3k", "The full lock-on saga: Angel Island to the Doomsday Zone, with Sonic, Tails and Knuckles."),
        Known("sonic_cd", "Sonic CD", "classic", "off", "Time travel to Little Planet, race Metal Sonic and rescue Amy."),
        Known("metal_sonic", "Metal Sonic Rebooted", "metal", "s1", "A fan hack that lets you play as the chrome menace himself."),
        Known("sboom", "Sonic Boom (hack)", "boom", "s1", "Sonic 1 reimagined with a Boom-style twist: run, don't get caught by the fire."),
        Known("shadow", "Shadow in Sonic 1", "shadow", "s1", "Chaos Control meets Green Hill: play Sonic 1 as Shadow."),
        Known("amy", "Amy Rose in Sonic 1", "amy", "s1", "Amy swings her hammer through the original Sonic 1 zones."),
        Known("xl", "Sonic 2 XL", "classic", "s2", "An expanded Sonic 2 with extra content and a bigger adventure."),
        Known("score", "Score Rush", "score", "auto", "Score-attack hack: chain tricks and rings for the highest total."),
        Known("heroes", "Sonic Classic Heroes", "heroes", "s3k", "Team up with Sonic, Tails and Knuckles in a classic-style team game."),
        Known("exe", "Sonic.exe (hack)", "exe", "s1", "A spooky horror-themed romhack. Play at your own risk."),
        Known("hedgehog_2", "Sonic the Hedgehog 2", "classic", "s2", "Meet Tails, spin-dash through Emerald Hill and take on Dr. Robotnik."),
        Known("hedgehog_usa", "Sonic the Hedgehog", "classic", "s1", "Where it all started: Green Hill, Marble, Spring Yard and a speedy blue hero."),
    )

    fun init(ctx: Context) {
        dir = File(ctx.filesDir, "roms").apply { mkdirs() }; art = File(ctx.filesDir, "art").apply { mkdirs() }; system = File(ctx.filesDir, "system").apply { mkdirs() }
        roms.clear()
        Store.read("library.json")?.let { t ->
            try { val a = JSONArray(t); for (i in 0 until a.length()) { val o = a.getJSONObject(i)
                roms.add(Rom(o.getString("id"), o.getString("title"), o.getString("file"), o.optString("desc"), o.optString("scene", "classic"),
                    o.optInt("rings", -1), o.optInt("lives", -1), o.optString("bg").ifEmpty { null }, o.optString("logo").ifEmpty { null },
                    o.optString("sys", "md"), o.optString("shader"), o.optInt("slot", 0), o.optString("skin"), o.optString("track"),
                    o.optInt("cBody", 0), o.optInt("cSky", 0), o.optInt("cGround", 0), o.optString("cheats"), o.optString("profile", "auto"), o.optString("group"), o.optString("variant"))) } } catch (e: Exception) { Logger.e("Library", "load failed", e) }
        }
    }
    fun save() {
        val a = JSONArray(); roms.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("file", it.file).put("desc", it.desc).put("scene", it.scene)
            .put("rings", it.rings).put("lives", it.lives).put("bg", it.bg ?: "").put("logo", it.logo ?: "").put("sys", it.sys).put("shader", it.shader)
            .put("slot", it.slot).put("skin", it.skin).put("track", it.track).put("cBody", it.cBody).put("cSky", it.cSky).put("cGround", it.cGround)
            .put("cheats", it.cheats).put("profile", it.profile).put("group", it.group).put("variant", it.variant)) }
        Store.events.tryEmit(SaveEvent("Library saved", Store.writeVerified("library.json", a.toString())))
    }
    fun update(r: Rom) { val i = roms.indexOfFirst { it.id == r.id }; if (i >= 0) { roms[i] = r; save() } }
    /** change the order of games in the list */
    fun move(id: String, delta: Int) { val i = roms.indexOfFirst { it.id == id }; val j = i + delta; if (i < 0 || j !in roms.indices) return; val t = roms[i]; roms[i] = roms[j]; roms[j] = t; save() }
    fun remove(r: Rom) { if ('/' in r.file) File(dir, r.file).parentFile?.deleteRecursively() else File(dir, r.file).delete(); roms.removeAll { it.id == r.id }; save() }

    fun displayName(ctx: Context, u: Uri): String =
        try { ctx.contentResolver.query(u, null, null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } } catch (_: Exception) { null } ?: "rom.bin"

    /** Import ROMs / archives. Picking a .cue together with its .bin files imports one Sega CD game. Runs in the background. */
    fun importUris(ctx: Context, uris: List<Uri>) = thread {
        ctx0 = ctx.applicationContext
        val named = uris.map { it to displayName(ctx, it) }
        var added = 0
        try {
            val groups = if (named.any { it.second.lowercase().endsWith(".cue") }) listOf(named) else named.map { listOf(it) }
            for (g in groups) added += importGroup(ctx, g)
        } finally { Archives.cleanup(ctx) }
        if (added > 0) { save(); toast(ctx, "Added $added game(s)") } else toast(ctx, "No new games found")
    }

    private fun importGroup(ctx: Context, items: List<Pair<Uri, String>>): Int {
        val label = items.first().second
        val ex = try { Archives.extractAll(ctx, items) } catch (e: Throwable) {
            Logger.e("Import", "extract failed for $label", e)
            toast(ctx, "Could not open $label" + if (label.lowercase().endsWith(".rar")) " (RAR5/encrypted isn't supported: re-pack as .zip or .7z)" else ""); return 0 }
        fun ext(f: File) = f.extension.lowercase()
        val cd = ex.files.firstOrNull { ext(it) == "cue" } ?: ex.files.firstOrNull { ext(it) == "chd" } ?: ex.files.firstOrNull { ext(it) == "iso" }
        if (cd != null) return importCd(ctx, ex, cd, label)
        var n = 0
        for (f in ex.files) when (ext(f)) {
            in Archives.romExts -> if (addRom(f.name, label, "md") { out -> f.inputStream().use { it.copyTo(out) } }) n++
            "pak" -> if (addRom(f.name, label, "bor") { out -> f.inputStream().use { it.copyTo(out) } }) n++
        }
        Logger.i("Import", "$label -> $n game(s)")
        return n
    }

    private fun idFrom(name: String) = name.substringBeforeLast('.').lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(48).ifEmpty { "game" + roms.size }

    private fun importCd(ctx: Context, ex: Archives.Extracted, cue: File, label: String): Int {
        val id = idFrom(cue.name)
        val had = roms.firstOrNull { it.id == id }
        if (had != null && File(dir, had.file).exists()) return 0
        val d = File(dir, id).apply { mkdirs() }
        for (f in ex.files) { val t = File(d, f.name); if (!f.renameTo(t)) { f.copyTo(t, true); f.delete() } }
        if (had != null) { Logger.i("Import", "repaired Sega CD files of ${had.title}"); return 1 }
        val k = known.firstOrNull { (label + cue.name).lowercase().replace(Regex("[^a-z0-9]+"), "_").contains(it.key) }
        roms.add(Rom(id, k?.title ?: cue.nameWithoutExtension, "$id/${cue.name}", k?.desc ?: "Sega CD game. Needs your Sega CD BIOS (LOCATIONS tab).", k?.scene ?: "classic", sys = "scd", profile = "off"))
        Logger.i("Import", "Sega CD image added: $id")
        return 1
    }

    private var ctx0: Context? = null
    private fun addRom(fileName: String, archiveName: String, sys0: String, write: (java.io.OutputStream) -> Unit): Boolean {
        val id = idFrom(fileName)
        val ext0 = fileName.substringAfterLast('.', "").lowercase()
        val stored = if (sys0 == "bor") "$id.pak" else "$id.${ext0.ifEmpty { "bin" }}"   // the core detects the system by this extension
        val existing = roms.firstOrNull { it.id == id }
        if (existing != null) {   // already in the library: only repair it when its file is missing or empty
            val ef = File(dir, existing.file)
            if (ef.exists() && ef.length() > 0) return false
            return try { ef.parentFile?.mkdirs(); ef.outputStream().use(write); Logger.i("Import", "repaired the missing file of ${existing.title}"); ef.length() > 0 } catch (e: Exception) { Logger.e("Import", "could not repair ${existing.title}", e); false }
        }
        val outFile = File(dir, stored)
        try { outFile.parentFile?.mkdirs(); outFile.outputStream().use(write) } catch (e: Exception) { Logger.e("Import", "could not write $fileName", e); ctx0?.let { toast(it, "Could not save $fileName: " + (e.message ?: "unknown error")) }; return false }
        if (outFile.length() == 0L) { Logger.e("Import", "$fileName was copied as an empty file"); outFile.delete(); return false }
        val probe = (archiveName + " " + fileName).lowercase().replace(Regex("[^a-z0-9]+"), "_")
        val k = if (sys0 == "bor" || ext0 in setOf("gba", "gb", "gbc", "32x", "swf")) null else known.firstOrNull { probe.contains(it.key) }
        val sys = when { sys0 == "bor" -> "bor"; ext0 == "sms" -> "sms"; ext0 == "gg" -> "gg"; ext0 == "32x" -> "x32"; ext0 == "gba" -> "gba"; ext0 == "gb" || ext0 == "gbc" -> "gb"; ext0 == "swf" -> "flash"; else -> "md" }
        var profile = k?.profile ?: "auto"
        if (k?.key == "score") profile = if (probe.contains("sonic_2")) "s2" else "s1"
        val base = fileName.substringBeforeLast('.').replace('_', ' ').trim()
        roms.add(Rom(id, k?.title ?: base, stored,
            if (sys == "bor") "OpenBOR game (.pak). Launched through the OpenBOR app, see the OpenBOR tab." else k?.desc ?: if (ext0 == "swf") "Flash game or movie (experimental, plays through Ruffle)." else if (ext0 == "32x") "Sega 32X game (experimental PicoDrive core)." else if (ext0 == "gba" || ext0 == "gb" || ext0 == "gbc") "Game Boy family game (experimental mGBA core)." else "Custom ROM. Tap EDIT to add a description, scene, cheats and more.",
            k?.scene ?: "classic", if (k != null) 0xFE20 else -1, if (k != null) 0xFE12 else -1, sys = sys, profile = profile))
        return true
    }

    /** Sega CD BIOS: pick single files or a zip/7z/rar full of them. Each dump is recognised by its content (the region letter in its header) and stored under the exact name the core wants. */
    fun addBios(ctx: Context, uris: List<Uri>) = thread {
        val found = mutableListOf<String>()
        try {
            val ex = Archives.extractAll(ctx, uris.map { it to displayName(ctx, it) })
            for (f in ex.files) {
                val n = f.length()
                if (n < 0x10000 || n > 0x100000) { Logger.i("BIOS", "skipped ${f.name}: $n bytes is not a Sega CD BIOS size"); continue }
                val region = biosRegion(f)
                if (region == null) { Logger.i("BIOS", "skipped ${f.name}: no Sega header found"); continue }
                val target = File(system, "bios_CD_$region.bin")
                f.copyTo(target, true)
                found.add("$region (${f.name})"); Logger.i("BIOS", "${f.name} -> ${target.name} ($n bytes)")
            }
        } catch (e: Throwable) { Logger.e("BIOS", "BIOS import failed", e) } finally { Archives.cleanup(ctx) }
        val have = listOf("U", "E", "J").filter { File(system, "bios_CD_$it.bin").exists() }
        toast(ctx, if (found.isEmpty()) "No Sega CD BIOS recognised. A BIOS is a 128 KB dump; you can pick a zip that holds several." else "BIOS added: " + found.joinToString(", ") + ". Installed now: " + have.joinToString("/"))
    }
    private fun biosRegion(f: File): String? {
        val head = try { f.inputStream().use { i -> ByteArray(0x200).also { i.read(it) } } } catch (_: Exception) { return null }
        val txt = String(head, Charsets.ISO_8859_1)
        val isSega = txt.regionMatches(0x100, "SEGA", 0, 4)
        val c = txt[0x1F0]
        if (isSega && c in "UEJ") return c.toString()
        val low = f.name.lowercase()
        return when {
            Regex("usa|america|genesis|_u[._]|\\bus\\b").containsMatchIn(low) -> "U"
            Regex("eur|pal|_e[._]").containsMatchIn(low) -> "E"
            Regex("jap|_j[._]|\\bjp\\b").containsMatchIn(low) -> "J"
            else -> if (isSega) "U" else null
        }
    }

    // ---- linked ROM folder (Storage Access Framework tree; permission persists, no storage permission needed)
    fun linkFolder(ctx: Context, uri: Uri) {
        try { ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        Store.set("romFolder", uri.toString()); scanFolder(ctx)
    }
    fun scanFolder(ctx: Context) {
        val u = Store.s("romFolder"); if (u.isEmpty()) return
        thread {
            val root = try { DocumentFile.fromTreeUri(ctx, Uri.parse(u)) } catch (_: Exception) { null } ?: run { toast(ctx, "Folder not accessible. Link it again."); return@thread }
            val byDir = LinkedHashMap<String, MutableList<DocumentFile>>()
            fun walk(d: DocumentFile, depth: Int, path: String) { d.listFiles().forEach { if (it.isDirectory) { if (depth < 3) walk(it, depth + 1, path + "/" + it.name) } else byDir.getOrPut(path) { mutableListOf() }.add(it) } }
            walk(root, 0, "")
            val seen = Store.s("scanned").split('\n').toMutableSet(); var added = 0
            try {
                for ((_, files) in byDir) {
                    fun ex(f: DocumentFile) = (f.name ?: "").substringAfterLast('.', "").lowercase()
                    val cue = files.firstOrNull { ex(it) == "cue" }
                    val groups: List<List<DocumentFile>> = if (cue != null) listOf(files.filter { ex(it) in setOf("cue", "bin", "wav", "mp3", "ogg", "flac") }) else files.map { listOf(it) }
                    for (g in groups) {
                        val head = g.first(); val n = head.name ?: continue; val key = n + "|" + head.length()
                        if (key in seen) continue
                        if (cue == null && ex(head) !in Archives.romExts && ex(head) !in Archives.archiveExts && ex(head) !in Archives.cdExts && ex(head) != "pak") continue
                        added += importGroup(ctx, g.map { it.uri to (it.name ?: "file") }); seen.add(key)
                    }
                }
            } finally { Archives.cleanup(ctx) }
            Store.set("scanned", seen.joinToString("\n"))
            if (added > 0) save(); toast(ctx, if (added > 0) "Folder scan: added $added game(s)" else "Folder scan: nothing new")
        }
    }

    /** Apply an IPS/BPS patch to an existing game, producing a new library entry. */
    fun applyPatch(ctx: Context, r: Rom, patchUri: Uri) = thread {
        val rom = File(dir, r.file).readBytes()
        val p = try { ctx.contentResolver.openInputStream(patchUri)!!.use { it.readBytes() } } catch (_: Exception) { null }
        val out = p?.let { Patch.apply(rom, it) }
        if (out == null) { toast(ctx, "Not a valid IPS/BPS patch"); return@thread }
        val id = r.id + "_p" + (System.currentTimeMillis() % 100000); val f = "$id.rom"
        File(dir, f).writeBytes(out); roms.add(r.copy(id = id, title = r.title + " (patched)", file = f)); save(); toast(ctx, "Patched copy added to your library")
    }

    fun setArt(ctx: Context, r: Rom, uri: Uri, logo: Boolean) {
        val f = File(art, "${r.id}_${if (logo) "logo" else "bg"}_${System.currentTimeMillis()}.img")
        try { ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } } } catch (_: Exception) { return }
        (if (logo) r.logo else r.bg)?.let { File(it).delete() }
        update(if (logo) r.copy(logo = f.path) else r.copy(bg = f.path))
    }
}
