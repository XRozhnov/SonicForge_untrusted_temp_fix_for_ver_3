package com.sonicforge.core

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import com.sonicforge.data.SaveEvent
import com.sonicforge.data.Store
import java.io.File

/** Saves screenshots to the app's own folder (…/Android/data/com.sonicforge/files/screenshots) and, on Android 10+, to Pictures/SonicForge. */
object Shots {
    fun save(ctx: Context, bmp: Bitmap) {
        val name = "SonicForge_${System.currentTimeMillis()}.png"; var ok = false
        try { val d = ctx.getExternalFilesDir("screenshots")!!.apply { mkdirs() }; File(d, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }; ok = true } catch (_: Exception) {}
        if (Build.VERSION.SDK_INT >= 29) try {
            val v = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/png"); put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SonicForge") }
            ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)?.let { u -> ctx.contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }; ok = true }
        } catch (_: Exception) {}
        Store.events.tryEmit(SaveEvent("Screenshot saved", ok))
    }
}
