package com.sonicforge.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.audio.Sfx
import com.sonicforge.data.SaveEvent
import com.sonicforge.data.Store
import com.sonicforge.input.Haptics
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

fun Modifier.skinBg(s: Skin) = this.background(Brush.verticalGradient(listOf(s.bgTop, s.bgBot)))

fun Modifier.forgeClick(sound: String = "click", onClick: () -> Unit) = this.clickable {
    Sfx.play(sound); Haptics.ui(); onClick()
}

/** Draws the skin's frame on top of the content (solid / dashed / neon / double / pixel). */
fun Modifier.skinBorder(s: Skin) = this.drawWithContent {
    drawContent()
    val w = s.bdWidth.dp.toPx(); val r = CornerRadius(s.radius.dp.toPx())
    when (s.border) {
        "neon" -> { drawRoundRect(s.bdColor.copy(alpha = .25f), cornerRadius = r, style = Stroke(w * 3.2f)); drawRoundRect(s.bdColor, cornerRadius = r, style = Stroke(w)) }
        "dashed" -> drawRoundRect(s.bdColor, cornerRadius = r, style = Stroke(w, pathEffect = PathEffect.dashPathEffect(floatArrayOf(w * 3, w * 2))))
        "double" -> { drawRoundRect(s.bdColor, cornerRadius = r, style = Stroke(w)); val i = w * 2.2f
            drawRoundRect(s.bdColor.copy(alpha = .7f), topLeft = Offset(i, i), size = Size(size.width - 2 * i, size.height - 2 * i), cornerRadius = r, style = Stroke(w * .6f)) }
        "pixel" -> { drawRect(s.bdColor, style = Stroke(w)); drawRect(Color.Black.copy(.55f), topLeft = Offset(w, w), size = Size(size.width - 2 * w, size.height - 2 * w), style = Stroke(w * .5f)) }
        else -> drawRoundRect(s.bdColor, cornerRadius = r, style = Stroke(w))
    }
}

@Composable
fun Particles(kind: String, modifier: Modifier = Modifier) {
    if (kind == "none") return
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { while (true) withFrameNanos { t = it / 1e9f } }
    val seeds = remember { List(36) { floatArrayOf(Random.nextFloat(), Random.nextFloat(), .3f + Random.nextFloat() * .7f) } }
    Canvas(modifier.fillMaxSize()) {
        when (kind) {
            "grid" -> { val hz = size.height * .55f
                for (i in 0..10) { val y = hz + (size.height - hz) * ((i + (t * .4f) % 1f) / 10f).let { it * it }; drawLine(Color(0x3300E5FF), Offset(0f, y), Offset(size.width, y), 2f) }
                for (i in -8..8) drawLine(Color(0x3300E5FF), Offset(size.width / 2 + i * size.width * .02f, hz), Offset(size.width / 2 + i * size.width * .16f, size.height), 2f) }
            else -> seeds.forEach { s ->
                val y = ((s[1] + t * .04f * s[2]) % 1f) * size.height; val x = ((s[0] + sin(t * s[2] + s[1] * 6f) * .03f + 1f) % 1f) * size.width
                when (kind) {
                    "sakura" -> drawCircle(Color(0xAAFFB7C5), 4f + 6f * s[2], Offset(x, y))
                    "rings" -> drawCircle(Color(0x99FFD54F), 5f + 6f * s[2], Offset(x, y), style = Stroke(3f))
                    "snow" -> drawCircle(Color(0xCCFFFFFF), 2f + 4f * s[2], Offset(x, y))
                    "embers" -> drawCircle(Color(0xCCFF9800), 2f + 3f * s[2], Offset(x, size.height - y))
                    "bubbles" -> drawCircle(Color(0x8880DEEA), 6f + 8f * s[2], Offset(x, size.height - y), style = Stroke(2f))
                    else -> drawCircle(Color.White.copy(alpha = .25f + .6f * abs(sin(t * s[2] * 2f + s[0] * 9f))), 1.5f + 2.5f * s[2], Offset(x, y))
                }
            }
        }
    }
}

/** Little floppy-disk sprite that confirms (or refutes) that a save really hit the disk. */
@Composable
fun SaveIndicator(modifier: Modifier = Modifier) {
    var ev by remember { mutableStateOf<SaveEvent?>(null) }
    var stamp by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { Store.events.collect { ev = it; stamp++ } }
    LaunchedEffect(stamp) { delay(1800); ev = null }
    val e = ev ?: return
    val col = if (e.ok) Color(0xFF43A047) else Color(0xFFE53935)
    Row(modifier.background(Color(0xDD101018), RoundedCornerShape(50)).border(1.5.dp, col, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(22.dp)) {
            val w = size.width
            drawRect(Color(0xFF90A4AE), Offset(w * .08f, w * .08f), Size(w * .84f, w * .84f))
            drawRect(Color(0xFFECEFF1), Offset(w * .22f, w * .08f), Size(w * .5f, w * .3f))
            drawRect(Color(0xFF37474F), Offset(w * .22f, w * .55f), Size(w * .56f, w * .37f))
            if (e.ok) { drawLine(col, Offset(w * .28f, w * .24f), Offset(w * .42f, w * .34f), 4f); drawLine(col, Offset(w * .42f, w * .34f), Offset(w * .66f, w * .12f), 4f) }
            else { drawLine(col, Offset(w * .3f, w * .12f), Offset(w * .64f, w * .34f), 4f); drawLine(col, Offset(w * .64f, w * .12f), Offset(w * .3f, w * .34f), 4f) }
        }
        Spacer(Modifier.width(6.dp)); Text((if (e.ok) "✓ " else "✗ ") + e.label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun rememberBitmap(path: String?): ImageBitmap? = remember(path) {
    path?.let { File(it).takeIf { f -> f.exists() } }?.let { f ->
        try { BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap() } catch (_: Exception) { null }
    }
}

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, selected: Boolean = false, color: Color? = null, onClick: () -> Unit) {
    val s = Skins.current(); val c = color ?: s.accent
    val shape = RoundedCornerShape(s.radius.coerceAtMost(14).dp)
    Box(modifier.clip(shape).background(if (selected) c else Color.Black.copy(.4f)).border(1.5.dp, c, shape)
        .forgeClick(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (selected) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = if (I18n.tr(text).length > 16) 11.sp else 13.sp, maxLines = 2, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
fun H(text: String) = Text(text.uppercase(), color = Skins.current().accent, fontWeight = FontWeight.Black, fontSize = 13.sp, letterSpacing = 2.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))

@Composable
fun SSlider(label: String, key: String, def: Int, max: Int = 100, unit: String = "%") {
    val v = Store.i(key, def); var edit by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, modifier = Modifier.weight(1f))
            if (v != def) Text("↺ $def$unit", color = Color(0xFFFFCC80), fontSize = 11.sp, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { Store.setI(key, def); Preview.poke(key); Sfx.play("click") }.padding(horizontal = 8.dp, vertical = 4.dp))
            Text("$v$unit ✎", color = Skins.current().accent, fontWeight = FontWeight.Bold, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { edit = true }.padding(horizontal = 8.dp, vertical = 4.dp))
        }
        Slider(v.toFloat(), { Store.setI(key, it.roundToInt()); Preview.poke(key) }, valueRange = 0f..max.toFloat(), onValueChangeFinished = { Sfx.play("click") })
    }
    if (edit) {
        var t by remember { mutableStateOf(v.toString()) }
        AlertDialog(onDismissRequest = { edit = false },
            confirmButton = { TextButton({ t.toIntOrNull()?.let { Store.setI(key, it.coerceIn(0, max)); Preview.poke(key) }; edit = false }) { Text("OK") } },
            dismissButton = { TextButton({ edit = false }) { Text("Cancel") } },
            title = { Text(label) },
            text = { Column { OutlinedTextField(t, { t = it.filter { c -> c.isDigit() }.take(5) }, singleLine = true, label = { Text("Value (0 to $max$unit)") }); Text("Default: $def$unit. Tap ↺ next to the value to go back to it.", fontSize = 11.sp) } })
    }
}

/** while a margin/size slider moves, the real screen shows the area the picture will use (so you see exactly what changes) */
object Preview { var key by mutableStateOf(""); var stamp by mutableLongStateOf(0L); fun poke(k: String) { if (k.startsWith("scr")) { key = k; stamp = System.currentTimeMillis() } } }
@Composable
fun PreviewOverlay() {
    LaunchedEffect(Preview.stamp) { while (System.currentTimeMillis() - Preview.stamp < 1800) delay(120); Preview.key = "" }
    if (Preview.key.isEmpty()) return
    val accent = Skins.current().accent
    Canvas(Modifier.fillMaxSize()) {
        val d = density
        val l = Store.i("scrLeft", 0) * d; val t = Store.i("scrTop", 0) * d; val r = Store.i("scrRight", 0) * d; val b = Store.i("scrBottom", 0) * d
        val sc = (Store.i("scrScale", 100) / 100f).coerceIn(.5f, 1f); val ox = (Store.i("scrOffX", 50) - 50) / 50f * 60 * d; val oy = (Store.i("scrOffY", 50) - 50) / 50f * 60 * d
        var aw = size.width - l - r; var ah = size.height - t - b
        aw *= sc; ah *= sc
        val x0 = l + (size.width - l - r - aw) / 2 + ox; val y0 = t + (size.height - t - b - ah) / 2 + oy
        val rad = Store.i("scrRadius", 0) * d
        val hole = androidx.compose.ui.graphics.Path().apply { fillType = androidx.compose.ui.graphics.PathFillType.EvenOdd
            addRect(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height)); addRoundRect(androidx.compose.ui.geometry.RoundRect(x0, y0, x0 + aw, y0 + ah, CornerRadius(rad))) }
        drawPath(hole, Color.Black.copy(alpha = .55f))
        drawRoundRect(accent, Offset(x0, y0), Size(aw, ah), CornerRadius(rad), style = Stroke(4f))
        drawContext.canvas.nativeCanvas.drawText("picture area", x0 + 16f, y0 + 36f, android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 34f; isFakeBoldText = true })
    }
}
@Composable
fun SToggle(label: String, key: String, def: Boolean, sub: String? = null) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(label, color = Color.White); if (sub != null) Text(sub, color = Color(0xAAFFFFFF), fontSize = 11.sp) }
        Switch(Store.b(key, def), { Store.setB(key, it); Sfx.play("click"); Haptics.ui() })
    }
}
@Composable
fun SChips(label: String, key: String, def: String, options: List<Pair<String, String>>) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, color = Color.White)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            options.forEach { (v, n) -> Btn(n, selected = Store.s(key, def) == v) { Store.set(key, v) } }
        }
    }
}

/** Volume 0..200 %: slider that snaps to the default (100 %), ±1 buttons and a reset button, so you can always get back to exactly 100. */
@Composable
fun VolSlider(label: String, key: String, def: Int = 100, max: Int = 200) {
    val v = Store.i(key, def)
    fun put(x: Int) = Store.setI(key, x.coerceIn(0, max))
    Column(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Row { Text(label, color = Color.White, modifier = Modifier.weight(1f)); Text("$v%", color = Skins.current().accent, fontWeight = FontWeight.Bold) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Btn("−") { put(v - 1) }
            Slider(v.toFloat(), { x -> var r = x.roundToInt(); if (abs(r - def) <= 3) r = def; put(r) }, valueRange = 0f..max.toFloat(), modifier = Modifier.weight(1f).padding(horizontal = 4.dp))
            Btn("+") { put(v + 1) }
            Spacer(Modifier.width(4.dp)); Btn("↺ $def", selected = v == def) { put(def) }
        }
    }
}
