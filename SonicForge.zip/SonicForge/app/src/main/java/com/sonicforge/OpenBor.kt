package com.sonicforge

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import com.sonicforge.data.Library
import com.sonicforge.data.Logger
import com.sonicforge.data.Rom
import java.io.File

/**
 * OpenBOR runs in its own app. We find an installed OpenBOR, copy the .pak to Downloads/SonicForge-OpenBOR so it can be moved into OpenBOR's Paks folder,
 * and compare the app's CPU type with your phone's (many OpenBOR builds are 32-bit armeabi-v7a only).
 */
object OpenBor {
    fun installed(ctx: Context): Pair<String, String>? {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = pm.queryIntentActivities(i, 0).firstOrNull { (it.loadLabel(pm).toString() + it.activityInfo.packageName).lowercase().contains("openbor") } ?: return null
        return hit.activityInfo.packageName to hit.loadLabel(pm).toString()
    }
    fun abiOf(ctx: Context, pkg: String): String = try {
        val ai = ctx.packageManager.getApplicationInfo(pkg, 0)
        (ai.javaClass.getField("primaryCpuAbi").get(ai) as? String) ?: "unknown"
    } catch (_: Exception) { "unknown" }
    fun report(ctx: Context): String {
        val dev = Build.SUPPORTED_ABIS.joinToString(); val app = installed(ctx)
        if (app == null) return "OpenBOR is not installed. Install an OpenBOR build that matches your phone's CPU. Your phone supports: $dev. (32-bit builds only run on phones that still support 32-bit apps.)"
        val abi = abiOf(ctx, app.first); val ok = abi == "unknown" || Build.SUPPORTED_ABIS.contains(abi)
        return "Found ${app.second} (${app.first}), built for $abi. Your phone supports: $dev. " + if (ok) "They match." else "They do NOT match: use an OpenBOR build for your CPU."
    }
    fun launch(ctx: Context, r: Rom) {
        val exported = export(ctx, r)
        val app = installed(ctx)
        if (app == null) { Toast.makeText(ctx, report(ctx), Toast.LENGTH_LONG).show(); return }
        Toast.makeText(ctx, (if (exported) "PAK copied to Downloads/SonicForge-OpenBOR. Move it into OpenBOR's Paks folder if it isn't listed. " else "") + report(ctx), Toast.LENGTH_LONG).show()
        ctx.packageManager.getLaunchIntentForPackage(app.first)?.let { ctx.startActivity(it) }
    }
    fun export(ctx: Context, r: Rom): Boolean = try {
        val src = File(Library.dir, r.file); val name = (r.title.replace(Regex("[^A-Za-z0-9._ -]"), "_")) + ".pak"
        if (Build.VERSION.SDK_INT >= 29) { val v = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.RELATIVE_PATH, "Download/SonicForge-OpenBOR") }
            ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)?.let { u -> ctx.contentResolver.openOutputStream(u)?.use { o -> src.inputStream().use { it.copyTo(o) } }; true } ?: false }
        else { val d = File(ctx.getExternalFilesDir(null), "openbor").apply { mkdirs() }; src.copyTo(File(d, name), true); true }
    } catch (e: Exception) { Logger.w("OpenBOR", "export failed: $e"); false }
}
