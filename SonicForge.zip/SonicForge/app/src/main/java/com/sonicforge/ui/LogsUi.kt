package com.sonicforge.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.data.Logger
import com.sonicforge.data.Store
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun copy(ctx: Context, t: String) { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("log", t)); Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show() }

private fun saveToFile(ctx: Context, text: String) {
    val name = "sonicforge-log-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt"
    Picker.createText(name) { uri -> try { ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }; Toast.makeText(ctx, "Saved: $name", Toast.LENGTH_LONG).show(); Logger.notice("Log saved to a file: $name") } catch (e: Exception) { Toast.makeText(ctx, "Could not save: ${e.message}", Toast.LENGTH_LONG).show() } }
}

/** Hidden log viewer. PROBLEMS = errors with the app's notes (copy / keep / delete each), NOTICES = every pop-up text in full, CONSOLE = this session, HISTORY = rolling file (FULL mode). */
@Composable
fun LogsDialog(close: () -> Unit) {
    val ctx = LocalContext.current; var tab by remember { mutableStateOf("issues") }; var rf by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val r = rf
    val mode = Store.s("logMode", "errors")
    fun current() = when (tab) { "issues" -> Logger.issuesText(); "notices" -> Logger.noticesText(); "console" -> Logger.text(); else -> Logger.fileTail() }
    AlertDialog(onDismissRequest = close,
        confirmButton = { TextButton(close) { Text("Close") } },
        title = { Text("Logs") },
        text = { Column {
            Text("Recording:", fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { listOf("off" to "OFF", "errors" to "ERRORS ONLY", "full" to "FULL").forEach { (k, n) -> Btn(n, selected = mode == k) { Store.set("logMode", k) } } }
            Text(when (mode) { "off" -> "Nothing is saved to the phone (the current session stays in memory)."; "full" -> "Problems AND a rolling text log are saved."; else -> "Only problems are saved: no emulator chatter." } + " Pop-up messages (notices) are always kept.", fontSize = 10.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Btn("COPY THIS TAB") { copy(ctx, current()) }; Btn("COPY ALL") { copy(ctx, Logger.fullReport()) }; Btn("COPY ERRORS") { copy(ctx, Logger.issuesText()) }
                Btn("SAVE FILE") { saveToFile(ctx, Logger.fullReport()) }
                Btn("SHARE") { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Logger.fullReport().takeLast(100000)), "Share log")) }
                Btn("CLEAR UNPINNED") { Logger.clearUnpinned(); rf++ }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) { listOf("issues" to "PROBLEMS", "notices" to "NOTICES", "console" to "CONSOLE", "file" to "HISTORY").forEach { (k, n) -> Btn(n, selected = tab == k) { tab = k } } }
            if (tab == "issues") {
                val list = Logger.issueList()
                Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState()).padding(top = 6.dp)) {
                    if (list.isEmpty()) Text("No problems recorded. 🎉", fontSize = 12.sp)
                    list.forEach { it ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(.25f)).padding(8.dp)) {
                            Text("${it.time}  ${it.sev} · ${it.src}" + (if (it.pinned) "  📌" else ""), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            if (it.ctx.isNotEmpty()) Text(it.ctx, fontSize = 10.sp)
                            Text(it.msg.take(900) + if (it.msg.length > 900) "\n… (COPY gives the complete text)" else "", fontFamily = FontFamily.Monospace, fontSize = 9.sp, modifier = Modifier.padding(vertical = 3.dp))
                            Text("# SonicForge note: " + it.noteEn, fontSize = 10.sp, color = Color(0xFF80CBC4))
                            if (it.noteLoc != it.noteEn) Text("# " + it.noteLoc, fontSize = 10.sp, color = Color(0xFFFFCC80))
                            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Btn("COPY") { copy(ctx, "[${it.time}] ${it.sev} (${it.src}) ${it.ctx}\n${it.msg}\n# SonicForge note: ${it.noteEn}") }
                                Btn(if (it.pinned) "UNPIN" else "KEEP") { Logger.pin(it.id); rf++ }; Btn("DELETE", color = Color(0xFFE53935)) { Logger.delete(it.id); rf++ } }
                        }
                    }
                }
            } else Text(current().ifEmpty { "(empty)" }.takeLast(12000), fontFamily = FontFamily.Monospace, fontSize = 9.sp, modifier = Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState()).padding(top = 6.dp))
        } })
}
