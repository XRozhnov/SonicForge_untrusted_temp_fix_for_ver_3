package com.sonicforge.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.audio.Sfx
import com.sonicforge.data.Store
import com.sonicforge.input.Haptics
import kotlin.math.abs
import kotlin.math.sin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

private object Mini {
    var paused by mutableStateOf(false); var muted by mutableStateOf(false); var countdown by mutableIntStateOf(0); var hidden by mutableStateOf(false)
    val running get() = !paused && countdown == 0 && !hidden
}
private fun snd(ev: String) { if (!Mini.muted) Sfx.play(ev) }
private fun heroCol(): Color = when (Store.s("mgHero", "sonic")) { "shadow" -> Color(0xFF212121); "amy" -> Color(0xFFF06292); "metal" -> Color(0xFF90A4AE); "tails" -> Color(0xFFFFA000); "knuckles" -> Color(0xFFE53935); else -> Color(0xFF1E88E5) }
private val RULES = mapOf(
    "runner" to "Tap to jump over the spikes and grab rings. One spike hit ends the run. The longer you run, the faster it gets.",
    "fire" to "Fire Chase: a wall of fire chases you! Rings push it back, spikes slow you down and let it catch up. If the fire reaches you it is over.",
    "boulder" to "Tap the left or right half to change lane. Dodge boulders, collect rings. 3 lives.",
    "catcher" to "Drag left and right to catch falling rings. Avoid the bombs. 3 lives.",
    "cafe" to "Speed Cafe: catch the menu items of the real Sonic Speed Cafe pop-up: Sonic's Classic Chili Dog, Knuckles Sandwich, Golden Ring onion rings, Fast Fries, Blue Blur slush, Team Dark milkshake and more (5 to 15 points). Burnt food costs a life. 3 lives.",
    "spin" to "Hold to charge the spin dash and release in the green zone. 5 rounds, best total wins.",
    "memory" to "Flip two cards at a time and match the Chaos Emerald pairs. Fewer moves = higher score.",
    "whack" to "Tap the badniks when they pop up. 30 seconds. Each hit is 10 points.",
    "flyer" to "Tap to flap and fly through the gaps. Don't touch the pipes, the ceiling or the floor.",
    "quiz" to "8 quick Sonic questions. 10 points each.",
    "brawl" to "Street Brawl (beat 'em up): enemies come from both sides. Tap the left or right half to punch that way. Chain hits for a combo bonus. If an enemy touches you, you lose a life. 3 lives.")

@Composable private fun FrameLoop(on: Boolean = true, step: (Float) -> Unit) {
    val st by rememberUpdatedState(step)
    LaunchedEffect(on) { if (!on) return@LaunchedEffect; var last = 0L
        while (true) withFrameNanos { n -> if (last != 0L && Mini.running) st(((n - last) / 1e9f).coerceAtMost(.05f)); last = n } }
}
private fun submit(id: String, score: Int, lower: Boolean = false) {
    val old = Store.i("hs_$id", if (lower) 99999 else 0)
    if (if (lower) score < old else score > old) Store.setI("hs_$id", score)
}
@Composable private fun Shell(title: String, id: String, score: Int, over: Boolean, lower: Boolean = false, onRestart: () -> Unit, onExit: () -> Unit, body: @Composable () -> Unit) {
    val hs = Store.i("hs_$id", 0)
    var best by remember { mutableStateOf(false) }; var rules by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope(); val skin = Skins.current()
    fun go() { scope.launch { for (n in 3 downTo 1) { Mini.countdown = n; delay(700) }; Mini.countdown = -1; delay(450); Mini.countdown = 0 } }
    LaunchedEffect(Unit) { Mini.paused = false; Mini.hidden = false; go() }
    DisposableEffect(Unit) { onDispose { Mini.countdown = 0; Mini.paused = false; Mini.hidden = false } }
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Btn("◀ BACK") { onExit() }
            Btn(if (Mini.paused) "▶ RESUME" else "⏸ PAUSE") { if (Mini.paused) { Mini.paused = false; go() } else Mini.paused = true }
            Btn(if (Mini.muted) "🔇 SOUND OFF" else "🔊 SOUND ON") { Mini.muted = !Mini.muted }
            Btn("🏆 BEST") { Mini.paused = true; best = true }
            Btn("? RULES") { Mini.paused = true; rules = true }
            Btn(if (Mini.hidden) "SHOW GAME" else "HIDE GAME") { Mini.hidden = !Mini.hidden; if (!Mini.hidden) go() }
        }
        Row { Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1)
            Text("SCORE $score  BEST $hs", color = skin.accent, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
        Box(Modifier.weight(1f).fillMaxWidth().padding(top = 6.dp), Alignment.Center) {
            if (!Mini.hidden) body() else Text("Game hidden. Tap SHOW GAME to continue with a 3-2-1.", color = Color(0xAAFFFFFF))
            if (over) Column(Modifier.background(Color(0xCC000000), RoundedCornerShape(14.dp)).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("GAME OVER", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black); Spacer(Modifier.height(10.dp)); Btn("RETRY") { onRestart(); go() } }
            else if (Mini.countdown != 0) Text(if (Mini.countdown > 0) "${Mini.countdown}" else "GO!", color = skin.accent, fontSize = 72.sp, fontWeight = FontWeight.Black)
            else if (Mini.paused && !best && !rules) Column(Modifier.background(Color(0xCC000000), RoundedCornerShape(14.dp)).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("PAUSED", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black); Spacer(Modifier.height(10.dp)); Btn("▶ RESUME") { Mini.paused = false; go() } }
            if (best || rules) Column(Modifier.background(Color(0xEE15151C), RoundedCornerShape(14.dp)).padding(18.dp).widthIn(max = 380.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (best) { Text("🏆 BEST SCORE", color = skin.accent, fontWeight = FontWeight.Black); Text("$hs", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Black); Text("Current: $score", color = Color.White) }
                else { Text("RULES", color = skin.accent, fontWeight = FontWeight.Black); Text(RULES[id] ?: "Have fun!", color = Color.White, modifier = Modifier.padding(vertical = 8.dp)) }
                Btn("CLOSE & CONTINUE") { best = false; rules = false; Mini.paused = false; go() } }
        }
    }
}

private val gameList = listOf(
    Triple("runner", "Ring Runner", "Tap to jump spikes, grab rings. Endless."),
    Triple("fire", "Fire Chase", "Sonic Boom style: outrun the wall of fire!"),
    Triple("boulder", "Boulder Dodge", "Tap left/right to switch lanes. Boulders fall!"),
    Triple("catcher", "Ring Catcher", "Drag to catch rings. Avoid bombs."),
    Triple("spin", "Spin Dash Charge", "Hold, release in the green zone. 5 rounds."),
    Triple("memory", "Emerald Memory", "Match the Chaos Emerald pairs. Fewest moves wins."),
    Triple("whack", "Badnik Bash", "Tap the badniks as they pop up. 30 seconds."),
    Triple("flyer", "Tails Flyer", "Tap to flap through the gaps. How far can you fly?"),
    Triple("quiz", "Zone Trivia", "8 quick Sonic questions. Perfect score = 80."),
    Triple("cafe", "Speed Cafe", "Catch chili dogs, blue drinks and onion rings."),
    Triple("brawl", "Street Brawl", "Beat 'em up: punch the enemies from both sides."),
)

@Composable
fun MiniGamesScreen() {
    var open by remember { mutableStateOf<String?>(null) }
    val exit = { open = null }
    when (open) {
        "runner" -> RingRunner(exit); "boulder" -> BoulderDodge(exit); "catcher" -> RingCatcher(exit)
        "spin" -> SpinDash(exit); "memory" -> EmeraldMemory(exit); "whack" -> BadnikBash(exit); "flyer" -> TailsFlyer(exit); "quiz" -> ZoneTrivia(exit); "fire" -> FireChase(exit); "cafe" -> SpeedCafe(exit); "brawl" -> StreetBrawl(exit)
        else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val skin = Skins.current()
            Text("MINI-GAMES", color = skin.accent, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("Hero", color = Color.White, fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("sonic" to "Sonic", "shadow" to "Shadow", "amy" to "Amy", "metal" to "Metal", "tails" to "Tails", "knuckles" to "Knuckles").forEach { (k, n) -> Btn(n, selected = Store.s("mgHero", "sonic") == k) { Store.set("mgHero", k) } } }
            gameList.forEach { (id, name, desc) ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(.4f)).forgeClick("confirm") { open = id }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text(desc, color = Color(0xBBFFFFFF), fontSize = 12.sp) }
                    Text("BEST ${Store.i("hs_$id", 0)}", color = skin.accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

// ---------- 1. Ring Runner ----------
private class RR { var y = 0f; var vy = 0f; val spikes = mutableListOf<Float>(); val rings = mutableListOf<Offset>(); var dist = 0f; var rg = 0; var over = false; var sp = 0f; var t = 0f }
@Composable private fun RingRunner(exit: () -> Unit) {
    var s by remember { mutableStateOf(RR()) }; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val tk = tick
    FrameLoop(!s.over) { dt -> val g = s; g.t += dt
        val speed = 320f + minOf(g.dist / 12f, 320f); g.dist += speed * dt
        g.vy -= 1900f * dt; g.y += g.vy * dt; if (g.y <= 0f) { g.y = 0f; g.vy = 0f }
        g.sp -= dt; if (g.sp <= 0f) { g.spikes.add(900f); if (Random.nextFloat() < .7f) g.rings.add(Offset(1000f + Random.nextFloat() * 200f, 40f + Random.nextFloat() * 110f)); g.sp = .85f + Random.nextFloat() * .7f - (speed - 320f) / 1000f }
        for (i in g.spikes.indices) g.spikes[i] -= speed * dt
        for (i in g.rings.indices) g.rings[i] = Offset(g.rings[i].x - speed * dt, g.rings[i].y)
        g.spikes.removeAll { it < -60f }; g.rings.removeAll { it.x < -40f }
        if (g.rings.removeAll { abs(it.x - 130f) < 42f && abs(it.y - (g.y + 20f)) < 54f }) { g.rg++; snd("click") }
        if (g.spikes.any { it > 105f && it < 155f } && g.y < 34f) { g.over = true; Haptics.gameEvent("hurt"); snd("error"); submit("runner", g.rg * 10 + (g.dist / 50).toInt()) }
        tick++ }
    Shell("Ring Runner", "runner", s.rg * 10 + (s.dist / 50).toInt(), s.over, onRestart = { s = RR() }, onExit = exit) {
        Canvas(Modifier.aspectRatio(2f).clip(RoundedCornerShape(10.dp)).pointerInput(s) { detectTapGestures { if (s.y <= 0f) { s.vy = 760f; Haptics.ui() } } }) {
            tick.let { }; scale(size.width / 800f, size.width / 800f, Offset.Zero) {
                drawRect(Color(0xFF81D4FA), Offset.Zero, Size(800f, 400f)); drawRect(Color(0xFF558B2F), Offset(0f, 320f), Size(800f, 80f))
                s.spikes.forEach { x -> drawPath(androidx.compose.ui.graphics.Path().apply { moveTo(x, 320f); lineTo(x + 20f, 275f); lineTo(x + 40f, 320f); close() }, Color(0xFFB0BEC5)) }
                s.rings.forEach { drawCircle(Color(0xFFFFD54F), 12f, Offset(it.x, 320f - it.y), style = Stroke(5f)) }
                drawCircle(heroCol(), 20f, Offset(130f, 300f - s.y)); drawCircle(Color(0xFFFFE0B2), 9f, Offset(136f, 303f - s.y))
            } }
    }
}

// ---------- 2. Boulder Dodge ----------
private class BD { var lane = 2; val boulders = mutableListOf<FloatArray>(); val rings = mutableListOf<FloatArray>(); var lives = 3; var score = 0; var over = false; var sp = 0f; var t = 0f }
@Composable private fun BoulderDodge(exit: () -> Unit) {
    var s by remember { mutableStateOf(BD()) }; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val tk = tick
    FrameLoop(!s.over) { dt -> val g = s; g.t += dt; g.sp -= dt
        if (g.sp <= 0f) { g.boulders.add(floatArrayOf(Random.nextInt(5).toFloat(), -30f, 220f + g.t * 6f)); if (Random.nextFloat() < .5f) g.rings.add(floatArrayOf(Random.nextInt(5).toFloat(), -30f)); g.sp = (.75f - g.t / 200f).coerceAtLeast(.28f) }
        g.boulders.forEach { it[1] += it[2] * dt }; g.rings.forEach { it[1] += 240f * dt }
        if (g.boulders.removeAll { it[0].toInt() == g.lane && it[1] in 300f..360f }) { g.lives--; Haptics.gameEvent("hurt"); snd("error"); if (g.lives <= 0) { g.over = true; submit("boulder", g.score) } }
        if (g.rings.removeAll { it[0].toInt() == g.lane && it[1] in 300f..370f }) { g.score += 10; snd("click") }
        g.boulders.removeAll { it[1] > 430f }; g.rings.removeAll { it[1] > 430f }; g.score += 0; if (!g.over && (g.t * 10).toInt() % 10 == 0) tick++ ; tick++ }
    Shell("Boulder Dodge   ♥${s.lives}", "boulder", s.score + (s.t * 2).toInt(), s.over, onRestart = { s = BD() }, onExit = exit) {
        Canvas(Modifier.aspectRatio(1.25f).clip(RoundedCornerShape(10.dp)).pointerInput(s) { detectTapGestures { o -> s.lane = (s.lane + if (o.x < size.width / 2) -1 else 1).coerceIn(0, 4) } }) {
            tick.let { }; scale(size.width / 500f, size.width / 500f, Offset.Zero) {
                drawRect(Color(0xFF6D4C41), Offset.Zero, Size(500f, 400f))
                for (i in 0..4) drawRect(Color(0x22000000), Offset(i * 100f + 4f, 0f), Size(92f, 400f))
                s.rings.forEach { drawCircle(Color(0xFFFFD54F), 14f, Offset(it[0] * 100f + 50f, it[1]), style = Stroke(5f)) }
                s.boulders.forEach { drawCircle(Color(0xFF8D8D8D), 30f, Offset(it[0] * 100f + 50f, it[1])); drawCircle(Color(0xFF616161), 12f, Offset(it[0] * 100f + 40f, it[1] - 8f)) }
                drawCircle(heroCol(), 24f, Offset(s.lane * 100f + 50f, 340f)); drawCircle(Color(0xFFFFE0B2), 10f, Offset(s.lane * 100f + 58f, 344f))
            } }
    }
}

// ---------- 3. Ring Catcher ----------
private class RC { var x = .5f; val items = mutableListOf<FloatArray>(); var score = 0; var lives = 3; var over = false; var sp = 0f; var t = 0f }
@Composable private fun RingCatcher(exit: () -> Unit) {
    var s by remember { mutableStateOf(RC()) }; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val tk = tick
    FrameLoop(!s.over) { dt -> val g = s; g.t += dt; g.sp -= dt
        if (g.sp <= 0f) { g.items.add(floatArrayOf(Random.nextFloat(), -20f, if (Random.nextFloat() < .22f) 1f else 0f)); g.sp = (.7f - g.t / 150f).coerceAtLeast(.3f) }
        g.items.forEach { it[1] += (200f + g.t * 4f) * dt }
        val caught = g.items.filter { it[1] in 330f..380f && abs(it[0] - g.x) < .09f }
        caught.forEach { if (it[2] == 0f) { g.score += 10; snd("click") } else { g.lives--; Haptics.gameEvent("hurt"); snd("error"); if (g.lives <= 0) { g.over = true; submit("catcher", g.score) } } }
        g.items.removeAll(caught); g.items.removeAll { it[1] > 420f }; tick++ }
    Shell("Ring Catcher   ♥${s.lives}", "catcher", s.score, s.over, onRestart = { s = RC() }, onExit = exit) {
        Canvas(Modifier.aspectRatio(1.25f).clip(RoundedCornerShape(10.dp)).pointerInput(s) { detectHorizontalDragGestures { c, _ -> s.x = (c.position.x / size.width).coerceIn(0f, 1f) } }
            .pointerInput(s) { detectTapGestures { s.x = (it.x / size.width) } }) {
            tick.let { }; scale(size.width / 500f, size.width / 500f, Offset.Zero) {
                drawRect(Color(0xFF283593), Offset.Zero, Size(500f, 400f))
                s.items.forEach { if (it[2] == 0f) drawCircle(Color(0xFFFFD54F), 14f, Offset(it[0] * 500f, it[1]), style = Stroke(5f)) else { drawCircle(Color(0xFF212121), 16f, Offset(it[0] * 500f, it[1])); drawCircle(Color.Red, 5f, Offset(it[0] * 500f, it[1])) } }
                drawCircle(heroCol(), 24f, Offset(s.x * 500f, 360f)); drawRect(Color(0xFFE53935), Offset(s.x * 500f - 40f, 380f), Size(80f, 10f))
            } }
    }
}

// ---------- 4. Spin Dash Charge ----------
@Composable private fun SpinDash(exit: () -> Unit) {
    var holding by remember { mutableStateOf(false) }; var m by remember { mutableFloatStateOf(0f) }; var ph by remember { mutableFloatStateOf(0f) }
    var round by remember { mutableIntStateOf(0) }; var total by remember { mutableIntStateOf(0) }; var last by remember { mutableIntStateOf(-1) }
    FrameLoop(holding) { dt -> ph += dt * (1.3f + round * .25f); val p = ph % 2f; m = if (p < 1f) p else 2f - p }
    Shell("Spin Dash Charge  R${(round + 1).coerceAtMost(5)}/5", "spin", total, round >= 5, onRestart = { round = 0; total = 0; last = -1; m = 0f; ph = 0f }, onExit = exit) {
        Column(Modifier.fillMaxWidth().pointerInput(round) { detectTapGestures(onPress = {
            if (round >= 5) return@detectTapGestures
            holding = true; ph = 0f; Haptics.ui(); val ok = tryAwaitRelease(); holding = false
            val pts = (100 - abs(m - .85f) * 220f).toInt().coerceAtLeast(0); last = pts; total += pts; round++; if (round >= 5) submit("spin", total); if (ok) Sfx.play(if (pts > 80) "confirm" else "click") }) },
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("HOLD to charge — release in the green", color = Color.White); Spacer(Modifier.height(14.dp))
            Canvas(Modifier.fillMaxWidth(.8f).height(40.dp)) {
                drawRect(Color(0xFF263238), Offset.Zero, size); drawRect(Color(0xFF43A047), Offset(size.width * .78f, 0f), Size(size.width * .14f, size.height))
                drawRect(Color(0xFFFFD54F), Offset(0f, 0f), Size(size.width * m, size.height), alpha = .8f)
            }
            Spacer(Modifier.height(14.dp)); Text(if (last >= 0) "Last: +$last" else "", color = Skins.current().accent, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(40.dp)); Text("[ press & hold anywhere here ]", color = Color(0x88FFFFFF))
        }
    }
}

// ---------- 5. Emerald Memory ----------
@Composable private fun EmeraldMemory(exit: () -> Unit) {
    val cols = listOf(Color(0xFF69F0AE), Color(0xFF40C4FF), Color(0xFFFF5252), Color(0xFFFFD740), Color(0xFFE040FB), Color(0xFFB0BEC5))
    var cards by remember { mutableStateOf((0..5).flatMap { listOf(it, it) }.shuffled()) }
    var up by remember { mutableStateOf(listOf<Int>()) }; var done by remember { mutableStateOf(setOf<Int>()) }; var moves by remember { mutableIntStateOf(0) }
    val over = done.size == 12
    LaunchedEffect(up) { if (up.size == 2) { kotlinx.coroutines.delay(650); if (cards[up[0]] == cards[up[1]]) { done = done + up; snd("confirm") } else snd("back"); up = emptyList()
        if (done.size == 12) submit("memory", 200 - moves * 10) } }
    Shell("Emerald Memory  moves $moves", "memory", (200 - moves * 10).coerceAtLeast(0).let { if (over) it else 0 }, over, onRestart = { cards = (0..5).flatMap { listOf(it, it) }.shuffled(); up = emptyList(); done = emptySet(); moves = 0 }, onExit = exit) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (r in 0 until 3) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (c in 0 until 4) { val i = r * 4 + c; val shown = i in up || i in done
                    Box(Modifier.size(68.dp).clip(RoundedCornerShape(10.dp)).background(if (shown) cols[cards[i]] else Color(0xFF37474F))
                        .clickable { if (up.size < 2 && i !in up && i !in done) { up = up + i; if (up.size == 2) moves++; snd("click") } }, Alignment.Center) { if (shown) Text("◆", fontSize = 28.sp, color = Color.White) else Text("?", color = Color(0xFF90A4AE), fontSize = 24.sp) } }
            }
        }
    }
}

// ---------- 6. Badnik Bash ----------
private class BB { val life = FloatArray(9); var score = 0; var time = 30f; var sp = 0f; val over get() = time <= 0f }
@Composable private fun BadnikBash(exit: () -> Unit) {
    var s by remember { mutableStateOf(BB()) }; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val tk = tick; var sz by remember { mutableStateOf(IntSize.Zero) }
    FrameLoop(!s.over) { dt -> val g = s; g.time -= dt; g.sp -= dt
        for (i in 0 until 9) if (g.life[i] > 0f) g.life[i] -= dt
        if (g.sp <= 0f) { g.life[Random.nextInt(9)] = .95f; g.sp = .5f }
        if (g.over) submit("whack", g.score); tick++ }
    Shell("Badnik Bash  ${s.time.coerceAtLeast(0f).toInt()}s", "whack", s.score, s.over, onRestart = { s = BB() }, onExit = exit) {
        Canvas(Modifier.aspectRatio(1.25f).clip(RoundedCornerShape(10.dp)).onSizeChanged { sz = it }.pointerInput(s) { detectTapGestures { o ->
            val cw = size.width / 3f; val ch = size.height / 3f; val i = (o.y / ch).toInt().coerceIn(0, 2) * 3 + (o.x / cw).toInt().coerceIn(0, 2)
            if (s.life[i] > 0f) { s.life[i] = 0f; s.score += 10; Haptics.gameTouch(); snd("click") } } }) {
            tick.let { }; drawRect(Color(0xFF558B2F), Offset.Zero, size)
            val cw = size.width / 3f; val ch = size.height / 3f
            for (i in 0 until 9) { val c = Offset((i % 3) * cw + cw / 2, (i / 3) * ch + ch / 2)
                drawOval(Color(0xFF3E2723), Offset(c.x - cw * .3f, c.y), Size(cw * .6f, ch * .3f))
                if (s.life[i] > 0f) { val b = Offset(c.x, c.y - ch * .1f); val r = ch * .22f
                    for (k in 0..6) { val a = Math.PI * (1.0 + k / 6.0); drawLine(Color(0xFFB0BEC5), Offset(b.x + (r * .9f * kotlin.math.cos(a)).toFloat(), b.y + (r * .9f * sin(a)).toFloat()), Offset(b.x + (r * 1.35f * kotlin.math.cos(a)).toFloat(), b.y + (r * 1.35f * sin(a)).toFloat()), 4f) }   // spikes
                    drawLine(Color(0xFFFFB300), Offset(b.x + r * .3f, b.y - r * .7f), Offset(b.x + r * .55f, b.y - r * 1.5f), 4f); drawLine(Color(0xFFFFB300), Offset(b.x + r * .7f, b.y - r * .5f), Offset(b.x + r * 1.0f, b.y - r * 1.3f), 4f)   // two orange antennae
                    drawCircle(Color(0xFFE53935), r, b); drawCircle(Color(0xFF29B6F6), r * .5f, Offset(b.x + r * .55f, b.y + r * .1f))   // red body, small blue face
                    drawCircle(Color.White, r * .22f, Offset(b.x + r * .25f, b.y - r * .15f)); drawCircle(Color.Black, r * .1f, Offset(b.x + r * .3f, b.y - r * .15f)) } }
        }
    }
}


// ---------- 7. Tails Flyer ----------
private class TF { var y = 200f; var vy = 0f; val gates = mutableListOf<FloatArray>(); var score = 0; var over = false; var sp = 0f; var t = 0f }
@Composable private fun TailsFlyer(exit: () -> Unit) {
    var s by remember { mutableStateOf(TF()) }; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val tk = tick
    FrameLoop(!s.over) { dt -> val g = s; g.t += dt; g.vy += 1100f * dt; g.y += g.vy * dt; g.sp -= dt
        if (g.sp <= 0f) { g.gates.add(floatArrayOf(560f, 90f + Random.nextFloat() * 220f, 0f)); g.sp = 1.5f }
        g.gates.forEach { it[0] -= (190f + g.t * 3f) * dt }
        g.gates.forEach { if (it[2] == 0f && it[0] < 100f) { it[2] = 1f; g.score++; snd("click") } }
        g.gates.removeAll { it[0] < -60f }
        val hit = g.y < 10f || g.y > 390f || g.gates.any { it[0] in 80f..140f && (g.y < it[1] - 70f || g.y > it[1] + 70f) }
        if (hit) { g.over = true; Haptics.gameEvent("hurt"); snd("error"); submit("flyer", g.score) }
        tick++ }
    Shell("Tails Flyer", "flyer", s.score, s.over, onRestart = { s = TF() }, onExit = exit) {
        Canvas(Modifier.aspectRatio(1.4f).clip(RoundedCornerShape(10.dp)).pointerInput(s) { detectTapGestures { s.vy = -380f; Haptics.ui() } }) {
            tick.let { }; scale(size.width / 560f, size.width / 560f, Offset.Zero) {
                drawRect(Color(0xFF81D4FA), Offset.Zero, Size(560f, 400f))
                s.gates.forEach { drawRect(Color(0xFF2E7D32), Offset(it[0], 0f), Size(46f, it[1] - 70f)); drawRect(Color(0xFF2E7D32), Offset(it[0], it[1] + 70f), Size(46f, 400f)) }
                drawCircle(Color(0xFFFFB300), 18f, Offset(110f, s.y)); drawCircle(Color(0xFFFFE0B2), 8f, Offset(116f, s.y + 2f))
            } }
    }
}

// ---------- 8. Zone Trivia ----------
private val QUIZ = listOf(
    Triple("Who is Sonic's two-tailed sidekick?", listOf("Tails", "Knuckles", "Amy", "Shadow"), 0),
    Triple("What do you collect to survive a hit?", listOf("Coins", "Rings", "Keys", "Stars"), 1),
    Triple("Which zone opens the original Sonic the Hedgehog (1991)?", listOf("Marble Zone", "Casino Night", "Green Hill Zone", "Emerald Hill"), 2),
    Triple("Who is Sonic's main enemy?", listOf("Dr. Eggman", "Metal Knuckles", "Orbot", "Mecha Tails"), 0),
    Triple("How many Chaos Emeralds are in the classic games?", listOf("Five", "Six", "Seven", "Ten"), 2),
    Triple("Which company created Sonic?", listOf("Nintendo", "Sega", "Atari", "Sony"), 1),
    Triple("What colour is Knuckles?", listOf("Red", "Blue", "Yellow", "Green"), 0),
    Triple("What is Sonic's rolling attack from a standstill called?", listOf("Light Dash", "Spin Dash", "Wall Jump", "Boost"), 1),
)
@Composable private fun ZoneTrivia(exit: () -> Unit) {
    var order by remember { mutableStateOf(QUIZ.indices.shuffled()) }; var idx by remember { mutableIntStateOf(0) }; var score by remember { mutableIntStateOf(0) }
    var picked by remember { mutableIntStateOf(-1) }
    val over = idx >= QUIZ.size
    LaunchedEffect(picked) { if (picked >= 0) { kotlinx.coroutines.delay(800); picked = -1; idx++; if (idx >= QUIZ.size) submit("quiz", score) } }
    Shell("Zone Trivia  ${(idx + 1).coerceAtMost(8)}/8", "quiz", score, over, onRestart = { order = QUIZ.indices.shuffled(); idx = 0; score = 0; picked = -1 }, onExit = exit) {
        if (!over) { val q = QUIZ[order[idx]]
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(q.first, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                q.second.forEachIndexed { i, a ->
                    val col = if (picked < 0) Color.Black.copy(.45f) else if (i == q.third) Color(0xFF2E7D32) else if (i == picked) Color(0xFFC62828) else Color.Black.copy(.45f)
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(col).clickable(enabled = picked < 0) { picked = i; if (i == q.third) { score += 10; snd("confirm") } else snd("error") }.padding(14.dp)) { Text(a, color = Color.White) } } } }
    }
}


// ---------- 9. Fire Chase (Sonic Boom style) ----------
private class FC { var y = 0f; var vy = 0f; val spikes = mutableListOf<Float>(); val rings = mutableListOf<Offset>(); var dist = 0f; var rg = 0; var over = false; var sp = 0f; var t = 0f; var fire = -40f }
@Composable private fun FireChase(exit: () -> Unit) {
    var s by remember { mutableStateOf(FC()) }; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val tk = tick
    FrameLoop(!s.over) { dt -> val g = s; g.t += dt
        val speed = 300f + minOf(g.dist / 14f, 240f); g.dist += speed * dt; g.fire += (20f + g.t * 1.4f) * dt
        g.vy -= 1900f * dt; g.y += g.vy * dt; if (g.y <= 0f) { g.y = 0f; g.vy = 0f }
        g.sp -= dt; if (g.sp <= 0f) { g.spikes.add(900f); g.rings.add(Offset(1000f + Random.nextFloat() * 200f, 40f + Random.nextFloat() * 100f)); g.sp = .9f + Random.nextFloat() * .6f }
        for (i in g.spikes.indices) g.spikes[i] -= speed * dt
        for (i in g.rings.indices) g.rings[i] = Offset(g.rings[i].x - speed * dt, g.rings[i].y)
        g.spikes.removeAll { it < -60f }; g.rings.removeAll { it.x < -40f }
        if (g.rings.removeAll { abs(it.x - 170f) < 42f && abs(it.y - (g.y + 20f)) < 54f }) { g.rg++; g.fire -= 22f; snd("click"); Haptics.gameEvent("ring") }
        if (g.spikes.removeAll { it > 140f && it < 200f && g.y < 34f }) { g.fire += 70f; snd("error"); Haptics.gameEvent("hurt") }
        if (g.fire > 130f) { g.over = true; snd("error"); Haptics.gameEvent("death"); submit("fire", g.rg * 10 + (g.dist / 50).toInt()) }
        tick++ }
    Shell("Fire Chase", "fire", s.rg * 10 + (s.dist / 50).toInt(), s.over, onRestart = { s = FC() }, onExit = exit) {
        Canvas(Modifier.aspectRatio(2f).clip(RoundedCornerShape(10.dp)).pointerInput(s) { detectTapGestures { if (s.y <= 0f) { s.vy = 760f; Haptics.ui() } } }) {
            tick.let { }; scale(size.width / 800f, size.width / 800f, Offset.Zero) {
                drawRect(Color(0xFF4E342E), Offset.Zero, Size(800f, 400f)); drawRect(Color(0xFF3E2723), Offset(0f, 320f), Size(800f, 80f))
                s.spikes.forEach { x -> drawPath(androidx.compose.ui.graphics.Path().apply { moveTo(x, 320f); lineTo(x + 20f, 275f); lineTo(x + 40f, 320f); close() }, Color(0xFFB0BEC5)) }
                s.rings.forEach { drawCircle(Color(0xFFFFD54F), 12f, Offset(it.x, 320f - it.y), style = Stroke(5f)) }
                drawCircle(heroCol(), 20f, Offset(170f, 300f - s.y)); drawCircle(Color(0xFFFFE0B2), 9f, Offset(176f, 303f - s.y))
                val fx = s.fire + 40f; drawRect(Color(0xFFFF6D00), Offset(0f, 0f), Size(fx.coerceAtLeast(0f), 400f))
                for (i in 0..8) drawCircle(Color(0xFFFFEB3B), 26f + 8f * sin(s.t * 9f + i), Offset(fx, i * 50f))
            } }
    }
}

// ---------- 10. Speed Cafe: items from the real Sonic the Hedgehog Speed Cafe pop-up (SEGA x Secret Sauce Society, since 2023) ----------
private class Food(val name: String, val pts: Int, val kind: String, val color: Color)
private val CAFE = listOf(
    Food("Sonic's Classic Chili Dog", 10, "dog", Color(0xFFB71C1C)), Food("Knuckles Sandwich", 15, "sandwich", Color(0xFFE53935)),
    Food("Piko Piko Tenders", 10, "tenders", Color(0xFFFFB74D)), Food("Golden Ring Onion Rings", 5, "ring", Color(0xFFFFD54F)),
    Food("Fast Fries", 5, "fries", Color(0xFFFFEE58)), Food("Green Hill Vegan Chili Cup", 10, "cup", Color(0xFF66BB6A)),
    Food("Evil Genius Sandwich", 10, "sandwich", Color(0xFFFFF59D)), Food("Rouge's Kickin' Chicken Sando", 15, "sandwich", Color(0xFFBA68C8)),
    Food("Blue Blur Slush", 15, "drink", Color(0xFF29B6F6)), Food("Smashing Echidna Slush", 15, "drink", Color(0xFFE53935)),
    Food("Flying Fox Slush", 15, "drink", Color(0xFFFFA726)), Food("Team Dark Milkshake", 15, "drink", Color(0xFF6D4C41)),
    Food("Sweet Amy Milkshake", 15, "drink", Color(0xFFF48FB1)), Food("Tails Spin Tea", 10, "drink", Color(0xFFFFCC80)))
private class SC { var x = .5f; val items = mutableListOf<FloatArray>(); var score = 0; var lives = 3; var over = false; var sp = 0f; var t = 0f; var last = "" }
@Composable private fun SpeedCafe(exit: () -> Unit) {
    var s by remember { mutableStateOf(SC()) }; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val tk = tick
    FrameLoop(!s.over) { dt -> val g = s; g.t += dt; g.sp -= dt
        if (g.sp <= 0f) { g.items.add(floatArrayOf(Random.nextFloat(), -20f, if (Random.nextFloat() < .18f) -1f else Random.nextInt(CAFE.size).toFloat())); g.sp = (.75f - g.t / 160f).coerceAtLeast(.32f) }
        g.items.forEach { it[1] += (190f + g.t * 4f) * dt }
        val caught = g.items.filter { it[1] in 330f..385f && abs(it[0] - g.x) < .1f }
        caught.forEach { if (it[2] < 0f) { g.lives--; g.last = "Burnt food!"; snd("error"); Haptics.gameEvent("hurt"); if (g.lives <= 0) { g.over = true; submit("cafe", g.score) } }
            else { val f = CAFE[it[2].toInt()]; g.score += f.pts; g.last = "${f.name} +${f.pts}"; snd(if (f.pts >= 15) "confirm" else "click") } }
        g.items.removeAll(caught); g.items.removeAll { it[1] > 420f }; tick++ }
    Shell("Speed Cafe   ♥${s.lives}", "cafe", s.score, s.over, onRestart = { s = SC() }, onExit = exit) {
        Canvas(Modifier.aspectRatio(1.25f).clip(RoundedCornerShape(10.dp)).pointerInput(s) { detectHorizontalDragGestures { c, _ -> s.x = (c.position.x / size.width).coerceIn(0f, 1f) } }.pointerInput(s) { detectTapGestures { s.x = it.x / size.width } }) {
            tick.let { }; scale(size.width / 500f, size.width / 500f, Offset.Zero) {
                drawRect(Color(0xFF1A237E), Offset.Zero, Size(500f, 400f)); drawRect(Color(0xFF8D6E63), Offset(0f, 392f), Size(500f, 8f))
                s.items.forEach { val c = Offset(it[0] * 500f, it[1])
                    if (it[2] < 0f) { drawCircle(Color(0xFF212121), 14f, c); drawLine(Color(0xFFFF5722), Offset(c.x - 8f, c.y - 8f), Offset(c.x + 8f, c.y + 8f), 3f) }
                    else { val f = CAFE[it[2].toInt()]; when (f.kind) {
                        "dog" -> { drawRoundRect(Color(0xFFE0A96D), Offset(c.x - 22f, c.y - 8f), Size(44f, 18f), androidx.compose.ui.geometry.CornerRadius(9f)); drawRect(f.color, Offset(c.x - 18f, c.y - 4f), Size(36f, 6f)) }
                        "ring" -> drawCircle(f.color, 13f, c, style = Stroke(6f))
                        "fries" -> for (k in -2..2) drawRect(f.color, Offset(c.x + k * 5f - 2f, c.y - 16f - (k * k), ), Size(4f, 26f))
                        "sandwich" -> { drawRoundRect(Color(0xFFE0A96D), Offset(c.x - 18f, c.y - 12f), Size(36f, 8f), androidx.compose.ui.geometry.CornerRadius(4f)); drawRect(f.color, Offset(c.x - 16f, c.y - 4f), Size(32f, 6f)); drawRoundRect(Color(0xFFE0A96D), Offset(c.x - 18f, c.y + 2f), Size(36f, 8f), androidx.compose.ui.geometry.CornerRadius(4f)) }
                        "tenders" -> for (k in 0..1) drawRoundRect(f.color, Offset(c.x - 16f + k * 14f, c.y - 10f + k * 4f), Size(22f, 10f), androidx.compose.ui.geometry.CornerRadius(5f))
                        "cup" -> { drawRoundRect(Color(0xFFECEFF1), Offset(c.x - 12f, c.y - 10f), Size(24f, 20f), androidx.compose.ui.geometry.CornerRadius(4f)); drawRect(f.color, Offset(c.x - 10f, c.y - 10f), Size(20f, 7f)) }
                        else -> { drawRoundRect(f.color, Offset(c.x - 10f, c.y - 16f), Size(20f, 32f), androidx.compose.ui.geometry.CornerRadius(5f)); drawRect(Color(0xFFE1F5FE), Offset(c.x - 8f, c.y - 14f), Size(16f, 5f)) } } } }
                drawCircle(heroCol(), 24f, Offset(s.x * 500f, 360f)); drawRect(Color.White, Offset(s.x * 500f - 40f, 382f), Size(80f, 8f))
                if (s.last.isNotEmpty()) drawContext.canvas.nativeCanvas.drawText(s.last, 12f, 28f, android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 22f; isFakeBoldText = true })
            } }
    }
}

// ---------- 11. Street Brawl (OpenBOR-style beat 'em up) ----------
private class SB { val enemies = mutableListOf<FloatArray>(); var score = 0; var lives = 3; var over = false; var sp = 0f; var t = 0f; var face = 1; var punch = 0f; var combo = 0; var comboT = 0f }
@Composable private fun StreetBrawl(exit: () -> Unit) {
    var s by remember { mutableStateOf(SB()) }; var tick by remember { mutableIntStateOf(0) }; @Suppress("UNUSED_VARIABLE") val tk = tick
    FrameLoop(!s.over) { dt -> val g = s; g.t += dt; g.sp -= dt; g.punch = (g.punch - dt).coerceAtLeast(0f); g.comboT -= dt; if (g.comboT <= 0f) g.combo = 0
        if (g.sp <= 0f) { val side = if (Random.nextBoolean()) 1f else -1f; g.enemies.add(floatArrayOf(side * 330f, side)); g.sp = (1.1f - g.t / 120f).coerceAtLeast(.35f) }
        g.enemies.forEach { it[0] -= it[1] * (60f + g.t * 1.5f) * dt }
        if (g.enemies.removeAll { abs(it[0]) < 30f }) { g.lives--; g.combo = 0; snd("error"); Haptics.gameEvent("hurt"); if (g.lives <= 0) { g.over = true; submit("brawl", g.score) } }
        tick++ }
    Shell("Street Brawl   ♥${s.lives}  combo x${s.combo}", "brawl", s.score, s.over, onRestart = { s = SB() }, onExit = exit) {
        Canvas(Modifier.aspectRatio(2f).clip(RoundedCornerShape(10.dp)).pointerInput(s) { detectTapGestures { o ->
            val dir = if (o.x < size.width / 2) -1 else 1; s.face = dir; s.punch = .15f; Haptics.ui()
            val hit = s.enemies.filter { it[0] * dir > 0f && abs(it[0]) < 110f }
            if (hit.isNotEmpty()) { s.enemies.removeAll(hit); s.combo += hit.size; s.comboT = 1.2f; s.score += hit.size * (10 + 5 * (s.combo - 1).coerceAtMost(6)); snd("confirm"); Haptics.gameEvent("spring") } else s.combo = 0 } }) {
            tick.let { }; scale(size.width / 800f, size.width / 800f, Offset.Zero) {
                drawRect(Color(0xFF37474F), Offset.Zero, Size(800f, 400f)); drawRect(Color(0xFF546E7A), Offset(0f, 300f), Size(800f, 100f))
                for (i in 0..6) drawRect(Color(0xFF263238), Offset(30f + i * 120f, 80f), Size(70f, 120f))
                s.enemies.forEach { drawRect(Color(0xFF6A1B9A), Offset(400f + it[0] * 1.1f - 18f, 250f), Size(36f, 60f)); drawCircle(Color(0xFFFFCC80), 14f, Offset(400f + it[0] * 1.1f, 240f)) }
                drawRect(heroCol(), Offset(382f, 250f), Size(36f, 60f)); drawCircle(Color(0xFFFFCC80), 14f, Offset(400f, 240f))
                if (s.punch > 0f) drawRect(Color(0xFFFFEB3B), Offset(if (s.face > 0) 420f else 340f, 262f), Size(60f, 14f))
            } }
    }
}
