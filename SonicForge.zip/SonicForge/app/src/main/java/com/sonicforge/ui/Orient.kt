package com.sonicforge.ui

import android.content.pm.ActivityInfo

object Orient {
    fun flag(s: String) = when (s) {
        "landscape" -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        "landscape_rev" -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
        "portrait" -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        "portrait_rev" -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT
        else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
    }
    fun flipped(s: String) = when (s) { "landscape" -> "landscape_rev"; "landscape_rev" -> "landscape"; "portrait" -> "portrait_rev"; "portrait_rev" -> "portrait"; else -> "landscape_rev" }
}
