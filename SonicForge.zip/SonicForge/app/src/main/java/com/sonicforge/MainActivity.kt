package com.sonicforge

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.sonicforge.audio.Music
import com.sonicforge.audio.MusicService
import com.sonicforge.data.Rom
import com.sonicforge.data.Store
import com.sonicforge.input.Pads
import com.sonicforge.ui.*

class MainActivity : ComponentActivity() {
    private var pendingDocs: ((List<Uri>) -> Unit)? = null
    private var pendingCreate: ((Uri) -> Unit)? = null
    private var pendingTree: ((Uri) -> Unit)? = null
    private var pendingText: ((Uri) -> Unit)? = null
    private var startTab by mutableStateOf("games")
    private val docs = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { u -> pendingDocs?.invoke(u); pendingDocs = null }
    private val create = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { u -> if (u != null) pendingCreate?.invoke(u); pendingCreate = null }
    private val createText = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { u -> if (u != null) pendingText?.invoke(u); pendingText = null }
    private val tree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> if (u != null) pendingTree?.invoke(u); pendingTree = null }
    private val notif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        Picker.launcher = { mime, cb -> pendingDocs = cb; docs.launch(mime) }
        Picker.creator = { name, cb -> pendingCreate = cb; create.launch(name) }
        Picker.tree = { cb -> pendingTree = cb; tree.launch(null) }
        Picker.textCreator = { name, cb -> pendingText = cb; createText.launch(name) }
        handleIntent(intent)
        if (Build.VERSION.SDK_INT >= 33 && Store.b("musicNotif", true) && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !Store.b("notifAsked", false)) { Store.setB("notifAsked", true); notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
        if (Store.s("crashPending") == "1") { Store.setRaw("crashPending", ""); Toast.makeText(this, "The app closed unexpectedly last time. Details: SETTINGS ▸ ABOUT APP, tap the version 5 times.", Toast.LENGTH_LONG).show() }
        setContent {
            val skin = Skins.current()
            val o = Store.s("orientLauncher", "auto")
            LaunchedEffect(o) { requestedOrientation = Orient.flag(o) }
            val imm = Store.s("immLauncher", "off")
            LaunchedEffect(imm) { applyBars(imm) }
            ForgeTheme(skin) { App(skin, startTab) { rom -> play(rom) } }
        }
    }
    override fun onResume() { super.onResume(); Music.onChange = { if (Music.playing) MusicService.ensure(applicationContext) } }
    private fun applyBars(mode: String) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        when (mode) { "full" -> c.hide(WindowInsetsCompat.Type.systemBars()); "status" -> { c.hide(WindowInsetsCompat.Type.statusBars()); c.show(WindowInsetsCompat.Type.navigationBars()) }
            "nav" -> { c.hide(WindowInsetsCompat.Type.navigationBars()); c.show(WindowInsetsCompat.Type.statusBars()) }; else -> c.show(WindowInsetsCompat.Type.systemBars()) }
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent) }
    /** the quick-settings tiles start the app with extras: "tab" opens a tab, "play" starts a game */
    private fun handleIntent(i: Intent?) {
        i ?: return
        i.getStringExtra("tab")?.let { startTab = it; i.removeExtra("tab") }
        i.getStringExtra("play")?.let { id -> i.removeExtra("play"); com.sonicforge.data.Library.roms.firstOrNull { it.id == id }?.let { r -> window.decorView.post { play(r) } } }
    }
    private fun play(r: Rom) {
        Store.set("lastGame", r.id)
        if (r.sys == "bor") { OpenBor.launch(this, r); return }
        if (r.sys == "flash") { startActivity(Intent(this, FlashActivity::class.java).putExtra("rom", r.id)); return }
        startActivity(Intent(this, GameActivity::class.java).putExtra("rom", r.id))
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) Pads.lastKey = Pads.keyName(e.keyCode)
        val cap = Pads.capture
        if (cap != null && e.action == KeyEvent.ACTION_DOWN && e.keyCode != KeyEvent.KEYCODE_BACK) { cap(e.keyCode); return true }
        return super.dispatchKeyEvent(e)
    }
}

@Composable
private fun App(skin: Skin, startTab: String, onPlay: (Rom) -> Unit) {
    var tab by remember(startTab) { mutableStateOf(startTab) }
    val lbg = rememberBitmap(Store.s("launcherBg").ifEmpty { null })
    LaunchedEffect(Unit) { if (!Store.b("guideSeen", false)) Guide.show = true }
    BackHandler(enabled = Guide.show) { Guide.show = false }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Box(Modifier.fillMaxSize().skinBg(skin)) {
        if (lbg != null) { Image(lbg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop); Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = Store.i("launcherDim", 45) / 100f))) }
        Particles(skin.deco)
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().background(Color.Black.copy(.35f)).horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("SONICFORGE", color = skin.accent, fontWeight = FontWeight.Black, letterSpacing = 3.sp, modifier = Modifier.padding(end = 8.dp))
                listOf("games" to "GAMES", "mini" to "MINI-GAMES", "music" to "MUSIC", "draw" to "DRAW", "custom" to "CUSTOMIZE", "locations" to "LOCATIONS", "settings" to "SETTINGS", "help" to "HELP").forEach { (k, n) -> Btn((if (k == "settings") "⚙ " else "") + com.sonicforge.ui.I18n.tr(n), selected = tab == k) { tab = k } }
            }
            if (tab != "music") MiniPlayerBar()
            Box(Modifier.weight(1f)) {
                when (tab) {
                    "games" -> LauncherScreen(onPlay); "mini" -> MiniGamesScreen(); "music" -> MusicScreen(); "draw" -> DrawScreen(); "custom" -> CustomizeScreen()
                    "locations" -> LocationsScreen(); "help" -> HelpScreen { tab = it }; else -> SettingsScreen()
                }
            }
        }
        SaveIndicator(Modifier.align(Alignment.TopEnd).systemBarsPadding().padding(top = 52.dp, end = 8.dp))
        PreviewOverlay()
        GuideOverlay { tab = it }
    }
}
