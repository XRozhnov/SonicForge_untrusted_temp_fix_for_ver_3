package com.sonicforge.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonicforge.audio.Sfx
import com.sonicforge.core.Shaders
import com.sonicforge.data.Library
import com.sonicforge.data.Factory
import com.sonicforge.data.PadLayout
import com.sonicforge.data.PadLayouts
import com.sonicforge.data.Store
import java.io.File
import kotlin.math.roundToInt

/** Customisation lives in its own tab (not in Settings): skins, frame, shaders, touch-control editor + 6 presets, backgrounds. */
@Composable
fun CustomizeScreen() {
    var tab by remember { mutableStateOf("skins") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("skins" to "SKINS", "frame" to "FRAME & SHADER", "controls" to "CONTROLS", "bg" to "BACKGROUNDS").forEach { (k, n) -> Btn(n, selected = tab == k) { tab = k } }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp)) {
            when (tab) { "skins" -> SkinsTab(); "frame" -> FrameTab(); "controls" -> ControlsTab(); else -> BgTab() }
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable private fun SkinsTab() {
    val cur = Skins.current()
    H("Presets (palette + shader + frame + effects)")
    Skins.all.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { s ->
                Box(Modifier.weight(1f).height(86.dp).clip(RoundedCornerShape(s.radius.coerceAtMost(18).dp)).skinBg(s)
                    .border(if (cur.id == s.id) 4.dp else 1.dp, if (cur.id == s.id) Color.White else s.accent, RoundedCornerShape(s.radius.coerceAtMost(18).dp))
                    .forgeClick("confirm") { Store.set("skin", s.id); listOf("bdStyle", "bdColor", "bdWidth", "bdRadius", "shader").forEach { Store.set(it, "") } }) {
                    Particles(s.deco)
                    Text(s.name, color = s.text, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.BottomStart).padding(10.dp))
                    Box(Modifier.align(Alignment.TopEnd).padding(8.dp).size(14.dp).clip(CircleShape).background(s.accent))
                }
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
    Text("Applies to the launcher, game frame, buttons and the default shader.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
}

@Composable private fun FrameTab() {
    val s = Skins.current()
    H("Game frame")
    Box(Modifier.fillMaxWidth().height(110.dp).padding(8.dp).clip(RoundedCornerShape(s.radius.dp)).skinBorder(s).skinBg(s))
    SChips("Border style", "bdStyle", s.border, Skins.borders.map { it to it.replaceFirstChar { c -> c.uppercase() } })
    Text("Border colour", color = Color.White, modifier = Modifier.padding(top = 6.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Skins.accents.forEach { c -> val col = Color(c.toInt())
            Box(Modifier.size(34.dp).clip(CircleShape).background(col).border(if (s.bdColor == col) 3.dp else 1.dp, Color.White, CircleShape).forgeClick { Store.setI("bdColor", c.toInt()) }) }
    }
    ColorPick("Custom border colour (RGB)", s.bdColor) { Store.setI("bdColor", it.toArgb()) }
    ColorPick("Accent colour (buttons, highlights)", s.accent) { Store.setI("accentC", it.toArgb()) }
    Btn("RESET COLOURS", Modifier.padding(top = 4.dp)) { Store.set("bdColor", ""); Store.set("accentC", "") }
    VSlider("Thickness", s.bdWidth, 0, 14) { Store.setI("bdWidth", it) }
    VSlider("Corner radius", s.radius, 0, 40) { Store.setI("bdRadius", it) }
    H("Shader")
    SChips("Look", "shader", s.shader, Shaders.list.map { it.id to it.name })
    Text("Shaders run on the GPU (OpenGL ES 3). You can also switch them live from the in-game menu.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
    H("Game screen")
    SChips("Aspect", "aspect", "fit", listOf("fit" to "Original ratio", "stretch" to "Stretch"))
    SToggle("Smooth (bilinear) filtering", "smooth", false)
}
@Composable private fun ColorPick(label: String, c: Color, set: (Color) -> Unit) {
    Column(Modifier.padding(top = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(label, color = Color.White, modifier = Modifier.weight(1f)); Box(Modifier.size(24.dp).clip(CircleShape).background(c).border(2.dp, Color.White, CircleShape)) }
        Slider(c.red, { set(Color(it, c.green, c.blue)) }, colors = SliderDefaults.colors(thumbColor = Color.Red, activeTrackColor = Color.Red))
        Slider(c.green, { set(Color(c.red, it, c.blue)) }, colors = SliderDefaults.colors(thumbColor = Color.Green, activeTrackColor = Color.Green))
        Slider(c.blue, { set(Color(c.red, c.green, it)) }, colors = SliderDefaults.colors(thumbColor = Color(0xFF42A5F5), activeTrackColor = Color(0xFF42A5F5)))
    }
}
@Composable private fun VSlider(label: String, v: Int, lo: Int, hi: Int, set: (Int) -> Unit) {
    Row { Text(label, color = Color.White, modifier = Modifier.weight(1f)); Text("$v", color = Skins.current().accent, fontWeight = FontWeight.Bold) }
    Slider(v.toFloat(), { set(it.roundToInt()) }, valueRange = lo.toFloat()..hi.toFloat())
}

@Composable private fun ControlsTab() {
    val skin = Skins.current()
    var land by remember { mutableStateOf(true) }; var sel by remember { mutableStateOf<String?>(null) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    val l = PadLayouts.active
    val slotCol = if (PadLayouts.activeSlot in 1..6) PadLayouts.slotColors[PadLayouts.activeSlot - 1] else skin.accent
    H("Touch controls editor")
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Btn("LANDSCAPE", selected = land) { land = true; sel = null }; Btn("PORTRAIT", selected = !land) { land = false; sel = null } }
    Spacer(Modifier.height(8.dp))
    Box(Modifier.fillMaxWidth(), Alignment.Center) {
        Canvas(Modifier.height(if (land) 230.dp else 380.dp).aspectRatio(if (land) 16 / 9f else 9 / 16f).clip(RoundedCornerShape(12.dp)).border(4.dp, slotCol, RoundedCornerShape(12.dp))
            .onSizeChanged { size = it }
            .pointerInput(land) { detectTapGestures { o -> sel = hitTest(PadLayouts.active, land, size.width.toFloat(), size.height.toFloat(), o, 1.5f)?.id } }
            .pointerInput(land) { detectDragGestures(
                onDragStart = { o -> sel = hitTest(PadLayouts.active, land, size.width.toFloat(), size.height.toFloat(), o, 1.5f)?.id },
                onDragEnd = { PadLayouts.commit() }, onDragCancel = { PadLayouts.commit() },
                onDrag = { c, d -> c.consume(); sel?.let { id -> PadLayouts.update(PadLayouts.active.edit(land, id) { e -> e.copy(x = (e.x + d.x / size.width).coerceIn(.02f, .98f), y = (e.y + d.y / size.height).coerceIn(.04f, .96f)) }) } }) }
        ) {
            drawRect(Color(0xFF15151C)); val gw = if (land) size.width * .5f else size.width * .9f; val gh = gw * .7f
            drawRect(Color.Black, Offset((size.width - gw) / 2, if (land) (size.height - gh) / 2 else size.height * .06f), Size(gw, gh))
            drawPad(l, land, skin, emptySet(), Offset.Zero, sel ?: "", slotCol)
        }
    }
    Text("Drag a control to move it. Tap to select.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("D-PAD", selected = !l.stick) { PadLayouts.update(l.copy(stick = false)); PadLayouts.commit() }
        Btn("ANALOG STICK", selected = l.stick) { PadLayouts.update(l.copy(stick = true)); PadLayouts.commit() }
        listOf("round", "square", "hex", "pixel").forEach { sh -> Btn(sh.uppercase(), selected = l.shape == sh) { PadLayouts.update(l.copy(shape = sh)); PadLayouts.commit() } }
    }
    Spacer(Modifier.height(6.dp))
    Row { Text("Opacity", color = Color.White, modifier = Modifier.weight(1f)); Text("${(l.opacity * 100).roundToInt()}%", color = skin.accent) }
    Slider(l.opacity, { PadLayouts.update(l.copy(opacity = it)) }, valueRange = .2f..1f, onValueChangeFinished = { PadLayouts.commit() })
    val e = sel?.let { id -> l.els(land).firstOrNull { it.id == id } }
    if (e != null) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Selected: ${e.id}  size ${"%.1f".format(e.s)}×", color = Color.White, modifier = Modifier.weight(1f))
            Text("Visible", color = Color.White); Spacer(Modifier.width(6.dp)); Switch(e.on, { v -> PadLayouts.update(l.edit(land, e.id) { it.copy(on = v) }); PadLayouts.commit() }) }
        Slider(e.s, { v -> PadLayouts.update(l.edit(land, e.id) { it.copy(s = v) }) }, valueRange = .5f..2f, onValueChangeFinished = { PadLayouts.commit() })
    }
    Btn("RESET THIS ORIENTATION", Modifier.padding(top = 4.dp)) { val d = PadLayout.default(); PadLayouts.update(if (land) l.copy(land = d.land) else l.copy(port = d.port)); PadLayouts.commit() }

    H("Ready-made layouts (cannot be overwritten)")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        (11..17).forEach { n -> Btn(Factory.names[n] ?: "$n", selected = PadLayouts.activeSlot == n, color = PadLayouts.colorOf(n)) { PadLayouts.loadSlot(n) } } }
    Text("Pick one, then change it freely and press SAVE CURRENT TO a slot below to keep your version.", color = Color(0xAAFFFFFF), fontSize = 11.sp)
    H("Presets (6 slots)")
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        for (n in 1..6) { val c = PadLayouts.slotColors[n - 1]; val filled = remember(PadLayouts.activeSlot, l) { PadLayouts.slot(n) != null }
            Box(Modifier.size(44.dp).clip(CircleShape).background(if (filled) c else Color.Transparent).border(if (PadLayouts.activeSlot == n) 5.dp else 2.dp, if (PadLayouts.activeSlot == n) Color.White else c, CircleShape)
                .forgeClick("confirm") { PadLayouts.loadSlot(n) }, Alignment.Center) { Text("$n", color = if (filled) Color.Black else c, fontWeight = FontWeight.Black) } }
    }
    Text("Tap a slot to load it. Filled = saved, hollow = empty. White ring = active.", color = Color(0xAAFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("SAVE CURRENT TO", color = skin.accent, fontWeight = FontWeight.Black, fontSize = 12.sp)
        for (n in 1..6) Btn("$n", color = PadLayouts.slotColors[n - 1]) { PadLayouts.saveSlot(n) }
    }
}

@Composable private fun BgTab() {
    val ctx = LocalContext.current
    fun pick(key: String) = Picker.pick(arrayOf("image/*")) { u -> u.firstOrNull()?.let { uri ->
        val f = File(Library.art, "$key-${System.currentTimeMillis()}.img")
        try { ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }; Store.s(key).takeIf { it.isNotEmpty() }?.let { File(it).delete() }; Store.set(key, f.path) } catch (_: Exception) {} } }
    H("Gamepad background (behind the game & controls)")
    val pb = rememberBitmap(Store.s("padBg").ifEmpty { null })
    Box(Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(12.dp)).skinBg(Skins.current())) { if (pb != null) Image(pb, null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) { Btn("CHOOSE IMAGE") { pick("padBg") }; Btn("CLEAR") { Store.set("padBg", "") } }
    SSlider("Dim image", "padDim", 40)
    H("Launcher background")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Btn("CHOOSE IMAGE") { pick("launcherBg") }; Btn("CLEAR") { Store.set("launcherBg", "") } }
    SSlider("Dim image", "launcherDim", 45)
    Text("Per-game background and logo are set on each game's page in the launcher.", color = Color(0xAAFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
}
