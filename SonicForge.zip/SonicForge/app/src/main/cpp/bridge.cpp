// JNI host for a libretro core (Genesis Plus GX). Loaded with dlopen() from the app's native lib dir.
#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <algorithm>
#include <atomic>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>
#include "libretro_min.h"
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "SonicForge", __VA_ARGS__)

static void* g_lib = nullptr;
#define FN(ret, name, args) static ret (*name) args = nullptr;
FN(void, retro_set_environment, (retro_environment_t))
FN(void, retro_set_video_refresh, (retro_video_refresh_t))
FN(void, retro_set_audio_sample, (retro_audio_sample_t))
FN(void, retro_set_audio_sample_batch, (retro_audio_sample_batch_t))
FN(void, retro_set_input_poll, (retro_input_poll_t))
FN(void, retro_set_input_state, (retro_input_state_t))
FN(void, retro_init, (void))
FN(void, retro_deinit, (void))
FN(void, retro_get_system_av_info, (retro_system_av_info*))
FN(void, retro_set_controller_port_device, (unsigned, unsigned))
FN(void, retro_reset, (void))
FN(void, retro_run, (void))
FN(size_t, retro_serialize_size, (void))
FN(bool, retro_serialize, (void*, size_t))
FN(bool, retro_unserialize, (const void*, size_t))
FN(bool, retro_load_game, (const retro_game_info*))
FN(void, retro_unload_game, (void))
FN(void*, retro_get_memory_data, (unsigned))
FN(size_t, retro_get_memory_size, (unsigned))
FN(void, retro_get_system_info, (retro_system_info*))
FN(void, retro_cheat_reset, (void))
FN(void, retro_cheat_set, (unsigned, bool, const char*))

static std::mutex g_vmx, g_amx;
static std::vector<uint8_t> g_frame, g_rom;
static unsigned g_w = 0, g_h = 0;
static bool g_new = false;
static std::vector<int16_t> g_audio;
static std::atomic<int> g_input{0};
static std::string g_sys, g_save, g_path;
static retro_system_av_info g_av{};
static std::mutex g_lmx; static std::vector<std::string> g_logs; static std::string g_err;
struct retro_log_callback { void (*log)(int level, const char* fmt, ...); };
static void core_log(int level, const char* fmt, ...) {   // the core's own console messages ("Unable to open CD BIOS ..." etc.)
    char buf[600]; va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    std::lock_guard<std::mutex> l(g_lmx); if (g_logs.size() < 400) g_logs.push_back(std::to_string(level) + "|" + buf);
}
static unsigned g_fmt = 2;   // 0 = 0RGB1555, 1 = XRGB8888, 2 = RGB565 (everything is converted to RGB565 for the GL texture)

static bool env_cb(unsigned cmd, void* d) {
    switch (cmd) {
        case 27: ((retro_log_callback*)d)->log = core_log; return true;   // RETRO_ENVIRONMENT_GET_LOG_INTERFACE
        case RETRO_ENVIRONMENT_GET_CAN_DUPE: *(bool*)d = true; return true;
        case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: { unsigned f = *(unsigned*)d; if (f <= 2) { g_fmt = f; return true; } return false; }
        case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY: *(const char**)d = g_sys.c_str(); return true;
        case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: *(const char**)d = g_save.c_str(); return true;
        case RETRO_ENVIRONMENT_GET_VARIABLE: ((retro_variable*)d)->value = nullptr; return false; // core defaults
        case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: *(bool*)d = false; return true;
        case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION: *(unsigned*)d = 0; return true;
        case RETRO_ENVIRONMENT_SET_GEOMETRY: return true;
        default: return false;
    }
}
static void video_cb(const void* data, unsigned w, unsigned h, size_t pitch) {
    if (!data) return;
    std::lock_guard<std::mutex> l(g_vmx);
    g_frame.resize((size_t)w * h * 2);
    for (unsigned y = 0; y < h; y++) {
        uint16_t* dst = (uint16_t*)&g_frame[(size_t)y * w * 2]; const uint8_t* row = (const uint8_t*)data + y * pitch;
        if (g_fmt == 2) memcpy(dst, row, (size_t)w * 2);
        else if (g_fmt == 1) { const uint32_t* p = (const uint32_t*)row; for (unsigned x = 0; x < w; x++) { uint32_t v = p[x]; dst[x] = (uint16_t)(((v >> 19) & 31) << 11 | ((v >> 10) & 63) << 5 | ((v >> 3) & 31)); } }
        else { const uint16_t* p = (const uint16_t*)row; for (unsigned x = 0; x < w; x++) { uint16_t v = p[x]; unsigned r = (v >> 10) & 31, g = (v >> 5) & 31, bl = v & 31; dst[x] = (uint16_t)(r << 11 | ((g << 1) | (g >> 4)) << 5 | bl); } }
    }
    g_w = w; g_h = h; g_new = true;
}
static void audio1(int16_t, int16_t) {}
static size_t audio_batch(const int16_t* d, size_t frames) {
    std::lock_guard<std::mutex> l(g_amx);
    g_audio.insert(g_audio.end(), d, d + frames * 2);
    if (g_audio.size() > 48000 * 2) g_audio.erase(g_audio.begin(), g_audio.end() - 48000);
    return frames;
}
static void poll_cb() {}
static int16_t input_cb(unsigned port, unsigned device, unsigned, unsigned id) {
    if (port != 0 || device != RETRO_DEVICE_JOYPAD) return 0;
    int m = g_input.load();
    if (id == RETRO_DEVICE_ID_JOYPAD_MASK) return (int16_t)(m & 0xFFFF);
    return (m >> id) & 1;
}
static std::string S(JNIEnv* e, jstring s) { const char* c = e->GetStringUTFChars(s, nullptr); std::string r(c); e->ReleaseStringUTFChars(s, c); return r; }

extern "C" {
#define J(name) Java_com_sonicforge_core_Emu_##name
#define LOAD(n) n = (decltype(n))dlsym(g_lib, #n); if (!n) { LOG("missing symbol %s", #n); return JNI_FALSE; }

JNIEXPORT jboolean JNICALL J(loadCore)(JNIEnv* e, jobject, jstring path, jstring sys, jstring save) {
    g_sys = S(e, sys); g_save = S(e, save);
    g_lib = dlopen(S(e, path).c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!g_lib) { const char* er = dlerror(); g_err = er ? er : "dlopen failed"; LOG("dlopen failed: %s", g_err.c_str()); return JNI_FALSE; }
    LOAD(retro_set_environment) LOAD(retro_set_video_refresh) LOAD(retro_set_audio_sample) LOAD(retro_set_audio_sample_batch)
    LOAD(retro_set_input_poll) LOAD(retro_set_input_state) LOAD(retro_init) LOAD(retro_deinit) LOAD(retro_get_system_av_info)
    LOAD(retro_set_controller_port_device) LOAD(retro_reset) LOAD(retro_run) LOAD(retro_serialize_size) LOAD(retro_serialize)
    LOAD(retro_unserialize) LOAD(retro_load_game) LOAD(retro_unload_game) LOAD(retro_get_memory_data) LOAD(retro_get_memory_size)
    retro_get_system_info = (decltype(retro_get_system_info))dlsym(g_lib, "retro_get_system_info");
    retro_cheat_reset = (decltype(retro_cheat_reset))dlsym(g_lib, "retro_cheat_reset"); retro_cheat_set = (decltype(retro_cheat_set))dlsym(g_lib, "retro_cheat_set");
    retro_set_environment(env_cb);
    retro_init();
    retro_set_video_refresh(video_cb); retro_set_audio_sample(audio1); retro_set_audio_sample_batch(audio_batch);
    retro_set_input_poll(poll_cb); retro_set_input_state(input_cb);
    return JNI_TRUE;
}
JNIEXPORT jdoubleArray JNICALL J(loadGame)(JNIEnv* e, jobject, jstring path, jboolean fullpath) {
    g_path = S(e, path);
    retro_game_info gi{g_path.c_str(), nullptr, 0, nullptr};
    if (!fullpath) {   // cartridge ROMs are handed over in memory; CD images (cue/chd/iso) are opened by the core from the path
        FILE* f = fopen(g_path.c_str(), "rb"); if (!f) return nullptr;
        fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
        g_rom.resize(n); if (fread(g_rom.data(), 1, n, f) != (size_t)n) { fclose(f); return nullptr; } fclose(f);
        gi.data = g_rom.data(); gi.size = g_rom.size();
    }
    if (!retro_load_game(&gi)) return nullptr;
    retro_get_system_av_info(&g_av);
    retro_set_controller_port_device(0, RETRO_DEVICE_JOYPAD);
    double asp = g_av.geometry.aspect_ratio > 0 ? g_av.geometry.aspect_ratio : (double)g_av.geometry.base_width / g_av.geometry.base_height;
    double a[5] = {g_av.timing.fps, g_av.timing.sample_rate, (double)g_av.geometry.base_width, (double)g_av.geometry.base_height, asp};
    jdoubleArray r = e->NewDoubleArray(5); e->SetDoubleArrayRegion(r, 0, 5, a); return r;
}
JNIEXPORT void JNICALL J(run)(JNIEnv*, jobject) { if (retro_run) retro_run(); }
JNIEXPORT jlong JNICALL J(fetchFrame)(JNIEnv* e, jobject, jobject buf) {
    std::lock_guard<std::mutex> l(g_vmx);
    if (!g_new) return 0;
    uint8_t* dst = (uint8_t*)e->GetDirectBufferAddress(buf);
    if (!dst || (jlong)g_frame.size() > e->GetDirectBufferCapacity(buf)) return 0;
    memcpy(dst, g_frame.data(), g_frame.size()); g_new = false;
    return ((jlong)g_w << 16) | g_h;
}
JNIEXPORT jint JNICALL J(getAudio)(JNIEnv* e, jobject, jshortArray out) {
    std::lock_guard<std::mutex> l(g_amx);
    jsize cap = e->GetArrayLength(out); jsize n = (jsize)std::min<size_t>(cap & ~1, g_audio.size());
    if (n > 0) { e->SetShortArrayRegion(out, 0, n, g_audio.data()); g_audio.erase(g_audio.begin(), g_audio.begin() + n); }
    return n;
}
JNIEXPORT void JNICALL J(setInput)(JNIEnv*, jobject, jint m) { g_input = m; }
JNIEXPORT void JNICALL J(reset)(JNIEnv*, jobject) { if (retro_reset) retro_reset(); }
JNIEXPORT jint JNICALL J(serializeSize)(JNIEnv*, jobject) { return retro_serialize_size ? (jint)retro_serialize_size() : 0; }
JNIEXPORT jboolean JNICALL J(serialize)(JNIEnv* e, jobject, jbyteArray out) {
    jsize n = e->GetArrayLength(out); jbyte* p = e->GetByteArrayElements(out, nullptr);
    bool ok = retro_serialize(p, n); e->ReleaseByteArrayElements(out, p, 0); return ok;
}
JNIEXPORT jboolean JNICALL J(unserialize)(JNIEnv* e, jobject, jbyteArray in) {
    jsize n = e->GetArrayLength(in); jbyte* p = e->GetByteArrayElements(in, nullptr);
    bool ok = retro_unserialize(p, n); e->ReleaseByteArrayElements(in, p, JNI_ABORT); return ok;
}
JNIEXPORT jbyteArray JNICALL J(getSram)(JNIEnv* e, jobject) {
    size_t n = retro_get_memory_size(RETRO_MEMORY_SAVE_RAM); void* p = retro_get_memory_data(RETRO_MEMORY_SAVE_RAM);
    if (!n || !p) return nullptr;
    jbyteArray r = e->NewByteArray(n); e->SetByteArrayRegion(r, 0, n, (jbyte*)p); return r;
}
JNIEXPORT void JNICALL J(setSram)(JNIEnv* e, jobject, jbyteArray d) {
    size_t n = retro_get_memory_size(RETRO_MEMORY_SAVE_RAM); void* p = retro_get_memory_data(RETRO_MEMORY_SAVE_RAM);
    jsize len = e->GetArrayLength(d); if (!p || !n) return;
    e->GetByteArrayRegion(d, 0, std::min<size_t>(n, len), (jbyte*)p);
}
JNIEXPORT jbyteArray JNICALL J(readRam)(JNIEnv* e, jobject, jint start, jint len) {
    size_t n = retro_get_memory_size(RETRO_MEMORY_SYSTEM_RAM); uint8_t* p = (uint8_t*)retro_get_memory_data(RETRO_MEMORY_SYSTEM_RAM);
    if (!p || start < 0 || (size_t)(start + len) > n) return nullptr;
    jbyteArray r = e->NewByteArray(len); e->SetByteArrayRegion(r, 0, len, (jbyte*)(p + start)); return r;
}
JNIEXPORT void JNICALL J(setCheats)(JNIEnv* e, jobject, jobjectArray arr) {
    if (!retro_cheat_reset || !retro_cheat_set) return;
    retro_cheat_reset(); jsize n = e->GetArrayLength(arr);
    for (jsize i = 0; i < n; i++) { jstring js = (jstring)e->GetObjectArrayElement(arr, i); std::string c = S(e, js); retro_cheat_set(i, true, c.c_str()); e->DeleteLocalRef(js); }
}
JNIEXPORT void JNICALL J(setPadType)(JNIEnv*, jobject, jint d) { if (retro_set_controller_port_device) retro_set_controller_port_device(0, (unsigned)d); }
JNIEXPORT void JNICALL J(writeRam)(JNIEnv*, jobject, jint off, jint val) {
    size_t n = retro_get_memory_size(RETRO_MEMORY_SYSTEM_RAM); uint8_t* p = (uint8_t*)retro_get_memory_data(RETRO_MEMORY_SYSTEM_RAM);
    if (p && off >= 0 && (size_t)off < n) p[off] = (uint8_t)val;
}
JNIEXPORT jstring JNICALL J(popLogs)(JNIEnv* e, jobject) {
    std::lock_guard<std::mutex> l(g_lmx); std::string all; for (auto& x : g_logs) { all += x; all += "\n"; } g_logs.clear(); return e->NewStringUTF(all.c_str());
}
JNIEXPORT jstring JNICALL J(lastError)(JNIEnv* e, jobject) { return e->NewStringUTF(g_err.c_str()); }
JNIEXPORT jstring JNICALL J(coreInfo)(JNIEnv* e, jobject) {
    if (!retro_get_system_info) return e->NewStringUTF("");
    retro_system_info si{}; retro_get_system_info(&si);
    std::string r = std::string(si.library_name ? si.library_name : "?") + " " + (si.library_version ? si.library_version : "?"); return e->NewStringUTF(r.c_str());
}
JNIEXPORT void JNICALL J(unload)(JNIEnv*, jobject) {
    if (retro_unload_game) retro_unload_game();
    if (retro_deinit) retro_deinit();
    if (g_lib) { dlclose(g_lib); g_lib = nullptr; }
    retro_run = nullptr;
}
}
