plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sonicforge"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.sonicforge"
        minSdk = 26
        targetSdk = 34
        versionCode = 7
        versionName = "0.3.4"
        externalNativeBuild { cmake { cppFlags += "-std=c++17"; abiFilters += listOf("arm64-v8a", "armeabi-v7a") } }
    }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
    signingConfigs {   // fixed key => every build (PC, GitHub, Termux) can update the previous one without losing data
        create("forge") { storeFile = file("forge.keystore"); storePassword = "sonicforge"; keyAlias = "forge"; keyPassword = "sonicforge" }
    }
    splits { abi { isEnable = true; reset(); include("arm64-v8a", "armeabi-v7a"); isUniversalApk = true } }   // 3 APKs: arm64-v8a, armeabi-v7a, universal
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions {
        jvmTarget = "17"
        // safety net: compose APIs flagged "experimental" that we may still touch compile fine (versions are pinned, so they cannot change under us)
        freeCompilerArgs += listOf("-opt-in=kotlin.RequiresOptIn", "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi", "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api")
    }
    // the libretro core must be extracted to disk so we can dlopen() it by path
    packaging {
        jniLibs { useLegacyPackaging = true }
        resources { excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/*.md", "META-INF/INDEX.LIST", "META-INF/AL2.0", "META-INF/LGPL2.1", "META-INF/versions/**", "META-INF/**/module-info.class") }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("forge") }
        getByName("release") { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("forge") }
    }
}
dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("com.github.junrar:junrar:7.5.5")            // .rar (RAR4)
    implementation("org.apache.commons:commons-compress:1.26.1") // .7z
    implementation("org.tukaani:xz:1.9")
}
