# SonicForge: STATUS AT END OF THIS CHAT (supersedes the older notes below where they differ)

**Version in code: 0.3.3 (code 6), synopsis "Emerald Everything Plus".** Three APKs per build (Universal, arm64-v8a, armeabi-v7a). Min Android 8.0.
**Still NEVER compiled since 0.1.0.** Static checks passed (bracket balance, missing-import scan, removed-API grep, signature greps), but only a real Actions build proves it.

## Finished since the first checklist (all written, uncompiled)
- ExternalApps + AppPicker (choose any installed file manager / text editor; used by SETTINGS ▸ GENERAL and LOCATIONS ▸ OPEN)
- SCENE_PRESETS (28 palettes) and the Scene under each game now COLLECTS rings (score + ring counter)
- Full manifest: permissions, MusicService (mediaPlayback), FlashActivity, 9 activity-aliases + 8 icon vectors, leanback bits, banner
- Gradle: version 0.3.3/6, abiFilters removed, ABI splits + universal APK, androidx.webkit added
- Flash/Ruffle (EXPERIMENTAL): `FlashActivity` (WebView + WebViewAssetLoader, correct wasm MIME), `fetch_extras.sh` (downloads Ruffle self-hosted at CI time, optional), `.swf` import, FLASH launcher tab, touch direct/touchpad mouse (tap, two-finger right-click + scroll, hold LEFT/RIGHT buttons), injected real key and mouse events, gamepad (left stick/D-pad → arrows/WASD/mouse, face buttons → Space/Enter/Z/X sets, right stick → cursor, L2/R2 clicks, L1/R1 Shift/Ctrl), on-screen key sets, quick controls menu, quality/scale/resolution, haptics off by default
- I18n: ko, hi, tr added (UI labels only); pt labelled "Português (Brasil)"; keys for LOCATIONS/HELP/VIBRATION/APPEARANCE
- Changelog rewritten for 0.3.3 + new planned list; HELP topics for Flash and "Android folders & limits (advanced)"; Tails answer about Flash
- Docs: build guide mentions three APKs

## Translation status (answer to "are translations finished?")
- DONE: UI labels (tabs, buttons, headings, common settings) ≈100 strings × 9 languages (es fr de pt-BR ru uk ja zh it) + ≈45 strings × 3 (ko hi tr). Crash-log notes: en + ru/uk/es/fr/de (other languages show English).
- NOT translated (English only): Changelog/What's new text, first-run tutorial, HELP topics, helper dialogues (~110 answers), most long descriptions.
- Arabic: skipped (right-to-left layout risk).

## Characters (answer to "how many?")
9 helpers: **Tails** (Miles "Tails" Prower; launcher + every setting), **Sonic**, **Amy**, **Knuckles**, **Dr. Eggman** (explains Robotnik vs Eggman), **Metal Sonic**, **Motobug**, **Buzz Bomber**, **Shadow**. The user's list had 7 names (without Amy and Metal Sonic); both exist in code. Tails' full-name introduction ("Miles 'Tails' Prower") is still to be added to his intro text.

## NEXT UPDATE: requests remembered but deliberately postponed (do these after the first successful compile)
1. Translate Changelog, tutorial, HELP topics and ALL helper dialogues (data-driven: add per-language strings to the Q&A/Topic/Changelog models; start with ru).
2. **Music shuffle history**: when shuffle is ON and the user goes BACK, don't reshuffle: replay the songs that were played before (history stack, in the order they were played). Turning shuffle OFF continues along the list from the current song (already works).
3. **Alternative on-screen icon sets** for buttons: "ST"/START vs ▶ play symbols; filled and outline variants (2+ more types), plus custom image or custom text per button where easy (CUSTOMIZE ▸ CONTROLS ▸ Icon style).
4. Everything in the older deferred list below (pixel-draw tab incl. clipping/visibility/paste image/canvas resize, simple text editor, file explorer, comics/photos/video, karaoke/voice, lyrics/timestamps, widgets, holiday themes, gradient/image backgrounds, PNG-mask frames, per-tab presets, richer helper content, hack-specific vibration profiles, DS/SRB2, format-visibility toggles on all lists).

# SonicForge: feature checklist (state at handoff)

IMPORTANT: "Written" means code exists in the snapshot. **Nothing after v0.1.0 has been compiled.** Treat every item as "unverified until the first successful Actions build".
Legend: ✅ written · 🟡 partial · ⛔ not started · 🔒 deliberately deferred/impossible (reason given)

## 0. Build & release
- ✅ GitHub workflow (zip-in-repo variant `docs/build-from-zip.yml` and normal `.github/workflows/build.yml`) with SDK step fixed, error summary, build-log artifact
- ✅ `fetch_core.sh` (required: genesis_plus_gx; optional: picodrive, mgba; arm64-v8a + armeabi-v7a)
- ✅ Fixed signing key
- 🟡 Gradle: version is 0.3.1/code 4; **must become 0.3.3/code 6**; **must remove `ndk { abiFilters }` and add `splits { abi {...isUniversalApk = true} }`** (three APKs). Not done yet.
- ⛔ Manifest: add `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK`, `POST_NOTIFICATIONS`, `<service .audio.MusicService foregroundServiceType=mediaPlayback>`, 9 `activity-alias` entries (+ move the LAUNCHER filter from MainActivity to the default alias), leanback `uses-feature` + `LEANBACK_LAUNCHER`. (`queries` block for OpenBOR detection IS already there.)
- ⛔ 8 alias icon vectors (calculator, notes, gold ring, launcher grid, collection, music, gamepad, clock)
- ✅ Experimental-API safety-net opt-ins in Gradle; Pager removed

## 1. Emulation core (C++/Kotlin)
- ✅ libretro JNI bridge (dlopen core, env callbacks, RGB565/XRGB8888/0RGB1555 → RGB565, audio batch, input mask, SRAM, states, cheats, pad type, RAM read/write, core log capture, last error, core info)
- ✅ EmuSession: pacing, AudioTrack (+LoudnessEnhancer), rewind (60 snapshots), FF, speed chips incl. unlimited, tilt RAM corruption levels, RAM watcher events, saves with previous-save (.prev), restore previous, Sega CD BIOS check, core selection by system
- ✅ Systems registry (md, sms, gg, scd, x32, gba, gb, bor) and per-system input bit mapping (GBA)
- ✅ GL renderer + 22 shaders (none, crt, bloom, bloomlite, anime, cinematic, vibes, greenhill, future, sakura, lcd, gameboy, sepia, noir, glitch, synthwave, aqua, snow, ember, emerald, dream, arcade); render FPS counter; screenshot
- 🟡 Optional cores (picodrive/mgba) depend on buildbot URLs/availability (unverified)
- 🔒 Nintendo DS (needs touch pointer + dual-screen layout engine), 3DS (hardware-render cores; display modes only possible in external emulators), Saturn/Dreamcast/PSP/GameCube/Wii/PS2: not embedded (need hardware rendering/huge). Guidance only.
- 🔒 Flash/Ruffle: planned, big (WebView + CI download of Ruffle + MotionEvent mouse injection); not started
- 🔒 SRB2: external-engine tab planned; not started
- ✅ OpenBOR: external app launcher + PAK export to Downloads + ABI compatibility report (`OpenBor.kt`)

## 2. Library / import
- ✅ Import ROMs, .zip/.rar(RAR4)/.7z, Sega CD sets (.cue+.bin or .chd/.iso), BIOS import, IPS/BPS patching, linked ROM folder scan, art per game, game groups/variants, reorder (▲▼), system tabs in launcher
- 🔒 RAR5: unsupported by junrar (documented; user must re-pack)
- ⛔ File explorer (X-Plore/ZArchiver style: multi-select, copy/move/rename/delete/extract, format groups, hidden/system toggle), "reset console/emulator" (cores live in nativeLibraryDir so they cannot be corrupted; plan = Repair library + clear system folder), mods folder option

## 3. Controls
- ✅ Touch layout editor, 6 user presets + 7 factory presets (11-17), L/R buttons, REW/FF buttons, per-orientation opacity modes (layout/all/pairs), quick opacity cycle in game
- ✅ Gamepad & keyboard separate maps, APPLY/CANCEL/RESET (can exit capture), combos, visualisation (Xbox/PS/Steam labels), controller list, hide touch with pad
- ✅ Pocket Lock (touch lock) + Stay Awake + UI hide + rescue button "👁 UI" in launcher top bar
- ⛔ Mouse emulation/Flash controls; adaptive triggers (🔒 not usable on Android generic gamepads)

## 4. In-game menu
- ✅ Two-step menu (quick pop-up → full menu: GAME, SCREEN, AUDIO, CONTROLS, VIBRATION, CHEATS, TOOLS[Pro]); freezes the game (Start is separate); mini music player; save states with RESTORE PREV; cheat input with format explanation; Ring Finder; Cartridge Wobble (3 levels, epilepsy warning, confirmation with delay)
- ✅ Classic mode (4:3 picture only, small or full-height frame), aspect fit/4:3/16:9/1:1/stretch, margins, corner mask, offsets, pixel/smooth, FPS counters (EMU & SCREEN, colours)

## 5. Customisation
- ✅ 18 skins, frame styles/colours, RGB pickers, shader per game, per-game skin/layout/music, background effects behind game, backgrounds for gamepad/launcher
- 🟡 Customize tab shows factory row + my presets; per-tab (music/comics/photos) separate preset systems not built
- ⛔ Holiday themes (New Year/Halloween/Easter/birthday), animated backgrounds beyond particles, gradient background editor (direction/colours/presets), image background fit/crop/positioning, PNG-mask/shaped frames, frame contour variants, widget themes, carousel/fade backgrounds
- 🟡 Scene (mini-hero under game description): drawn, tappable; **ring collecting + score + 26 palettes (`SCENE_PRESETS`) NOT yet written** (Launcher already references `SCENE_PRESETS`)

## 6. Audio & music
- ✅ Volumes 0-200% (snap, ±1, reset); music-in-game policy; sound packs (3) + custom
- ✅ Music engine: async import with failed catalogue + reasons, more formats, covers, artist/length/size/date, sort, multi-select + delete confirmation, playlists (create/add/remove/merge/ungroup/reorder), equalizers (5 styles, smooth fade), disc scrub, ±10/30, shuffle/repeat labels ON/OFF, time format, 3 faces (handheld/neon/streaming), mini bar on all tabs, test tunes incl. ~2 min "Speed Rush"
- ✅ MusicService (notification, media session, headset multi-click 1/2/3) **but manifest entries missing**
- ⛔ Lyrics/subtitles, timestamps/chapters, karaoke recorder/multitrack editor (🔒 big; fallback idea: voice mini-game), widgets, private music folders, blur, video player

## 7. Vibration
- ✅ Master/app/emulator/per-game switches, per-event on/off + strength, templates, presets 1-3 built-in + 4-9 user, panel in settings AND in game menu, 18 events (touch, ring, hurt, death, jump, spin, spring, fly, drown, bite, drain, oneup, shield, invinc, shoes, fizz, zap, step[experimental])
- ✅ RAM profiles s1, s2, s3k (basic), s3kx (experimental), generic via Ring Finder, off; per-game profile chips in ✎ EDIT
- ⛔ Wind/Sky Battery, breakable walls, score tally, casino, boss/victory music haptics, per-system settings tabs, hack-specific presets (Sonic 2 XL, Hellfire Saga, Ordinary Sonic), "danger meter"/chase haptics

## 8. Mini-games
- ✅ 11 games: Ring Runner, Fire Chase, Boulder Dodge, Ring Catcher, Speed Cafe (real menu names), Spin Dash Charge, Emerald Memory, Badnik Bash (Motobug look), Tails Flyer, Zone Trivia, Street Brawl; shared shell (pause, mute, best, rules, hide, 3-2-1-GO, fit to screen), hero choice (6)
- ⛔ Spin Dash Charge improvements beyond current, level-maker, voice mini-game, more themed games

## 9. Helpers, help, tutorial
- ✅ HELP tab: 10 topics, ASK A HELPER (9 characters, ~109 answers, LIST/TYPE/BOTH, Tails depth levels, backdrops, Eggman moustache, cross-referral)
- ✅ First-run tutorial overlay (7 pages, Tails leads, own swipe pager, skip with confirmation, replay from settings/help)
- ⛔ Much more helper content (see requests log §Helpers), Android-restrictions tutorial topic (Shizuku/adb/OBB/.apks), characters' canonical-looking art, holiday events

## 10. Logs & safety
- ✅ Logger (off/errors/full), Issues keep/delete, CrashKB (13 entries), core log capture, hidden viewer
- ✅ Confirm dialogs with delay + settings (3 s/5 s/off), Classic/Pro mode switch + explanation; Pro gating applied to VIDEO advanced blocks, CONTROLS advanced sub-tabs, experimental switch, TOOLS tab
- ✅ Backups: light/full parts, named file, manifest, inspect + restore with missing-file warnings

## 11. UI shell / info
- ✅ Tabs, mini player bar, LOCATIONS, SETTINGS (general/video/audio/vibration/controls/launcher sounds/appearance/data/about/updates), margin preview, ABI/Android info, hidden logs
- 🟡 Changelog head still says 0.3.1 "Emerald Everything": must be rewritten for **0.3.3 "Emerald Everything Plus"** (+ planned list updated)
- 🟡 I18n: en, es, fr, de, pt, it, ru, uk, ja, zh ≈100 strings; **ko/hi/tr not added**; Arabic skipped (RTL risk); new keys (LOCATIONS, HELP, VIBRATION…) partly missing in the table
- ⛔ Pixel-draw tab (layers, visibility, clipping mask, paste image onto layer, canvas resize, palettes), simple text editor, external file-manager/text-editor chooser (`ExternalApps`/`AppPicker` referenced but NOT defined), format-visibility toggles in all lists (only music has it), comics/photos/video tabs, widgets, TV polish
Added at the end of the 0.3.4 work: DRAW tab (DrawUi.kt: Draw object + DrawScreen), tutorial page titles translated in 12 languages, Sfx rewritten (all packs preloaded, applies instantly), MusicUi no longer recomposes per frame (derivedStateOf + ProgressBar), Library import write bug fixed.
