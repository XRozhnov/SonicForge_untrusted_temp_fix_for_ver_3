# File map & architecture (source snapshot)

Project root = `SonicForge/` (inside the ZIP). Package `com.sonicforge`, sources in `app/src/main/java/com/sonicforge/`.

## Root / build
- `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `gradle/wrapper/gradle-wrapper.properties` (CI uses setup-gradle 8.7; no wrapper jar)
- `fetch_core.sh`: downloads libretro cores to `app/src/main/jniLibs/<abi>/lib<name>.so` (`libgpgx.so` required; `libpicodrive.so`, `libmgba.so` optional)
- `.github/workflows/build.yml` and `docs/build-from-zip.yml` (zip-in-repo variant)
- `docs/BUILD_GUIDE.md`, `docs/WHERE_FILES_LIVE.md`, `README.md`
- `app/build.gradle.kts` (compose, signing `forge`, packaging excludes, opt-ins, dependencies), `app/forge.keystore`
- `app/src/main/AndroidManifest.xml` (activities Main/Game, VIBRATE, queries; **service/aliases/permissions pending**)
- `app/src/main/res/values/themes.xml`, `res/drawable/ic_launcher.xml` (emerald gem)
- `app/src/main/cpp/CMakeLists.txt`, `bridge.cpp` (libretro host), `libretro_min.h` (minimal API subset)

## Kotlin modules
**root**: `ForgeApp` (init order: Store → Logger → Library → PadLayouts → Sfx → Haptics → Pads → Music), `MainActivity` (tabs, pickers, mini bar, rescue UI button, notification permission, OpenBOR launch), `GameActivity` (GL view, overlays, two-step menu, key/axis handling, Ring Finder, wobble), `OpenBor` (detect app, ABI report, export PAK).
**core/**: `Emu` (JNI facade + `Bits`), `EmuSession` (emulator thread), `GlView` (renderer, shot, render FPS), `Shaders` (GLSL), `Shots`, `Systems` (+`PadSys`), `Watch` (RAM profiles + `Watcher` events).
**data/**: `Store` (settings map + verified JSON writes + save events with labels), `Library` (`Rom` data class, import, CD sets, BIOS, folder scan, patches, move), `Archives` (zip/rar/7z extraction), `Patch` (IPS/BPS), `Backup` (parts, manifest, inspect, restore), `Layouts` (`CtrlEl`, `PadLayout`, `Factory` 11-17, `PadLayouts` user slots/opacity), `Logger`, `CrashKB`, `Tips` (+`CheatDb`).
**audio/**: `Synth` (WAV synthesis, UI sound packs, test tunes), `Sfx`, `Music` (engine, failed list, metadata, policy), `MusicService`, `Playlists`.
**input/**: `Haptics` (events, patterns, presets), `Pads` (`Act` enum, gamepad/keyboard maps, combos, capture).
**ui/**: `Themes` (Skins), `Common` (Btn, H, SSlider/SToggle/SChips/VolSlider, borders, Particles, SaveIndicator), `Controls` (hit-test + drawPad + overlay), `Fx` (background effects), `Scene` (mini hero under game), `Launcher`, `MiniGames`, `MusicUi`, `CustomizeUi`, `SettingsUi`, `HapticsUi`, `AboutUi` (+Changelog), `LogsUi`, `BackupUi`, `LocationsUi`, `HelpUi`, `AssistantData`, `Guide`, `Confirm`, `I18n`, `Orient`, `Picker`.

## Design facts that matter when editing
- **i18n**: every `Text(...)` in package `com.sonicforge.ui` is the project's own wrapper (`I18n.kt`) that translates English strings via a lookup table. Files that explicitly import `androidx.compose.material3.Text` would bypass it (don't). Table row format: `English::es|fr|de|pt|ru|uk|ja|zh|it`.
- **Skins** are read inside composition via `Skins.current()` (reads Store state → recomposes). Overrides are Store keys (bdStyle, bdColor, bdWidth, bdRadius, accentC, shader).
- **Store** persists a flat String map to `data/settings.json` (debounced 500 ms, verified write, label chosen from last key by `Store.labelFor`). Typed helpers `s/i/f/b/set/setI/setB`. Empty string counts as "unset".
- **SurfaceView limitation**: Compose can't clip a GLSurfaceView; corner rounding is a mask drawn over it. Overlays above the surface work.
- **RAM watching**: 68000 work RAM is exposed byte-swapped per 16-bit word on little-endian hosts: read byte at address `a` as `ram[a xor 1]`. Profiles hold addresses as offsets inside the 64 KB (`$FFxxxx` → `0xxxxx`). Sonic 1: rings `0xFE20`, lives `0xFE12`, air `0xFE14`, player `0xD000`, status +0x22, anim +0x1C, shield/invinc/shoes `0xFE2C/2D/2E`, inertia +0x14. Sonic 2: player `0xB000`, Tails `0xB040`. S3K advanced offsets are from memory (unverified).
- **libretro mapping (Genesis Plus GX)**: MD A=RetroPad Y, B=B, C=A; X/Y/Z = L/X/R (unverified); six-button pad is device 257; GBA uses A/B/L/R directly (`Systems.bit`).
- **Threading**: libretro is only called from the emulator thread; other threads queue work with `EmuSession.post {}`. Core logs are drained once per second.
- **Files**: private storage `filesDir/{roms,saves,data,art,sounds,music,system,logs}`; external app dir `Android/data/com.sonicforge/files/{music,screenshots}`. CD games live in `roms/<id>/` with the `.cue` path stored in `Rom.file`. ROM files are stored with their ORIGINAL extension (cores detect type by extension).
- **Store key catalogue** (all strings): lang, skin, shader, bdStyle/bdColor/bdWidth/bdRadius/accentC, aspect, classic, classicFrame, smooth, scrTop/scrBottom/scrLeft/scrRight/scrRadius/scrScale/scrOffX/scrOffY, fps, fpsEmu/fpsScr/fpsEmuCol/fpsScrCol, rewind, ffMult, sixButton, orientLauncher/orientGame, immGame/immLauncher, bgfx/bgfxPng/bgfxOver, padBg/padDim, launcherBg/launcherDim, volMusic/volGame/volUi, musicInGame, musicNotif, sfxPack, sfx_<event>, hapAppOn/hapGameOn/hapApp/hapSteps/hapStepCal/hapG_<romId>/hapE_<event>_on/_amp, pad_<ACT>/kb_<ACT>/combo_<ACT>, padOn/kbOn/hideTouch/padDead, opMode/opAll/opPortPair/opLandPair, layoutSlot, quickSlot, cheats_<romId>, experiments, proMode, confirmMode, guideSeen, logMode, crashPending, romFolder/musicFolder/scanned, musFace/musEq/musSort/musRev/musDetLen/musDetSize/musDetDate/musDetFmt/coverMode/cov_<path>/timeFmt, miniBanner, mgHero, hs_<game>, testTunes/testTune3, appIcon, extFm/extEdit (planned), notifAsked, uiHidden.
- **JSON files in `data/`**: settings.json, library.json, layout_active.json, layout_slot1-6.json, haptic_preset_4-9.json, playlists.json, issues.json (in logs/).
- **Build gotchas already hit**: setup-android action fails ("package 'tools'"); experimental Compose Pager; `/bin/sh` brace expansion in my sandbox heredocs; python patch scripts abort entirely on a single syntax error (use triple-quoted strings, run scripts from files).
