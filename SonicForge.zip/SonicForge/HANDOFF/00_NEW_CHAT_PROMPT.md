# Prompt to paste into a NEW chat (copy everything below the line)

Attach these files together with this message: `SonicForge_source_snapshot.zip` (project + all handoff docs inside the `HANDOFF/` folder), or at least the 7 `.md` files + `status.json`.

---

Hi Claude. We are continuing a long project from an earlier chat that ran out of space. Everything you need is in the attached files. Please read them IN THIS ORDER before doing anything, and tell me in 10-15 lines what you understood (state of the project, what is done, what is next):

1. `01_PROJECT_CONTEXT.md`: who I am, what the app is, rules I gave you, environment, how builds work.
2. `03_CHECKLIST.md`: exact status of every feature (done / partial / not started / deferred).
3. `06_KNOWN_ISSUES_AND_NEXT_STEPS.md`: what is broken or missing RIGHT NOW and the exact order to finish.
4. `04_FILE_MAP_AND_ARCHITECTURE.md`: where everything is in the source.
5. `02_USER_REQUESTS_FULL_LOG.md`: every request I ever made (so I don't have to repeat myself).
6. `05_RESEARCH_NOTES_VERIFIED_FACTS.md`: facts already researched and checked (cheat codes, bugs, menu names, OpenBOR APK analysis, error messages).

Project name: **SonicForge** (Android package `com.sonicforge`). Current gradle version: 0.3.1 (code 4). Target next version: **0.3.3** with a synopsis of at most three words (planned: "Emerald Everything Plus").

Important working rules (details in file 01):
- I write mostly in Russian now, earlier in English. Reply in the language I use in my latest message.
- Do what is needed, don't do what is not needed. If something can't work reliably, don't add it, or add it clearly marked EXPERIMENTAL with a crash warning, and put it on the "can't do / later" list with the reason.
- Research on the internet when facts matter (you have web search); don't invent facts; tell me when something is unverified.
- The code has NOT been compiled since version 0.1.0. First priority is a build that compiles on GitHub Actions (zip-in-repo method). Check for compile errors by careful reading; I will send you the Actions "Summary" errors if the build fails.
- Deliver a single ZIP of the full project each time, plus short instructions. Update the in-app "What's new" and the in-app guide/help for every change.

When you have read everything, start with `06_KNOWN_ISSUES_AND_NEXT_STEPS.md`, step 1, and finish the compile-critical items first. Then continue the checklist in order. Ask me only if something is truly ambiguous.
