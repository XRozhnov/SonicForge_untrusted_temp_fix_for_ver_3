# SonicForge: project context (read first)

## 1. Who / what / why
- The user is a Russian-speaking hobbyist (mostly writes Russian now; early messages were English). GitHub user **XRozhnov**, private repo **SonicForge**. Phone: Android (screenshots show a Xiaomi/Poco-style Android with 120+ Hz display; exact model unknown). Personal use only.
- He owns MD.emu (paid, closed source) and wanted "one unified game/launcher" with the same gameplay, lots of customisation (like Sonic 3 A.I.R. is mod-driven), Sonic ROMs/hacks, mini-games, music player, shaders, vibration, etc.
- App name: **SonicForge**. Android applicationId/namespace: `com.sonicforge`. Logo: faceted Chaos-Emerald-style gem (vector `ic_launcher.xml`).
- I (Claude) refused to repackage/reverse-engineer MD.emu. The app instead hosts the open-source **libretro** cores (Genesis Plus GX for Mega Drive/Master System/Game Gear/Sega CD; optional PicoDrive for 32X; optional mGBA for GBA/GB) through a small C++ JNI bridge. Cores are downloaded at BUILD time by `fetch_core.sh` (the APK has NO INTERNET permission). ROMs are never bundled; the user imports his own.

## 2. Environment and constraints
- **My sandbox**: no internet from bash, no Gradle/Kotlin/Android SDK, Python 3 + Java exist. I CANNOT compile. Web search/fetch tools exist (use them for research). Files are delivered with `present_files` from `/mnt/user-data/outputs/`. The working dir `/home/claude/SonicForge` disappears with the chat: the source ZIP is the source of truth.
- **How the user builds**: GitHub Actions, "zip-in-repo" method. Repo root contains `SonicForge.zip` + `.github/workflows/build.yml`; the workflow unzips (so paths in logs look like `SonicForge/SonicForge/app/...`), installs SDK pieces, runs `fetch_core.sh`, `gradle assembleDebug`, uploads artifacts `SonicForge-APK` and `build-log`; errors are summarised on the run's Summary page. Alternative one-line Termux push exists (see `docs/BUILD_GUIDE.md`). He uses a fine-grained, short-lived GitHub token (Contents + Workflows read/write), deleted afterwards.
- Fixed signing key `app/forge.keystore` (password `sonicforge`, alias `forge`) so every build updates the previous one without data loss.
- Toolchain: AGP 8.5.2, Gradle 8.7, Kotlin 1.9.24, Compose compiler 1.5.14, Compose BOM 2024.06.00, compileSdk/targetSdk 34, **minSdk 26 (Android 8.0)**, NDK 26.1.10909125, CMake 3.22.1, JDK 17. Dependencies: documentfile, junrar 7.5.5 (RAR4 only, RAR5 unsupported), commons-compress 1.26.1 + xz 1.9 (7z), coroutines. Opt-in compiler flags for experimental Compose APIs are set as a safety net, but code avoids experimental APIs (the Pager was removed after it broke the 0.2.0 build).
- History of builds: version 0.1.0 compiled once and "works well". 0.2.0 failed in `Guide.kt` (experimental `HorizontalPager`). Everything after that (0.3.x) has never been compiled. ChatGPT's suggested fix (`@file:OptIn` after `package`) was wrong and the user told me not to trust it.

## 3. The user's working rules (he repeated these many times)
1. "Do what's needed, don't do what's not needed." Don't add things that can't really work. Doubtful things: add only with a clear EXPERIMENTAL / may-crash warning. Don't add huge things with no good offline resources (e.g. PS2 emulation).
2. Research facts on the internet; don't invent. Be honest about what is unverified. Don't trust ChatGPT answers blindly.
3. Always explain limits: what works / what doesn't / why. Write a "things we couldn't implement" list.
4. Make everything polished, comfortable and understandable: good descriptions, instructions, warnings, in-app help; not "boring blank text".
5. Customisation must be generalised, individual per game, with presets; Classic (simple) vs Pro mode hides advanced settings (and explains what is hidden and why).
6. Every save of settings should show a small confirmation sprite saying WHAT was saved; saves must be verified (read back).
7. Important setting changes ask "Are you sure?" with a 3 s/5 s delay (both switchable), underlining what WILL and what will NOT happen.
8. Epilepsy warning for glitch/tilt features. No 18+ content, no Sonic-related adult stuff (Buzz Bomber refuses such questions). Don't mention Nintendo in Sonic's dialogue (user: "I told you about Nintendo only for research").
9. Always update: in-app "What's new"/Updates tab, version number, in-app guide/help, docs, translations.
10. Version numbering: user keeps asking "+1 at the end". Sequence so far: 0.1.0 "Customisation n' Blue", 0.2.0 "Archives n' Cheats", then 0.3.0/0.3.1 in code, planned release **0.3.3** with a synopsis of up to 3 words ("Emerald Everything Plus"). Version + short name are shown in SETTINGS > ABOUT APP (not permanently on screen). History in SETTINGS > UPDATES (expandable entries, "What's new" style with icons; see screenshot style: version pill + short description + icon bullets).
11. Remove any mention of "the developer/user prompts/ChatGPT" from code comments: comments must only describe what the code does, in my own words.
12. The user wants delivery as ONE ZIP he uploads to GitHub, built via Actions; the app must support ARM64 + ARM32 (three APKs: Universal, arm64-v8a, armeabi-v7a; Android TV uses the same APK with leanback manifest bits). Mention minimum Android (8.0 / API 26).

## 4. Product summary (what the app is meant to be)
Tabs: GAMES (collections per system: Mega Drive / Sega CD / 32X / Game Boy / OpenBOR), MINI-GAMES, MUSIC, CUSTOMIZE, LOCATIONS, SETTINGS, HELP (Quick start, topics, ASK A HELPER chat with 9 characters), plus a first-run character-led tutorial (Tails leads), a rescue "👁 UI" button, and a mini player bar. Later planned: FILES (explorer), COMICS/PHOTOS/VIDEO, PIXEL DRAW, TEXT EDITOR, KARAOKE, FLASH (Ruffle), widgets.
See `03_CHECKLIST.md` for exact status.

## 5. Style notes for replies
- Warm, clear, structured; Russian when the user writes Russian. Avoid walls of text; but he explicitly likes detailed explanations and instructions inside the app.
- Don't claim something works if it was never compiled/tested. Say "written, not compiled".
- Characters in helper dialogues: roleplay lightly, give detailed answers, include "examples, not a complete list" and "as of mid-2026" disclaimers, hint which other helper to ask.
