# Research notes (what was checked, what is still unverified)

## Cheats & codes (checked on Sonic Retro, TCRF, Almar's Guides, Sonic Stadium archive)
- Sonic & Knuckles / Sonic 3 & Knuckles (Game Genie): **AWXT-CA4C** don't lose rings when hit; **HXRT-AA6A** infinite time. (Almar's guides)
- Action Replay: **FFFFE0:0101** enables the level-select flag in S&K (TCRF).
- Level select: **Sonic 1**: title screen Up, Down, Left, Right (ring sound), then hold A + Start. **S&K/S3&K**: in Angel Island Zone grab a rope/vine and press Left×3, Right×3, Up×3 (TCRF/Sonic Retro). **Sonic 3 (standalone)**: title screen Up, Up, Down, Down, Up, Up, Up, Up; Down, Down opens Sound Test. **Sonic 2 locked onto S&K**: title Up×3, Down×3, Left, Right, Left, Right, then A + Start.
- **Sonic 2 standalone** sound-test codes: Super Sonic 04, 01, 02, 06 (confirmed); level-select 19, 65, 09, 17 (commonly cited, NOT verified in this research; the app marks it "test it").
- **Sonic Origins cheat codes do not apply to Mega Drive ROMs** (Origins is a modern PC/console compilation). MD ROMs use Game Genie/Action Replay codes and button-combination codes.
- Genesis Plus GX accepts Game Genie `XXXX-XXXX` and Action Replay `XXXXXX:XXXX`.

## Abilities / bugs / features (Sonic Retro SPG, TCRF, StrategyWiki)
- **Drop Dash**: introduced as an official move in Sonic Mania (2017); earlier only in fan games/mods; an early Sonic 3 prototype had a similar idea; Sonic Origins adds it to older games.
- **Insta-Shield**: introduced in Sonic 3 (1994) (Japanese name "Double Spin Attack"); a landing-timing bug in Sonic 3 (flag not cleared) was fixed in Sonic & Knuckles; absent by default in Sonic Mania (unlockable).
- **Roll lock** (Sonic 1/2): prevents steering backwards mid-air after a rolling jump; Origins changed it.
- **Sonic 3 vertical wrap**: lets Sonic reach Knuckles-only areas (Angel Island Act 1); never fixed.
- **Sonic 1 lives glitch** (Labyrinth Zone Act 3, 1 → 255 lives) documented on TCRF. The "spike bug" in Sonic 1 is mentioned by fans/hacks but its cause was NOT verified; Sonic's dialogue honestly says so.
- Spin Dash arrived in Sonic 2 (1992); Super Peel-Out in Sonic CD (1993); elemental shields + insta-shield in Sonic 3; Knuckles glide/climb in Sonic 3 & Knuckles.

## Franchise facts used in helper dialogues (check again before expanding)
- Release years: Sonic 1 1991, Sonic 2 1992, Sonic CD 1993, Sonic 3 / S&K 1994, Knuckles' Chaotix 1995 (32X), Sonic Adventure 1998. Mega Drive Oct 1988 (JP) / 1989 (US as Genesis); Sega CD Dec 1991 (JP); 32X 1994.
- TV: Adventures of Sonic the Hedgehog & SatAM 1993, Sonic Underground 1999, OVA 1996, Sonic X 2003-2006, Sonic Boom 2014-2017, Sonic Prime (Netflix) from 2022. Films: 2020, 2022, 2024. Knuckles series (Paramount+) 2024. A fourth film was announced for 2027; Sonic's 35th anniversary was June 2026 (as of mid-2026 knowledge).
- Comics: Fleetway "Sonic the Comic" UK 1993-2002; Archie Comics 1993-2017; IDW from 2018.
- Voices: Jaleel White (1990s cartoons), Ryan Drummond (Sonic Adventure era), Jason Griffith (Sonic X English), Roger Craig Smith (games 2010-2021), Ben Schwartz (films).
- Eggman/Robotnik: Ivo Robotnik, "Eggman" Japanese nickname; Western Genesis-era games used Robotnik; Sonic Adventure (1998) onward uses Eggman worldwide, films use Dr. Robotnik.
- **Sonic Speed Cafe** (pop-up by SEGA with Secret Sauce Society, first at San Diego Comic-Con 2023, later locations): menu items used in the mini-game: Sonic's Classic Chili Dog, Knuckles Sandwich, Piko Piko Tenders, Golden Ring Onion Rings, Fast Fries, Green Hill Vegan Chili Cup, Evil Genius sandwich, Rouge's Kickin' Chicken Sando; drinks: Blue Blur, Smashing Echidna, Flying Fox, Team Dark milkshake, Sweet Amy milkshake, Tails Spin Tea.
- NOT yet researched (requested): LEGO Sonic sets history, McLaren/Minecraft/DC collabs details, Sonic Racing CrossWorlds roster/collabs (e.g. Hatsune Miku), NiGHTS appearances in Sonic games, Sega IP guide (NiGHTS, Super Monkey Ball, Jet Set Radio, Persona, Crazy Taxi...), indie game recommendations, game/character birthdays, Sonic canon history, per-language fun facts (one example the user gave: Russian "Хвостик" for Tails from an old Sonic Adventure translation; unverified), eye colour facts, multiplayer/co-op list, music composers details.

## libretro / emulator error messages (RetroArch/libretro forums, RetroPie)
- "Unable to open CD BIOS …bios_CD_U.bin" / "Failed to load content": Sega CD BIOS missing or wrong name/dump; Genesis Plus GX needs `bios_CD_U.bin` (USA), `bios_CD_E.bin` (Europe), `bios_CD_J.bin` (Japan) in the system dir; `.bin` without `.cue` loses CD audio.
- "wrong ELF class" / dlopen failures: core ABI doesn't match the app/phone (32 vs 64-bit).
- These are encoded in `data/CrashKB.kt`.

## OpenBOR analysis (user's uploaded files)
- `OpenBOR.apk`: package **org.openbor.engine**, activity `org.openbor.engine.GameActivity`, native libraries only in **lib/armeabi-v7a** (32-bit ARM), permissions READ/WRITE_EXTERNAL_STORAGE, no VIEW intent filter (cannot be given a file by intent). Many new phones can't run 32-bit apps → the launcher shows a CPU compatibility report and exports the PAK to `Download/SonicForge-OpenBOR` for manual placement into OpenBOR's Paks folder.
- `PXLPD_7_8.zip`: an OpenBOR modded game package (game 7.8, mod 3.2 per the user's pasted description); PAK is moved into the engine's Paks folder; on Windows the engine and Paks sit side by side. User says the "mod edition" runs smoothly with the OpenBOR APK; another project is unreliable. Files too large to upload fully; no run test done.
- User also attached `screenshot_examples.7z` and an Ibis-Paint-style layers panel screenshot (reference for the pixel-draw tab: Selection layer, folder, per-layer visibility eye, opacity %, blend mode "Normal", clipping arrow, lock-alpha, merge, delete, FX, reference/canvas tools). The 7z was NOT opened.

## Platform notes (from general knowledge; re-verify before writing tutorials)
- Android 10 introduced scoped storage; Android 11 enforces it; apps cannot browse other apps' `Android/data` and `Android/obb` via the picker; Android 13+ restricts further. Workarounds for experienced users: Shizuku-enabled file managers, `adb push`/`adb install-multiple` from a PC, split-APK installers for `.apks/.xapk/.apkm`, enabling "Install unknown apps" per source. keepandroidopen.org is the style reference the user wants for the tutorial (not fetched yet; sideloading-policy news changes: check it).
- LoudnessEnhancer gives >100% volume for MediaPlayer/AudioTrack; SoundPool can't be boosted (menu sounds capped at 100%).
- `SurfaceView` can't be clipped by Compose; overlays above it work.
- Compose `HorizontalPager` showed as experimental in this toolchain: avoid.
- AGP: `ndk.abiFilters` conflicts with `splits.abi`: remove abiFilters when enabling splits.

## Unverified items inside the code (flag if they misbehave)
- S3K advanced RAM offsets (`Watch.s3kx`), S2 Tails fly anim id 0x20, S2/S3K status_secondary bit layout, drowning air counter semantics, X/Y/Z mapping for the 6-button pad, device id 257 for the 6-button pad, buildbot URLs for picodrive/mgba, 32X/GBA behaviour, footstep cadence formula, ring "drain" heuristics (small drops 1-3 without hurt animation).
