# UPDATE (end of chat): Section A (undefined symbols), B (config) and most of "Config still to do" are now DONE. What remains before/after the first build:
1. Upload `SonicForge.zip`, run Actions ▸ Build APK, send the Summary errors (`e:` lines) if it fails; fix; repeat. Expect a few compile errors: nothing was compiled for many iterations.
2. Optional download steps (`fetch_core.sh` for picodrive/mgba, `fetch_extras.sh` for Ruffle) are allowed to fail; the app then reports the missing core/Ruffle. If `fetch_extras.sh` can't find the Ruffle asset, check the asset name pattern "web-selfhosted" in the GitHub releases API (not verified offline).
3. First real-device checks (in this order): app starts; GAMES tab; import a Mega Drive ROM; PLAY; touch controls; pause menu; save states; vibration; music + notification; mini-games; SETTINGS tabs; backup; logs viewer (tap version 5×); icon switching; Flash with a small .swf.
4. Then do "NEXT UPDATE" items in `03_CHECKLIST.md` (top block).
Everything below is the older plan (partially superseded):

# Known issues & exact next steps (do these first)

## A. Symbols referenced but NOT defined (the project will not compile until fixed)
1. `ExternalApps` (object with `label(ctx, key): String` and a list of installed launcher apps) and `@Composable AppPicker(key: String, onClose: () -> Unit)`: used by `SettingsUi.GeneralTab`. Store keys `extFm`, `extEdit` hold the chosen package. Use `queryIntentActivities(MAIN/LAUNCHER)` (manifest `<queries>` already allows it). Make LocationsUi "OPEN" use `extFm` when set.
2. `SCENE_PRESETS`: list of objects with `name: String`, `sky: Int`, `ground: Int`, `body: Int` (ARGB ints; 0 = default). Used by `Launcher.EditDialog`. Write ~26 presets named after zones/hacks (Green Hill, Marble, Spring Yard, Labyrinth, Star Light, Scrap Brain, Emerald Hill, Chemical Plant, Aquatic Ruin, Casino Night, Hill Top, Mystic Cave, Oil Ocean, Metropolis, Sky Chase, Wing Fortress, Death Egg, Angel Island, Hydrocity, Marble Garden, Carnival Night, Ice Cap, Launch Base, Sky Sanctuary, Hidden Palace, Shadow Space, Starlight (Tails) ...).
3. `Scene.kt` rings must be COLLECTED (hero touches ring → score +10, ring respawns off-screen) with a visible score; currently rings are drawn but never collected (user complaint).

## B. Config still to do
- `app/build.gradle.kts`: versionCode 6 / versionName "0.3.3"; remove `ndk { abiFilters }`; add `splits { abi { isEnable = true; reset(); include("arm64-v8a","armeabi-v7a"); isUniversalApk = true } }`.
- `AndroidManifest.xml`: permissions (FOREGROUND_SERVICE, FOREGROUND_SERVICE_MEDIA_PLAYBACK, POST_NOTIFICATIONS), `<service android:name=".audio.MusicService" android:exported="false" android:foregroundServiceType="mediaPlayback"/>`, 9 activity-aliases (`.IconDefault` enabled, `.IconCalc`, `.IconNotes`, `.IconRing`, `.IconLauncher`, `.IconCollection`, `.IconMusic`, `.IconPad`, `.IconClock` disabled; targetActivity `.MainActivity`; MAIN/LAUNCHER filters; default alias also LEANBACK_LAUNCHER), remove LAUNCHER filter from MainActivity, `uses-feature android.software.leanback required=false`. Add 8 vector icons.
- `AboutUi.Changelog`: replace head with `Release("0.3.3", "Emerald Everything Plus", ...)` listing everything done (see checklist), update `planned`.
- `I18n.kt`: add ko, hi, tr (+ keys LOCATIONS, HELP, VIBRATION, etc.); `current()`/`tr()` must handle languages beyond the 9-column table (e.g. a second table). Pt label → "Português (Brasil)". Language-accuracy/layout disclaimer text is already in `SettingsUi.GeneralTab`.
- `docs/BUILD_GUIDE.md`: describe three APKs and which to pick.
- Scrub code comments for any wording about "user asked/prompt/ChatGPT/developer"; comments must describe behaviour only.

## C. Compile-risk review (read carefully; none of this was compiled)
Highest risk files (recently written/patched): `GameActivity.kt`, `SettingsUi.kt` (many string-replace patches, check `if (pro) { }` brace pairing around VideoTab), `Launcher.kt` (wrapped in an extra `Column`, patched EditDialog/GameHero), `MusicUi.kt`, `Music.kt`, `EmuSession.kt`, `bridge.cpp`, `Library.kt`, `Archives.kt`, `Haptics.kt`, `Watch.kt`, `HelpUi.kt`, `AssistantData.kt` (large string literals; no `$` or unescaped quotes), `I18n.kt` (`RAW` constant must stay < 64 KB UTF-8).
Checks to run each time: bracket balance script; grep for removed APIs (`Pads.actFor(`, `BoulderOverlay`, `Archives.extract(`, `Haptics.test(true`); ensure every `import com.sonicforge...` target exists; Compose calls with wrong named params; `Text` wrapper params (no `softWrap`, `overflow`, `style`); `Btn(text, modifier, selected, color, onClick)` signature; `SSlider(label,key,def,max,unit)`.
If the Actions run fails: ask the user for the **Summary page screenshot or the `e:` lines**, fix, re-zip.

## D. Order of the remaining work after it compiles
1. In-app info: Changelog/What's new, HELP topic "Android folders & restrictions (Shizuku/adb/OBB/.apks) for experienced users" in keepandroidopen-style, update tutorial text if features changed.
2. Customisation polish: gradient/image launcher backgrounds with fit/crop/position, holiday themes + toggle, frame contour variants & shapes (PNG mask later), per-tab presets (music/…), animated backgrounds.
3. Haptics breadth: hack profiles (Sonic 2 XL, Hellfire Saga, Ordinary Sonic) as selectable presets, Sky Battery wind, wall breaks, score tally, danger-meter via Ring Finder.
4. Files: explorer tab (multi-select, copy/move/rename/delete, extract, format groups, hidden/system toggle with warning, repair library/clear system folder), mods folder option, choose-external-app integration.
5. Pixel Draw tab (layers with visibility, opacity, clipping mask, paste image onto layer, reference image, canvas resize, grid, brushes, fill, palettes ≥4 custom, export PNG) + simple text editor.
6. Media tabs: comics (cbz/cbr/cb7/pdf/image folders, webtoon mode, Kotatsu import), photos, video (VideoView + controls hide/show, covers, subtitles).
7. Helpers content expansion (see requests log) + avatars + holiday events.
8. Karaoke/multitrack editor only if feasible; else voice mini-game. Flash (Ruffle), SRB2, DS, widgets as separate milestones.
9. Final polish pass, docs, what's-new, three APK explanation, zip.

## E. Things that are impossible/not worth it (tell the user, with reasons)
RAR5 (library), adaptive triggers for generic Android pads, embedding Saturn/Dreamcast/PSP/GameCube/Wii/PS2/3DS (hardware rendering + size), Arabic UI (RTL), launcher icon switching on Android < 8 (app min is 8), universal "close all background" beyond the app's own service, running 32-bit-only OpenBOR on 64-bit-only phones, notification permission on Android 13+ requires user approval.
