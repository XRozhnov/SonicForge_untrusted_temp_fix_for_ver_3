# SonicForge

One app: a launcher for your own Mega Drive / Genesis ROMs (Sonic 1/2/3&K and any hacks), plus mini-games, a retro music player,
GLSL shaders, skins and a fully customisable touch-control layout. **No INTERNET permission** is declared.

## Build the APK
**Option A – GitHub (no local setup):** push this folder to a GitHub repo → Actions → "Build APK" → download `SonicForge-debug-apk`.
**Option B – local:** install Android Studio (SDK 34, NDK 26.1, CMake 3.22.1), run `./fetch_core.sh` (downloads the open-source
Genesis Plus GX libretro core into `app/src/main/jniLibs/arm64-v8a/libgpgx.so`; needs internet only at build time), then Build > Build APK.
Targets arm64-v8a phones. Sideload the APK.

## Docs
* docs/BUILD_GUIDE.md: step-by-step building (GitHub, Termux, PC), verifying, uninstalling
* docs/WHERE_FILES_LIVE.md: every folder the app reads or writes

## Using it
* GAMES > "+ ADD GAME": pick your ROMs (.bin/.md/.gen/.smd or .zip). 7z/rar must be unpacked first. ROMs are copied into the app's private storage; none ship with the app.
* Per-game: change background/logo, edit title/description/scene, haptic RAM addresses.
* MUSIC: two generated test tunes are included. Add files via the button or drop them into the folder shown on screen.
* CUSTOMIZE: skins (palette + shader + frame), frame style, shaders, touch-control editor with 6 colour-coded presets, backgrounds.
* SETTINGS: FPS / counter, orientation (incl. flipped), separate music/game/UI volumes, haptics, controller list + rebinding, launcher sounds, privacy check.

## Licences
Genesis Plus GX is licensed by its authors for non-commercial use. Respect its licence if you ever redistribute the APK.
