#!/usr/bin/env bash
# Downloads libretro cores at BUILD time (the APK itself has no internet permission).
# Required: genesis_plus_gx (Mega Drive / Master System / Game Gear / Sega CD). Optional: picodrive (32X), mgba (GBA/GB). Optional failures are skipped.
fetch() {  # abi core libname required
  local abi=$1 core=$2 lib=$3 req=$4
  local d=app/src/main/jniLibs/$abi; mkdir -p $d
  if curl -fsSL "https://buildbot.libretro.com/nightly/android/latest/$abi/${core}_libretro_android.so.zip" -o /tmp/$core-$abi.zip && unzip -qo /tmp/$core-$abi.zip -d /tmp/$core-$abi && cp /tmp/$core-$abi/${core}_libretro_android.so $d/$lib; then
    echo "OK   $abi $core"
  else
    echo "MISS $abi $core"; rm -f $d/$lib
    if [ "$req" = "1" ]; then echo "required core missing: $core"; exit 1; fi
  fi
}
for ABI in arm64-v8a armeabi-v7a; do
  fetch $ABI genesis_plus_gx libgpgx.so 1
  fetch $ABI picodrive libpicodrive.so 0
  fetch $ABI mgba libmgba.so 0
done
ls -la app/src/main/jniLibs/*/
